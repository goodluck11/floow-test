package com.demo.integration.it.config;

import org.springframework.lang.Nullable;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.CronTrigger;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * @created by 13/02/2026  - 10:10
 * @project IntegrationDemo
 * @author Goodluck
 */
public class InitialThenCronTrigger implements Trigger {
   private final CronTrigger cronTrigger;
   private final java.time.Duration initialDelay;
   private final AtomicBoolean firstRun = new AtomicBoolean(true);
   private final Clock clock;

   public InitialThenCronTrigger(String cronExpression) {
      this(cronExpression, java.time.Duration.ZERO, ZoneId.of("Asia/Qatar"));
   }

   public InitialThenCronTrigger(String cronExpression, java.time.Duration initialDelay) {
      this(cronExpression, initialDelay, ZoneId.of("Asia/Qatar"));
   }

   public InitialThenCronTrigger(String cronExpression, java.time.Duration initialDelay, ZoneId zoneId) {
      this(cronExpression, initialDelay, zoneId, Clock.system(zoneId));
   }

   public InitialThenCronTrigger(String cronExpression, java.time.Duration initialDelay, ZoneId zoneId, Clock clock) {
      this.cronTrigger = new CronTrigger(cronExpression, zoneId);
      this.initialDelay = initialDelay;
      this.clock = clock;
   }

   @Nullable
   @Override
   public Instant nextExecution(TriggerContext triggerContext) {
      if (firstRun.compareAndSet(true, false)) {
         return Instant.now(clock).plus(initialDelay);
      }
      return cronTrigger.nextExecution(triggerContext);
   }
}
