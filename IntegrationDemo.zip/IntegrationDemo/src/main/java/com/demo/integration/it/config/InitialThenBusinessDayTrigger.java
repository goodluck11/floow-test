package com.demo.integration.it.config;

import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;

import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/*
 * @created by 13/02/2026  - 10:21
 * @project IntegrationDemo
 * @author Goodluck
 */
public class InitialThenBusinessDayTrigger implements Trigger {

   private final AtomicBoolean firstRun = new AtomicBoolean(true);
   private final Duration initialDelay;
   private final LocalTime executionTime;
   private final int targetBusinessDay;
   private final Set<DayOfWeek> businessDays;
   private final ZoneId zoneId;
   private final Clock clock;

   public InitialThenBusinessDayTrigger() {
      this(Duration.ofMinutes(30), LocalTime.of(8, 0), 3, ZoneId.of("Asia/Qatar"));
   }

   public InitialThenBusinessDayTrigger(Duration initialDelay, LocalTime executionTime,
                                        int targetBusinessDay, ZoneId zoneId) {
      this(initialDelay, executionTime, targetBusinessDay, zoneId, Clock.system(zoneId));
   }

   public InitialThenBusinessDayTrigger(Duration initialDelay, LocalTime executionTime,
                                        int targetBusinessDay, ZoneId zoneId, Clock clock) {
      this.initialDelay = initialDelay;
      this.executionTime = executionTime;
      this.targetBusinessDay = targetBusinessDay;
      this.zoneId = zoneId;
      this.clock = clock;
      this.businessDays = Set.of(
              DayOfWeek.MONDAY,
              DayOfWeek.TUESDAY,
              DayOfWeek.WEDNESDAY,
              DayOfWeek.THURSDAY,
              DayOfWeek.FRIDAY
      );
   }

   @Override
   public Instant nextExecution(TriggerContext triggerContext) {
      if (firstRun.compareAndSet(true, false)) {
         return Instant.now(clock).plus(initialDelay);
      }

      var today = LocalDate.now(clock);
      var now = LocalDateTime.now(clock);

      var thirdBusinessDay = findNthBusinessDay(today.withDayOfMonth(1), targetBusinessDay);
      var nextRun = thirdBusinessDay.atTime(executionTime);

      // If we've passed this month's run, calculate for next month
      if (now.isAfter(nextRun) || now.isEqual(nextRun)) {
         var firstOfNextMonth = today.with(TemporalAdjusters.firstDayOfNextMonth());
         thirdBusinessDay = findNthBusinessDay(firstOfNextMonth, targetBusinessDay);
         nextRun = thirdBusinessDay.atTime(executionTime);
      }

      return nextRun.atZone(zoneId).toInstant();
   }

   private LocalDate findNthBusinessDay(LocalDate startOfMonth, int n) {
      var date = startOfMonth;
      var businessDayCount = 0;

      while (businessDayCount < n) {
         if (businessDays.contains(date.getDayOfWeek())) {
            businessDayCount++;
            if (businessDayCount == n) {
               return date;
            }
         }
         date = date.plusDays(1);
      }

      return date;
   }
}
