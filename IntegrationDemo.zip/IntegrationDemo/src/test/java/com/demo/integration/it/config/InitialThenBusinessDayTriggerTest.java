package com.demo.integration.it.config;

import org.junit.jupiter.api.Test;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.SimpleTriggerContext;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

class InitialThenBusinessDayTriggerTest {

   private final ZoneId zoneId = ZoneId.of("Asia/Qatar");
   private final LocalTime executionTime = LocalTime.of(8, 0);
   private final int targetBusinessDay = 3;

   @Test
   void testFirstRunReturnsInitialDelay() {
      Instant fixedNow = ZonedDateTime.of(2026, 2, 13, 10, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(fixedNow, zoneId);
      Duration initialDelay = Duration.ofMinutes(10);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              initialDelay, executionTime, targetBusinessDay, zoneId, clock);

      Instant nextExecution = trigger.nextExecution(new SimpleTriggerContext());
      assertEquals(fixedNow.plus(initialDelay), nextExecution);
   }

   @Test
   void testSecondRun_BeforeTargetDayInCurrentMonth() {
      // Feb 1st 2026 is Sunday.
      // Business days: Feb 2 (Mon), Feb 3 (Tue), Feb 4 (Wed).
      // 3rd business day is Feb 4th.
      Instant now = ZonedDateTime.of(2026, 2, 1, 10, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(now, zoneId);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              Duration.ZERO, executionTime, targetBusinessDay, zoneId, clock);

      TriggerContext context = new SimpleTriggerContext();
      trigger.nextExecution(context); // Consume first run

      Instant nextExecution = trigger.nextExecution(context);

      ZonedDateTime expected = ZonedDateTime.of(2026, 2, 4, 8, 0, 0, 0, zoneId);
      assertEquals(expected.toInstant(), nextExecution);
   }

   @Test
   void testSecondRun_OnTargetDayBeforeExecutionTime() {
      // 3rd business day is Feb 4th.
      Instant now = ZonedDateTime.of(2026, 2, 4, 7, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(now, zoneId);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              Duration.ZERO, executionTime, targetBusinessDay, zoneId, clock);

      TriggerContext context = new SimpleTriggerContext();
      trigger.nextExecution(context); // Consume first run

      Instant nextExecution = trigger.nextExecution(context);

      ZonedDateTime expected = ZonedDateTime.of(2026, 2, 4, 8, 0, 0, 0, zoneId);
      assertEquals(expected.toInstant(), nextExecution);
   }

   @Test
   void testSecondRun_OnTargetDayAfterExecutionTime() {
      // 3rd business day is Feb 4th.
      Instant now = ZonedDateTime.of(2026, 2, 4, 9, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(now, zoneId);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              Duration.ZERO, executionTime, targetBusinessDay, zoneId, clock);

      TriggerContext context = new SimpleTriggerContext();
      trigger.nextExecution(context); // Consume first run

      Instant nextExecution = trigger.nextExecution(context);

      // Should be the 3rd business day of March.
      // March 1st 2026 is Sunday.
      // Business days: March 2 (Mon), March 3 (Tue), March 4 (Wed).
      ZonedDateTime expected = ZonedDateTime.of(2026, 3, 4, 8, 0, 0, 0, zoneId);
      assertEquals(expected.toInstant(), nextExecution);
   }

   @Test
   void testSecondRun_AfterTargetDayInCurrentMonth() {
      Instant now = ZonedDateTime.of(2026, 2, 10, 10, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(now, zoneId);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              Duration.ZERO, executionTime, targetBusinessDay, zoneId, clock);

      TriggerContext context = new SimpleTriggerContext();
      trigger.nextExecution(context); // Consume first run

      Instant nextExecution = trigger.nextExecution(context);

      // 3rd business day of March 2026 is March 4th.
      ZonedDateTime expected = ZonedDateTime.of(2026, 3, 4, 8, 0, 0, 0, zoneId);
      assertEquals(expected.toInstant(), nextExecution);
   }

   @Test
   void testFindNthBusinessDay_WithWeekendStart() {
      // August 1st 2026 is Saturday.
      // 1st: Sat, 2nd: Sun, 3rd: Mon (1st BD), 4th: Tue (2nd BD), 5th: Wed (3rd BD).
      Instant now = ZonedDateTime.of(2026, 8, 1, 0, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(now, zoneId);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              Duration.ZERO, executionTime, 3, zoneId, clock);

      TriggerContext context = new SimpleTriggerContext();
      trigger.nextExecution(context); // Consume first run

      Instant nextExecution = trigger.nextExecution(context);

      ZonedDateTime expected = ZonedDateTime.of(2026, 8, 5, 8, 0, 0, 0, zoneId);
      assertEquals(expected.toInstant(), nextExecution);
   }

   @Test
   void testFindNthBusinessDay_LargeN() {
      // Feb 2026. 1st is Sun.
      // BDs: 2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 23, 24, 25, 26, 27.
      // 10th business day should be Feb 13th.
      Instant now = ZonedDateTime.of(2026, 2, 1, 0, 0, 0, 0, zoneId).toInstant();
      Clock clock = Clock.fixed(now, zoneId);

      InitialThenBusinessDayTrigger trigger = new InitialThenBusinessDayTrigger(
              Duration.ZERO, executionTime, 10, zoneId, clock);

      TriggerContext context = new SimpleTriggerContext();
      trigger.nextExecution(context); // Consume first run

      Instant nextExecution = trigger.nextExecution(context);

      ZonedDateTime expected = ZonedDateTime.of(2026, 2, 13, 8, 0, 0, 0, zoneId);
      assertEquals(expected.toInstant(), nextExecution);
   }
}
