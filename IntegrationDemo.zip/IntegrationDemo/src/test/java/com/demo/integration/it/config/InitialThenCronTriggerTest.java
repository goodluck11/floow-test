package com.demo.integration.it.config;

import org.junit.jupiter.api.Test;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.scheduling.support.SimpleTriggerContext;

import java.time.*;

import static org.assertj.core.api.Assertions.*;

class InitialThenCronTriggerTest {

    private static final ZoneId QATAR = ZoneId.of("Asia/Qatar");

    @Test
    void testFirstRunReturnsInitialDelay_UsingFixedClock_QatarTime() {
        Instant fixedNow = Instant.parse("2026-02-13T10:00:00Z");
        Clock qatarClock = Clock.fixed(fixedNow, QATAR);
        Duration initialDelay = Duration.ofMinutes(15);

        InitialThenCronTrigger trigger = new InitialThenCronTrigger("0 0 8 * * *", initialDelay, QATAR, qatarClock);

        TriggerContext context = new SimpleTriggerContext();
        Instant next = trigger.nextExecution(context);

        assertThat(next).isEqualTo(fixedNow.plus(initialDelay));
    }

    @Test
    void testSubsequentRunsFollowCron() {
        // Use a simple daily-at-08:00 cron in Qatar time
        Duration initialDelay = Duration.ZERO;
        InitialThenCronTrigger trigger = new InitialThenCronTrigger("0 0 8 * * *", initialDelay, QATAR);

        TriggerContext context = new SimpleTriggerContext();
        // First run is immediate (since initialDelay is zero)
        trigger.nextExecution(context);

        Instant second = trigger.nextExecution(context);
        assertThat(second).isAfter(Instant.now());
    }

    @Test
    void testCronRespectsQatarTimeZone() {
        // 1:00 on the 3rd day of next month, Qatar time
        CronExpression cron = CronExpression.parse("0 0 1 3 * *");
        ZonedDateTime base = ZonedDateTime.of(2026, 2, 15, 0, 0, 0, 0, QATAR);
        ZonedDateTime next = cron.next(base);

        assertThat(next.getZone()).isEqualTo(QATAR);
        assertThat(next.getDayOfMonth()).isEqualTo(3);
        assertThat(next.getHour()).isEqualTo(1);
    }

    @Test
    void testInvalidCronExpression() {
        assertThatThrownBy(() -> new InitialThenCronTrigger("invalid"))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
