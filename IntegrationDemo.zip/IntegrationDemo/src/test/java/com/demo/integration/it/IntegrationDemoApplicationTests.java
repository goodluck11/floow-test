package com.demo.integration.it;

import com.demo.integration.it.config.InitialThenCronTrigger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.scheduling.support.SimpleTriggerContext;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.within;


@ExtendWith(MockitoExtension.class)
class IntegrationDemoApplicationTests {

   @Mock
   private TriggerContext triggerContext;

   @Test
   void shouldTriggerImmediatelyOnFirstRun() {
      var trigger = new InitialThenCronTrigger("0 0 1 3 * *");

      var firstExecution = trigger.nextExecution(triggerContext);
      var now = Instant.now();

      assertThat(firstExecution)
              .isCloseTo(now, within(1, ChronoUnit.SECONDS));
   }

   @Test
   void shouldUseCronForSubsequentRuns() {
      var trigger = new InitialThenCronTrigger("0 0 1 3 * *");
      var context = new SimpleTriggerContext();

      // First execution
      trigger.nextExecution(context);

      // Second execution should use cron
      var secondExecution = trigger.nextExecution(context);

      assertThat(secondExecution)
              .isAfter(Instant.now());
   }

   @Test
   void shouldResetAfterTriggerContextChanges() {
      var trigger = new InitialThenCronTrigger("0 0 1 3 * *");

      trigger.nextExecution(new SimpleTriggerContext());

      // New trigger context
      var newContext = new SimpleTriggerContext();
      var execution = trigger.nextExecution(newContext);

      assertThat(execution).isNotNull();
   }

   @Test
   void testMonthlyCronExpression() {
      CronExpression cron = CronExpression.parse("0 0 1 3 * *");

      ZonedDateTime now = ZonedDateTime.of(2024, 2, 15, 0, 0, 0, 0, ZoneId.of("Asia/Qatar"));
      ZonedDateTime nextExecution = cron.next(now);

      assertThat(nextExecution.getDayOfMonth()).isEqualTo(3);
      assertThat(nextExecution.getMonth().getValue()).isEqualTo(3);
      assertThat(nextExecution.getYear()).isEqualTo(2024);
      assertThat(nextExecution.getHour()).isEqualTo(1);
   }

   @Test
   void testInvalidCronExpression() {
      assertThatThrownBy(() -> new InitialThenCronTrigger("invalid"))
              .isInstanceOf(IllegalArgumentException.class);
   }
}
