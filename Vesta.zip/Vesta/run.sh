#!/bin/bash
java -jar vesta-0.0.1-shaded.jar