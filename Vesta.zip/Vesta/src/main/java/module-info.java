module io.erikka.vesta.vesta {
   requires javafx.controls;
   requires javafx.fxml;
   requires javafx.swing;
   requires jasypt;
   requires org.json;
   requires java.desktop;

   opens io.erikka.vesta to javafx.fxml;
   exports io.erikka.vesta;
   exports io.erikka.vesta.controller;
   opens io.erikka.vesta.controller to javafx.fxml;
}
