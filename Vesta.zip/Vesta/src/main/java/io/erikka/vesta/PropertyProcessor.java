package io.erikka.vesta;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * @created by 16/02/2026 - 21:06
 * @project Vesta
 * @author Goodluck
 */
public class PropertyProcessor {
   private static final List<String> DEFAULT_PATTERNS = Arrays.asList(
           "*.password",
           "*.secret",
           "*.secret-key",
           "*-secret",
           "*.api-key",
           "*.apikey",
           "*.token",
           "*.auth-token",
           "*.private-key",
           "*.privatekey",
           "*.encryption-key",
           "*.access-key",
           "*.credentials",
           "*.auth",
           "*-key",
           "app.admin.password",
           "app.admin.api-key",
           "app.admin.secret",
           "*.client-secret"
   );

   private static final List<String> WHITELIST_PATTERNS = Arrays.asList(
           "*.username",
           "*.user",
           "*.public-key",
           "*.sender-id",
           "*.timeout",
           "*.port",
           "*.host",
           "*.base-url",
           "*.scope",
           "*.client-id"
   );

   private final EncryptionService encryptionService;
   private final boolean includeDataSourceUrl;

   public PropertyProcessor(EncryptionService encryptionService, boolean includeDataSourceUrl) {
      this.encryptionService = encryptionService;
      this.includeDataSourceUrl = includeDataSourceUrl;
   }

   public static List<String> getDefaultPatterns() {
      return new ArrayList<>(DEFAULT_PATTERNS);
   }

   public ProcessingResult encryptFile(String inputFile, String environment, List<String> patterns)
           throws IOException {

      List<String> lines = Files.readAllLines(Paths.get(inputFile), StandardCharsets.UTF_8);
      List<String> processedLines = new ArrayList<>();

      List<String> encryptedKeys = new ArrayList<>();
      List<String> skippedKeys = new ArrayList<>();

      for (var line : lines) {
         var trimmedLine = line.trim();

         if (trimmedLine.startsWith("#") || !trimmedLine.contains("=")) {
            processedLines.add(line);
            continue;
         }

         // Parse the property line
         int equalIndex = line.indexOf('=');
         if (equalIndex == -1) {
            processedLines.add(line);
            continue;
         }

         var beforeEqual = line.substring(0, equalIndex);
         var afterEqual = line.substring(equalIndex + 1);

         var key = beforeEqual.trim();

         // Skip jasypt configuration keys
         if (shouldSkipKey(key)) {
            processedLines.add(line);
            skippedKeys.add(key + " (jasypt config)");
            continue;
         }

         // Skip already encrypted values
         if (encryptionService.isEncrypted(afterEqual.trim())) {
            processedLines.add(line);
            skippedKeys.add(key + " (already encrypted)");
            continue;
         }

         // Check if the key is whitelisted (should not be encrypted)
         if (isWhitelisted(key)) {
            processedLines.add(line);
            continue;
         }

         // Check if the key matches any pattern
         boolean shouldEncrypt = shouldEncryptKey(key, patterns);

         if (shouldEncrypt) {
            var trimmedValue = afterEqual.trim();
            var encrypted = encryptionService.encrypt(trimmedValue);

            // Preserve the original line structure, only replace the value
            var newLine = beforeEqual + "=ENC(" + encrypted + ")";
            processedLines.add(newLine);
            encryptedKeys.add(key);
         } else {
            processedLines.add(line);
         }
      }

      var outputFile = generateOutputFileName(inputFile, environment, false);
      Files.write(Paths.get(outputFile), processedLines, StandardCharsets.UTF_8);

      return new ProcessingResult(outputFile, encryptedKeys, skippedKeys);
   }

   public ProcessingResult decryptFile(String inputFile, String environment, List<String> patterns)
           throws IOException {
      List<String> lines = Files.readAllLines(Paths.get(inputFile), StandardCharsets.UTF_8);
      List<String> processedLines = new ArrayList<>();

      List<String> decryptedKeys = new ArrayList<>();
      List<String> skippedKeys = new ArrayList<>();

      for (var line : lines) {
         var trimmedLine = line.trim();

         // Preserve comments, empty lines, and non-property lines as-is
         if (trimmedLine.startsWith("#") || !trimmedLine.contains("=")) {
            processedLines.add(line);
            continue;
         }

         // Parse the property line
         int equalIndex = line.indexOf('=');
         if (equalIndex == -1) {
            processedLines.add(line);
            continue;
         }

         var beforeEqual = line.substring(0, equalIndex);
         var afterEqual = line.substring(equalIndex + 1);

         var key = beforeEqual.trim();

         // Skip jasypt configuration keys
         if (shouldSkipKey(key)) {
            processedLines.add(line);
            skippedKeys.add(key + " (jasypt config)");
            continue;
         }

         // Check if the value is encrypted
         var trimmedValue = afterEqual.trim();
         if (encryptionService.isEncrypted(trimmedValue)) {
            boolean shouldDecrypt = shouldEncryptKey(key, patterns);

            if (shouldDecrypt) {
               try {
                  var decrypted = encryptionService.decrypt(trimmedValue);

                  // Preserve the original line structure, only replace the value
                  var newLine = beforeEqual + "=" + decrypted;
                  processedLines.add(newLine);
                  decryptedKeys.add(key);
               } catch (Exception e) {
                  processedLines.add(line);
                  skippedKeys.add(key + " (decryption failed: " + e.getMessage() + ")");
               }
            } else {
               processedLines.add(line);
            }
         } else {
            processedLines.add(line);
            if (shouldEncryptKey(key, patterns)) {
               skippedKeys.add(key + " (not encrypted)");
            }
         }
      }

      // Generate output filename
      var outputFile = generateOutputFileName(inputFile, environment, true);
      Files.write(Paths.get(outputFile), processedLines, StandardCharsets.UTF_8);

      return new ProcessingResult(outputFile, decryptedKeys, skippedKeys);
   }

   private boolean shouldSkipKey(String key) {
      var lowerKey = key.toLowerCase();
      return lowerKey.contains("jasypt") ||
              lowerKey.equals("jasypt.encryptor.password") ||
              lowerKey.equals("jasypt.encryptor.algorithm") ||
              lowerKey.startsWith("jasypt.");
   }

   private boolean isWhitelisted(String key) {
      return WHITELIST_PATTERNS.stream().anyMatch(pattern -> matchesPattern(key, pattern));
   }

   private boolean shouldEncryptKey(String key, List<String> patterns) {
      var lowerKey = key.toLowerCase();
      // Check datasource URL
      if (includeDataSourceUrl && (lowerKey.contains("datasource") && lowerKey.contains("url"))) {
         return true;
      }

      // Special case for Kafka SASL config (contains password in value)
      if (lowerKey.contains("sasl") && lowerKey.contains("jaas")) {
         return true;
      }

      // Check against patterns
      return patterns.stream().anyMatch(pattern -> matchesPattern(key, pattern));
   }

   private boolean matchesPattern(String key, String pattern) {
      var lowerKey = key.toLowerCase();
      var lowerPattern = pattern.toLowerCase();

      // Handle the exact match first
      if (lowerKey.equals(lowerPattern)) {
         return true;
      }

      // Convert wildcard pattern to regex
      var regex = lowerPattern
              .replace(".", "\\.")
              .replace("*", ".*");

      // Check if a pattern matches
      return lowerKey.matches(regex);
   }

   private String generateOutputFileName(String inputFile, String environment, boolean isDecryption) {
      var path = Paths.get(inputFile);
      var fileName = path.getFileName().toString();
      var directory = path.getParent() != null ? path.getParent().toString() : "";

      // Remove extension
      int dotIndex = fileName.lastIndexOf('.');
      var baseName = dotIndex > 0 ? fileName.substring(0, dotIndex) : fileName;
      var extension = dotIndex > 0 ? fileName.substring(dotIndex) : "";

      // Build new filename
      var suffix = isDecryption ? "-decrypted" : "";
      var envSuffix = (!isDecryption && environment != null && !environment.isEmpty())
              ? "-" + environment.toLowerCase()
              : "";
      var newFileName = baseName + envSuffix + suffix + extension;

      return directory.isEmpty() ? newFileName : Paths.get(directory, newFileName).toString();
   }

   public record ProcessingResult(String outputFile, List<String> processedKeys, List<String> skippedKeys) {
   }
}
