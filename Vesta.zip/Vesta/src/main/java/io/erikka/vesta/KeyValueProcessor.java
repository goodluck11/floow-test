package io.erikka.vesta;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/*
 * @created by 16/02/2026 - 21:09
 * @project Vesta
 * @author Goodluck
 */
public class KeyValueProcessor {
   private final EncryptionService encryptionService;

   public KeyValueProcessor(EncryptionService encryptionService) {
      this.encryptionService = encryptionService;
   }

   public List<KeyValuePair> processInput(String input, boolean encrypt) {
      List<KeyValuePair> results = new ArrayList<>();

      if (isJson(input)) {
         results.addAll(processJson(input, encrypt));
      } else {
         results.addAll(processKeyValuePairs(input, encrypt));
      }

      return results;
   }

   private boolean isJson(String input) {
      var trimmed = input.trim();
      return (trimmed.startsWith("{") && trimmed.endsWith("}")) ||
              (trimmed.startsWith("[") && trimmed.endsWith("]"));
   }

   private List<KeyValuePair> processJson(String json, boolean encrypt) {
      List<KeyValuePair> results = new ArrayList<>();

      try {
         processJsonObject(new JSONObject(json), "", results, encrypt);
      } catch (Exception e) {
         results.add(new KeyValuePair("ERROR", "", "Invalid JSON: " + e.getMessage()));
      }

      return results;
   }

   private void processJsonObject(JSONObject obj, String prefix, List<KeyValuePair> results, boolean encrypt) {
      for (var key : obj.keySet()) {
         var value = obj.get(key);
         var fullKey = prefix.isEmpty() ? key : prefix + "." + key;

         if (value instanceof JSONObject jsonObject) {
            processJsonObject(jsonObject, fullKey, results, encrypt);
         } else if (value != null) {
            var valueStr = value.toString();
            results.add(new KeyValuePair(fullKey, valueStr, processValue(valueStr, encrypt)));
         }
      }
   }

   private List<KeyValuePair> processKeyValuePairs(String input, boolean encrypt) {
      List<KeyValuePair> results = new ArrayList<>();

      var pairs = splitByComma(input);

      for (var pair : pairs) {
         pair = pair.trim();
         if (pair.isEmpty()) continue;

         int equalIndex = pair.indexOf('=');
         if (equalIndex > 0) {
            var key = pair.substring(0, equalIndex).trim();
            var value = pair.substring(equalIndex + 1).trim();

            // Remove quotes if present
            value = removeQuotes(value);

            results.add(new KeyValuePair(key, value, processValue(value, encrypt)));
         } else {
            results.add(new KeyValuePair("ERROR", pair, "Invalid format (expected key=value)"));
         }
      }

      return results;
   }

   private String[] splitByComma(String input) {
      List<String> parts = new ArrayList<>();
      var current = new StringBuilder();
      boolean inQuotes = false;

      for (char c : input.toCharArray()) {
         if (c == '"' || c == '\'') {
            inQuotes = !inQuotes;
            current.append(c);
         } else if (c == ',' && !inQuotes) {
            parts.add(current.toString());
            current = new StringBuilder();
         } else {
            current.append(c);
         }
      }

      if (!current.isEmpty()) {
         parts.add(current.toString());
      }

      return parts.toArray(new String[0]);
   }

   private String removeQuotes(String value) {
      if ((value.startsWith("\"") && value.endsWith("\"")) ||
              (value.startsWith("'") && value.endsWith("'"))) {
         return value.substring(1, value.length() - 1);
      }
      return value;
   }

   private String processValue(String value, boolean encrypt) {
      try {
         if (encrypt) {
            if (encryptionService.isEncrypted(value)) {
               return value + " (already encrypted)";
            }
            return "ENC(" + encryptionService.encrypt(value) + ")";
         } else {
            if (encryptionService.isEncrypted(value)) {
               return encryptionService.decrypt(value);
            }
            return value + " (not encrypted)";
         }
      } catch (Exception e) {
         return "ERROR: " + e.getMessage();
      }
   }

   public record KeyValuePair(String key, String originalValue, String processedValue) {
   }
}
