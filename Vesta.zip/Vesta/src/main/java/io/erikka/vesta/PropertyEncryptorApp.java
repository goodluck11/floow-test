package io.erikka.vesta;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.awt.*;

import static java.util.Objects.requireNonNull;

/*
 * @created by 16/02/2026 - 21:03
 * @project Vesta
 * @author Goodluck
 */
public class PropertyEncryptorApp extends Application {

   @Override
   public void start(Stage primaryStage) throws Exception {
      var loader = new FXMLLoader(getClass().getResource("/fxml/main.fxml"));
      var scene = new Scene(loader.load(), 1000, 700);

      scene.getStylesheets().add(requireNonNull(getClass().getResource("/css/style.css")).toExternalForm());

      primaryStage.setTitle("Vesta - Jasypt Property Encryptor/Decryptor");
      primaryStage.setScene(scene);
      primaryStage.setMinWidth(900);
      primaryStage.setMinHeight(650);

      try (var iconStream = getClass().getResourceAsStream("/images/icon.png")) {
         if (iconStream != null) {
            var icon = new Image(iconStream);
            primaryStage.getIcons().add(icon);
            setMacOSDockIcon(icon);
         }
      }

      primaryStage.show();
   }

   private void setMacOSDockIcon(Image fxImage) {
      try {
         if (Taskbar.isTaskbarSupported()) {
            var taskbar = Taskbar.getTaskbar();

            if (taskbar.isSupported(Taskbar.Feature.ICON_IMAGE)) {
               var awtImage = javafx.embed.swing.SwingFXUtils.fromFXImage(fxImage, null);
               taskbar.setIconImage(awtImage);
            }
         }
      } catch (Exception e) {}
   }

   public static void main(String[] args) {
      launch(args);
   }
}
