package io.erikka.vesta;

/*
 * @created by 16/02/2026 - 22:54
 * @project Vesta
 * @author Goodluck
 */
public class Launcher {
   public static void main(String[] args) {
      PropertyEncryptorApp.main(args);
   }
}
