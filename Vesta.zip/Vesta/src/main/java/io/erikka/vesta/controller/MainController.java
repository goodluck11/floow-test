package io.erikka.vesta.controller;

import io.erikka.vesta.EncryptionService;
import io.erikka.vesta.KeyValueProcessor;
import io.erikka.vesta.PropertyProcessor;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.stage.FileChooser;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static io.erikka.vesta.KeyValueProcessor.KeyValuePair;

/*
 * @created by 16/02/2026 - 21:12
 * @project Vesta
 * @author Goodluck
 */
public class MainController {
   // File Processing Tab
   @FXML
   private TextField filePathField;
   @FXML private PasswordField masterKeyField;
   @FXML private Spinner<Integer> iterationsSpinner;
   @FXML private ComboBox<String> environmentComboBox;
   @FXML private CheckBox includeDataSourceUrlCheckBox;
   @FXML private ListView<String> defaultPatternsListView;
   @FXML private TextArea customPatternsTextArea;
   @FXML private TextArea fileResultArea;
   @FXML private ProgressIndicator fileProgressIndicator;

   // Key-Value Processing Tab
   @FXML private PasswordField kvMasterKeyField;
   @FXML private Spinner<Integer> kvIterationsSpinner;
   @FXML private TextArea kvInputTextArea;
   @FXML private TableView<KeyValueResult> kvResultTable;
   @FXML private TableColumn<KeyValueResult, String> kvKeyColumn;
   @FXML private TableColumn<KeyValueResult, String> kvOriginalColumn;
   @FXML private TableColumn<KeyValueResult, String> kvProcessedColumn;
   @FXML private ProgressIndicator kvProgressIndicator;

   private final ObservableList<KeyValueResult> kvResults = FXCollections.observableArrayList();

   @FXML
   public void initialize() {
      setupFileProcessingTab();
      setupKeyValueTab();
   }

   private void setupFileProcessingTab() {
      // Initialize iterations spinner
      SpinnerValueFactory<Integer> valueFactory =
              new SpinnerValueFactory.IntegerSpinnerValueFactory(100, 100000, 1000, 100);
      iterationsSpinner.setValueFactory(valueFactory);
      iterationsSpinner.setEditable(true);

      // Initialize environment combo box
      environmentComboBox.setItems(FXCollections.observableArrayList("dev", "uat", "prod"));
      environmentComboBox.setValue("dev");

      // Initialize default patterns list
      ObservableList<String> patterns = FXCollections.observableArrayList(
              PropertyProcessor.getDefaultPatterns()
      );
      defaultPatternsListView.setItems(patterns);
      defaultPatternsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

      // Select all by default
      defaultPatternsListView.getSelectionModel().selectAll();

      // Hide progress indicator initially
      fileProgressIndicator.setVisible(false);

      // Custom patterns placeholder
      customPatternsTextArea.setPromptText("Enter custom patterns (one per line)\nExample:\napp.custom.*.secret\nmy.app.*.token");
   }

   private void setupKeyValueTab() {
      // Initialize iterations spinner
      SpinnerValueFactory<Integer> valueFactory =
              new SpinnerValueFactory.IntegerSpinnerValueFactory(100, 100000, 1000, 100);
      kvIterationsSpinner.setValueFactory(valueFactory);
      kvIterationsSpinner.setEditable(true);

      // Setup table columns
      kvKeyColumn.setCellValueFactory(new PropertyValueFactory<>("key"));
      kvOriginalColumn.setCellValueFactory(new PropertyValueFactory<>("originalValue"));
      kvProcessedColumn.setCellValueFactory(new PropertyValueFactory<>("processedValue"));

      // Make columns resizable
      kvKeyColumn.prefWidthProperty().bind(kvResultTable.widthProperty().multiply(0.25));
      kvOriginalColumn.prefWidthProperty().bind(kvResultTable.widthProperty().multiply(0.35));
      kvProcessedColumn.prefWidthProperty().bind(kvResultTable.widthProperty().multiply(0.35));

      // Enable text wrapping in cells
      kvOriginalColumn.setCellFactory(tc -> createWrappingCell());
      kvProcessedColumn.setCellFactory(tc -> createWrappingCell());

      kvResultTable.setItems(kvResults);

      // Hide progress indicator initially
      kvProgressIndicator.setVisible(false);

      // Input placeholder
      kvInputTextArea.setPromptText("Enter key-value pairs or JSON:\n\nComma-separated:\napi.key=secret123, db.password=mypass\n\nJSON:\n{\"api.key\": \"secret123\", \"db.password\": \"mypass\"}");
   }

   private TableCell<KeyValueResult, String> createWrappingCell() {
      return new TableCell<>() {
         private final Label label = new Label();

         {
            label.setWrapText(true);
            label.setMaxWidth(Double.MAX_VALUE);
            setGraphic(label);
         }

         @Override
         protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
               label.setText(null);
            } else {
               label.setText(item);
            }
         }
      };
   }

   @FXML
   private void handleBrowseFile() {
      FileChooser fileChooser = new FileChooser();
      fileChooser.setTitle("Select Properties File");
      fileChooser.getExtensionFilters().addAll(
              new FileChooser.ExtensionFilter("Properties Files", "*.properties", "*.yml", "*.yaml"),
              new FileChooser.ExtensionFilter("All Files", "*.*")
      );

      File file = fileChooser.showOpenDialog(filePathField.getScene().getWindow());
      if (file != null) {
         filePathField.setText(file.getAbsolutePath());
      }
   }

   @FXML
   private void handleEncryptFile() {
      processFile(true);
   }

   @FXML
   private void handleDecryptFile() {
      processFile(false);
   }

   private void processFile(boolean encrypt) {
      // Validate inputs
      String filePath = filePathField.getText();
      String masterKey = masterKeyField.getText();

      if (filePath == null || filePath.trim().isEmpty()) {
         showError("Please select a properties file");
         return;
      }

      if (masterKey == null || masterKey.trim().isEmpty()) {
         showError("Please enter master key");
         return;
      }

      File file = new File(filePath);
      if (!file.exists()) {
         showError("File does not exist: " + filePath);
         return;
      }

      // Get patterns
      List<String> patterns = getSelectedPatterns();
      if (patterns.isEmpty()) {
         showError("Please select at least one pattern");
         return;
      }

      // Show progress
      fileProgressIndicator.setVisible(true);
      fileResultArea.setText("Processing...");

      // Process in the background thread
      new Thread(() -> {
         try {
            int iterations = iterationsSpinner.getValue();
            String environment = environmentComboBox.getValue();
            boolean includeDataSourceUrl = includeDataSourceUrlCheckBox.isSelected();

            EncryptionService encryptionService = new EncryptionService(masterKey, iterations);
            PropertyProcessor processor = new PropertyProcessor(encryptionService, includeDataSourceUrl);

            PropertyProcessor.ProcessingResult result;
            if (encrypt) {
               result = processor.encryptFile(filePath, environment, patterns);
            } else {
               result = processor.decryptFile(filePath, environment, patterns);
            }

            // Update UI on JavaFX thread
            Platform.runLater(() -> {
               fileProgressIndicator.setVisible(false);
               displayFileResult(result, encrypt);
               resetFileProcessingInputs();
            });

         } catch (Exception e) {
            Platform.runLater(() -> {
               fileProgressIndicator.setVisible(false);
               showError("Processing failed: " + e.getMessage());
               e.printStackTrace();
            });
         }
      }).start();
   }

   private List<String> getSelectedPatterns() {
      List<String> patterns = new ArrayList<>();

      // Add selected default patterns
      patterns.addAll(defaultPatternsListView.getSelectionModel().getSelectedItems());

      // Add custom patterns
      String customPatternsText = customPatternsTextArea.getText();
      if (customPatternsText != null && !customPatternsText.trim().isEmpty()) {
         String[] customPatterns = customPatternsText.split("\n");
         for (String pattern : customPatterns) {
            pattern = pattern.trim();
            if (!pattern.isEmpty() && !patterns.contains(pattern)) {
               patterns.add(pattern);
            }
         }
      }

      return patterns;
   }

   private void displayFileResult(PropertyProcessor.ProcessingResult result, boolean encrypted) {
      StringBuilder sb = new StringBuilder();

      String action = encrypted ? "ENCRYPTION" : "DECRYPTION";
      sb.append("========== ").append(action).append(" COMPLETED ==========\n\n");

      sb.append("Output File: ").append(result.outputFile()).append("\n\n");

      sb.append("Processed Keys (").append(result.processedKeys().size()).append("):\n");
      if (result.processedKeys().isEmpty()) {
         sb.append("  None\n");
      } else {
         result.processedKeys().forEach(key -> sb.append("  ✓ ").append(key).append("\n"));
      }

      sb.append("\nSkipped Keys (").append(result.skippedKeys().size()).append("):\n");
      if (result.skippedKeys().isEmpty()) {
         sb.append("  None\n");
      } else {
         result.skippedKeys().forEach(key -> sb.append("  ⊗ ").append(key).append("\n"));
      }

      sb.append("\n========== SUMMARY ==========\n");
      sb.append("Total Processed: ").append(result.processedKeys().size()).append("\n");
      sb.append("Total Skipped: ").append(result.skippedKeys().size()).append("\n");

      fileResultArea.setText(sb.toString());

      showInfo(action + " completed successfully!\n\nOutput: " + result.outputFile());
   }

   // Key-Value Processing Actions

   @FXML
   private void handleEncryptKeyValue() {
      processKeyValue(true);
   }

   @FXML
   private void handleDecryptKeyValue() {
      processKeyValue(false);
   }

   private void processKeyValue(boolean encrypt) {
      String masterKey = kvMasterKeyField.getText();
      String input = kvInputTextArea.getText();

      if (masterKey == null || masterKey.trim().isEmpty()) {
         showError("Please enter master key");
         return;
      }

      if (input == null || input.trim().isEmpty()) {
         showError("Please enter key-value pairs or JSON");
         return;
      }

      // Show progress
      kvProgressIndicator.setVisible(true);
      kvResults.clear();

      // Process in background thread
      new Thread(() -> {
         try {
            int iterations = kvIterationsSpinner.getValue();

            EncryptionService encryptionService = new EncryptionService(masterKey, iterations);
            KeyValueProcessor processor = new KeyValueProcessor(encryptionService);

            List<KeyValuePair> results = processor.processInput(input, encrypt);

            // Update UI on JavaFX thread
            Platform.runLater(() -> {
               kvProgressIndicator.setVisible(false);
               displayKeyValueResults(results);
            });

         } catch (Exception e) {
            Platform.runLater(() -> {
               kvProgressIndicator.setVisible(false);
               showError("Processing failed: " + e.getMessage());
               e.printStackTrace();
            });
         }
      }).start();
   }

   private void displayKeyValueResults(List<KeyValuePair> results) {
      kvResults.clear();

      for (KeyValuePair pair : results) {
         kvResults.add(new KeyValueResult(
                 pair.key(),
                 pair.originalValue(),
                 pair.processedValue()
         ));
      }
   }

   @FXML
   private void handleCopyAll() {
      if (kvResults.isEmpty()) {
         showWarning("No results to copy");
         return;
      }

      StringBuilder sb = new StringBuilder();
      for (KeyValueResult result : kvResults) {
         sb.append(result.getKey())
                 .append("=")
                 .append(result.getProcessedValue())
                 .append("\n");
      }

      copyToClipboard(sb.toString());
      showInfo("All results copied to clipboard!");
   }

   @FXML
   private void handleCopySelected() {
      KeyValueResult selected = kvResultTable.getSelectionModel().getSelectedItem();
      if (selected == null) {
         showWarning("Please select a row to copy");
         return;
      }

      String text = selected.getKey() + "=" + selected.getProcessedValue();
      copyToClipboard(text);
      showInfo("Selected result copied to clipboard!");
   }

   @FXML
   private void handleClearKeyValue() {
      kvInputTextArea.clear();
      kvResults.clear();
   }

   private void copyToClipboard(String text) {
      ClipboardContent content = new ClipboardContent();
      content.putString(text);
      Clipboard.getSystemClipboard().setContent(content);
   }

   // Utility methods

   private void showError(String message) {
      Alert alert = new Alert(Alert.AlertType.ERROR);
      alert.setTitle("Error");
      alert.setHeaderText(null);
      alert.setContentText(message);
      alert.showAndWait();
   }

   private void showWarning(String message) {
      Alert alert = new Alert(Alert.AlertType.WARNING);
      alert.setTitle("Warning");
      alert.setHeaderText(null);
      alert.setContentText(message);
      alert.showAndWait();
   }

   private void showInfo(String message) {
      Alert alert = new Alert(Alert.AlertType.INFORMATION);
      alert.setTitle("Success");
      alert.setHeaderText(null);
      alert.setContentText(message);
      alert.showAndWait();
   }

   private void resetFileProcessingInputs() {
      filePathField.clear();
      masterKeyField.clear();
//      iterationsSpinner.getValueFactory().setValue(1000);
      environmentComboBox.setValue("dev");
      includeDataSourceUrlCheckBox.setSelected(false);
      defaultPatternsListView.getSelectionModel().selectAll();
//      customPatternsTextArea.clear();
   }

   // Inner class for table data
   public static class KeyValueResult {
      private final SimpleStringProperty key;
      private final SimpleStringProperty originalValue;
      private final SimpleStringProperty processedValue;

      public KeyValueResult(String key, String originalValue, String processedValue) {
         this.key = new SimpleStringProperty(key);
         this.originalValue = new SimpleStringProperty(originalValue);
         this.processedValue = new SimpleStringProperty(processedValue);
      }

      public String getKey() { return key.get(); }
      public String getOriginalValue() { return originalValue.get(); }
      public String getProcessedValue() { return processedValue.get(); }

      public SimpleStringProperty keyProperty() { return key; }
      public SimpleStringProperty originalValueProperty() { return originalValue; }
      public SimpleStringProperty processedValueProperty() { return processedValue; }
   }
}
