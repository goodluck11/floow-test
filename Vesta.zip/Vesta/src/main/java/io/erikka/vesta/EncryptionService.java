package io.erikka.vesta;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;

/*
 * @created by 16/02/2026 - 21:04
 * @project Vesta
 * @author Goodluck
 */
public class EncryptionService {
   private final PooledPBEStringEncryptor encryptor;

   public EncryptionService(String password, int iterations) {
      this.encryptor = new PooledPBEStringEncryptor();
      SimpleStringPBEConfig config = new SimpleStringPBEConfig();
      config.setPassword(password);
      config.setAlgorithm("PBEWITHHMACSHA512ANDAES_256");
      config.setKeyObtentionIterations(String.valueOf(iterations));
      config.setPoolSize("1");
      config.setProviderName("SunJCE");
      config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
      config.setIvGeneratorClassName("org.jasypt.iv.RandomIvGenerator");
      config.setStringOutputType("base64");
      encryptor.setConfig(config);
   }

   public String encrypt(String plainText) {
      if (plainText == null || plainText.trim().isEmpty()) {
         return plainText;
      }
      return encryptor.encrypt(plainText);
   }

   public String decrypt(String encryptedText) {
      if (encryptedText == null || encryptedText.trim().isEmpty()) {
         return encryptedText;
      }

      var text = encryptedText.trim();
      if (text.startsWith("ENC(") && text.endsWith(")")) {
         text = text.substring(4, text.length() - 1);
      }

      try {
         return encryptor.decrypt(text);
      } catch (Exception e) {
         throw new RuntimeException("Decryption failed: " + e.getMessage(), e);
      }
   }

   public boolean isEncrypted(String value) {
      if (value == null) return false;
      String trimmed = value.trim();
      return trimmed.startsWith("ENC(") && trimmed.endsWith(")");
   }
}
