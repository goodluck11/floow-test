The `CBQ Log` library can be configured either via Spring Boot properties (`application.properties` or `application.yml`) or programmatically using the fluent builder.

#### 1. Spring Boot Properties (`application.properties`)

Below is a complete sample of all available properties with their default values and descriptions.

```properties
# --- General Settings ---
# Service name to identify the source of logs
cbq.log.service-name=app
# Log format: JSON (default), TEXT, PRETTY, or PRETTY_TEXT
cbq.log.format=JSON
# Whether to use non-blocking asynchronous logging
cbq.log.async=true
# Environment name (e.g., production, staging, dev)
cbq.log.environment=default

# --- Masking Settings ---
# Fields to be masked globally across all logs (case-insensitive)
cbq.log.mask-fields=password,cvv,creditCard,iban,accountNumber
# Predefined masking profiles: PCI, GDPR, HIPAA, KONG, AUTH, NIGERIA_FINTECH
cbq.log.mask-profiles=PCI,KONG
# Specific JSON paths to mask (e.g., user.identity.ssn)
cbq.log.mask-json-paths=user.credentials.password,payment.card.cvv
# Character used for masking
cbq.log.mask-symbol=*
# Number of leading characters to keep visible
cbq.log.left-visible=0
# Number of trailing characters to keep visible
cbq.log.right-visible=0
# If true, forces full masking in production even if visible chars are set
cbq.log.prod-mask-override=false

# --- Context & MDC ---
# MDC key for Correlation ID
cbq.log.correlation-key=cid
# MDC key for Request ID
cbq.log.request-id-key=rid
# List of custom MDC fields to include in structured logs
cbq.log.mdc-fields=user_id,account_type,trace_id
# Whether to include class/method/line information (expensive)
cbq.log.include-caller-info=false

# --- Performance & Bounds ---
# Maximum size for log bodies before truncation (bytes)
cbq.log.max-body-size=4096
# Threshold for marking DB/Task operations as slow (ms)
cbq.log.slow-query-threshold-ms=500
# Default sampling rate (1.0 = 100%, 0.01 = 1%)
cbq.log.default-sample-rate=1.0

# --- Async Executor Settings (only used if async=true and pre-Java 21) ---
cbq.log.async-core-pool-size=2
cbq.log.async-max-pool-size=10
cbq.log.async-queue-capacity=1000
```

#### 2. YAML Configuration (`application.yml`)

```yaml
cbq:
  log:
    service-name: "payment-gateway"
    format: "PRETTY_TEXT"
    async: true
    environment: "production"
    mask-fields:
      - "password"
      - "cvv"
      - "secretKey"
    mask-profiles:
      - "PCI"
      - "AUTH"
    mask-json-paths:
      - "request.payload.card.number"
    left-visible: 4
    right-visible: 4
    mdc-fields:
      - "tenant_id"
      - "user_role"
    async-max-pool-size: 20
    slow-query-threshold-ms: 1000
```

#### 3. Programmatic Configuration (Fluent Builder)

For non-Spring applications or manual setup:

```java
import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.cbq.log.mask.MaskProfile;

CbqLogConfig config = CbqLogConfig.builder()
    .serviceName("order-service")
    .prettyTextFormat()          // Use boxed output format
    .async(true)
    .environment("production")
    .maskProfile(MaskProfile.PCI)
    .maskFields("apiKey", "token")
    .leftVisible(4)
    .rightVisible(4)
    .mdcFields("correlationId", "requestId", "userId")
    .asyncMaxPoolSize(15)
    .slowQueryThresholdMs(300)
    .build();

CbqLog.configure(config);
```
---
## Benchmarking
```java
@Test
   void benchmarkLoggingThroughput() {
      CbqLog log = CbqLog.getLogger(AsyncLogWriterTest.class);
      int totalLogs = 100_000;
      long start = System.currentTimeMillis();

      for (int i = 0; i < totalLogs; i++) {
         log.info("BENCHMARK: Payment processed for ", "account",
                 "ACC123456", "amount", 150.75);
      }

      long duration = System.currentTimeMillis() - start;
      double logsPerSecond = (totalLogs / (double) duration) * 1000;

      System.out.println("--- LOGGING BENCHMARK RESULTS ---");
      System.out.println("Total Time: " + duration + "ms");
      System.out.println("Throughput: " + (int) logsPerSecond + " logs/sec");
   }

    @Test
    void benchmarkRealSustainedThroughput() throws InterruptedException {
        int totalLogs = 100_000;
        CountDownLatch latch = new CountDownLatch(totalLogs);
        CbqLog log = CbqLog.getLogger(AsyncLogWriterTest.class);

        long start = System.currentTimeMillis();

        for (int i = 0; i < totalLogs; i++) {
            AsyncLogWriter.submit(() -> {
                try {
                    log.info("FINANCIAL_LOG: TX_ID={}, STATUS={}", "TXN-9902", "SUCCESS");
                } catch (Exception e) {
                    e.printStackTrace(); // See if it's failing internally
                } finally {
                    latch.countDown();
                }
            });
            if (i % 10000 == 0) System.out.println("Submitted " + i);
        }

        // This is the important part: Wait for the workers to finish!
        latch.await(30, TimeUnit.SECONDS);


        long duration = System.currentTimeMillis() - start;

        double logsPerSecond = (totalLogs / (double) duration) * 1000;

        System.out.println("\n--- SUSTAINED THROUGHPUT RESULTS ---");
        System.out.println("Total Logs Processed: " + totalLogs);
        System.out.println("Time to Persist:      " + duration + "ms");
        System.out.println("Actual Throughput:    " + (int) logsPerSecond + " logs/sec");

        if (latch.getCount() > 0) {
            System.err.println("WARNING: Test timed out! Remaining logs in queue: " + latch.getCount());
        }
    }
```

* Health Indicators:
* - backpressure_events == 0: System in normal operation
* - queue_full_events > 0: System self-regulating under load
* - avg_latency: Should be ~(avg_io_time + small_queue_wait)
* - If backpressure_events > 0: Consider increasing pool size
* - If queue_full_events == 0 and avg_latency < io_time: Under-utilized

### Visualizing What Happened
```
Queue Status Over Time:
[   25% full] → Producers faster
[   75% full] → Building up
[  100% full] → 🔴 Queue full! Producers wait
[   80% full] → Consumers catch up
[  100% full] → 🔴 Queue full again
... repeats ...

This is PERFECT behavior - the system self-regulates!

```