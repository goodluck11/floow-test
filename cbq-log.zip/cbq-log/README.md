# CBQ Log

Structured logging library for Java 17+ with field masking, DB performance tracking, and gateway support.

**~2,000 lines** · **Thin JAR** · **2 required deps** (SLF4J + Jackson) · **Everything else optional**

## Dependencies

Required: `slf4j-api`, `jackson-databind`

Optional (only needed if you use the feature):

| Feature | Dependency | When needed |
|---|---|---|
| Spring Boot auto-config | `spring-boot-autoconfigure` | `application.yml` config |
| R2DBC tracking | `r2dbc-spi`, `reactor-core` | Reactive DB logging |
| Micrometer metrics | `micrometer-core` | `LogMetrics.bindTo()` |

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-log</artifactId>
    <version>1.0.0</version>
</dependency>
```

---

## 1. Core Logging

### Get a logger

```java
// Manual
private static final CbqLog log = CbqLog.getLogger(PaymentService.class);

// Or with Lombok @CustomLog (add to lombok.config):
// lombok.log.custom.declaration=com.cbq.log.core.CbqLog com.cbq.log.core.CbqLog.getLogger(TYPE)
```

### Log methods

```java
// Simple message
log.info("server started");

// With payload object (auto-serialized to JSON, @MaskSensitive fields masked)
log.info("order created", order);

// Structured key-value pairs
log.info("payment processed", "orderId", orderId, "amount", amount, "currency", "NGN");

// With exception
log.error("payment failed", ex);
log.error("payment failed", payment, ex);

// Task timing (type, operation, target, duration_ms, success)
log.task("db", "insert", "orders", 45, true);

// Audit (always sync, never sampled, includes caller class:line)
log.audit("funds transferred", transfer);
```

### Sampling

```java
log.sampled(0.01).info("high-frequency event", data);  // logs 1% of calls
log.sampled(0.1).debug("request trace", payload);       // logs 10%
```

---

## 2. Field Masking

### Annotation-based

```java
public class PaymentRequest {
    private String orderId;

    @MaskSensitive                          // → "************"
    private String cardNumber;

    @MaskSensitive(visibleChars = 4)        // → "************4242"
    private String accountNumber;

    @MaskSensitive(fullyMask = true)        // → "************"
    private String cvv;
}

log.info("processing payment", paymentRequest);
// cardNumber, cvv, accountNumber masked automatically in JSON output
```

### Mask profiles (predefined field sets)

```java
CbqLog.configure(CbqLogConfig.builder()
        .maskProfile(MaskProfile.PCI)              // cardNumber, cvv, pin, track1, track2...
        .maskProfile(MaskProfile.NIGERIA_FINTECH)  // bvn, nin, nuban, msisdn...
        .maskProfile(MaskProfile.KONG_GATEWAY)     // Authorization, X-API-Key, Cookie...
        .build());
```

Available profiles: `PCI`, `GDPR`, `HIPAA`, `KONG_GATEWAY`, `AUTH`, `NIGERIA_FINTECH`.

### JSON path masking (for third-party DTOs you can't annotate)

```java
CbqLog.configure(CbqLogConfig.builder()
        .maskJsonPaths("response.data.bvn", "payment.card.pan")
        .build());
```

### Environment-conditional masking

```java
CbqLog.configure(CbqLogConfig.builder()
        .environment("production")
        .prodMaskOverride(true)  // forces visibleChars=0 in prod
        .build());
// Dev:  accountNumber → "************4242"
// Prod: accountNumber → "****************"
```

---

## 3. Timed Operations

```java
// AutoCloseable — auto-logs duration and success/failure on close
try (var op = TimedOp.start(log, "http", "callPartner", "flutterwave")) {
    var response = restClient.post(request);
    op.detail("status=" + response.status());
}
// → {"task_type":"http","operation":"callPartner","target":"flutterwave","duration_ms":230,"success":true}

// One-liner for simple operations
TimedOp.run(log, "cache", "set", "sessions", () -> redis.put(key, value));
User user = TimedOp.call(log, "db", "findById", "users", () -> repo.findById(id));
```

---

## 4. DB Performance Tracking

### JDBC (non-reactive)

```java
@Bean
public DataSource dataSource(DataSource original) {
    return DbLogProxyDataSource.wrap(original);          // default threshold
    // or: DbLogProxyDataSource.wrap(original, 200);     // 200ms slow query threshold
}
```

**What gets logged automatically:**

```
pool.acquire  → {"event":"pool.acquire","wait_ms":3,"correlation_id":"abc-123"}
query         → {"operation":"select","duration_ms":12,"sql":"SELECT * FROM users..."}  (slow only)
pool.release  → {"event":"pool.release","hold_ms":45,"acquire_wait_ms":3,"correlation_id":"abc-123"}
```

Every event carries the `correlation_id` of the HTTP request that acquired the connection — even if `close()` runs on a different thread.

### R2DBC (reactive)

```java
@Bean
public DatabaseClient databaseClient(ConnectionFactory connectionFactory) {
    return DatabaseClient.builder()
            .connectionFactory(R2dbcLogListener.wrap(connectionFactory))
            .build();
}
```

**What gets logged automatically (zero changes to your repositories):**

```
pool.acquire  → {"event":"pool.acquire","wait_ms":2,"correlation_id":"abc-123","client_ip":"10.0.0.1"}
query         → {"operation":"select","duration_ms":8,"sql":"SELECT * FROM posts"}
pool.release  → {"event":"pool.release","hold_ms":12,"acquire_wait_ms":2,"correlation_id":"abc-123"}
```

Your repository code stays clean:

```java
public Flux<Post> findAll() {
    return databaseClient
            .sql("SELECT * FROM posts")
            .map(this::mapRowToPost)
            .all();
    // ↑ acquire, query, release all logged automatically
}
```

**Optional: explicit query timing at the Flux/Mono level**

```java
// observe() wraps the Flux with doOnComplete/doOnError timing hooks
public Flux<Post> findAll() {
    return R2dbcLogListener.observe("SELECT * FROM posts",
        databaseClient.sql("SELECT * FROM posts").map(this::mapRowToPost).all());
}

// Works for Mono too
public Mono<Post> findById(Long id) {
    return R2dbcLogListener.observe("SELECT * FROM posts WHERE id = :id",
        databaseClient.sql("SELECT * FROM posts WHERE id = :id")
            .bind("id", id).map(this::mapRowToPost).one());
}
```

---

## 5. Correlation & Context

### Non-reactive (servlet, MDC-based)

```java
// In a servlet filter or interceptor
LogContext.setCorrelationId(request.getHeader("X-Correlation-ID"));
LogContext.newRequestId();
GatewayContext.extract(request::getHeader);

// All subsequent log calls on this thread include correlation_id, client_ip, etc.
log.info("processing request", order);

// Propagate to async threads
executor.submit(LogContext.wrap(() -> doWork()));
CompletableFuture.supplyAsync(LogContext.wrapSupplier(() -> compute()), pool);
```

### Reactive (WebFlux, Reactor Context)

MDC doesn't work in reactive — use Reactor Context instead:

```java
@Component
public class LoggingWebFilter implements WebFilter {
    private static final CbqLog log = CbqLog.getLogger(LoggingWebFilter.class);

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        long start = System.nanoTime();
        var request = exchange.getRequest();
        var method = request.getMethod().name();
        var path = request.getPath().value();

        var corrId = request.getHeaders().getFirst("X-Correlation-ID");
        if (corrId == null) corrId = UUID.randomUUID().toString();
        var reqId = UUID.randomUUID().toString();

        // Extract gateway headers as a plain map (no MDC)
        var gwCtx = GatewayContext.extractMap(request.getHeaders()::getFirst);

        return chain.filter(exchange)
                // These propagate through the entire reactive chain
                .contextWrite(R2dbcLogListener.contextWrite(corrId, reqId))
                .contextWrite(ctx -> ctx.put(GatewayContext.REACTOR_CTX_KEY, gwCtx))
                .doOnSuccess(v -> {
                    long ms = (System.nanoTime() - start) / 1_000_000;
                    int status = exchange.getResponse().getStatusCode() != null
                            ? exchange.getResponse().getStatusCode().value() : 500;
                    log.info("HTTP request completed",
                            "method", method, "path", path, "status", status,
                            "duration_ms", ms, "correlation_id", corrId,
                            "client_ip", gwCtx.get("client_ip"),
                            "ua_platform", gwCtx.get("ua_platform"));
                })
                .doOnError(err ->
                    log.error("HTTP request failed",
                            "method", method, "path", path,
                            "error", err.getMessage(), "correlation_id", corrId)
                );
    }
}
```

R2dbcLogListener automatically reads `correlation_id`, `request_id`, and gateway context from Reactor Context — so all DB logs within that request carry the same IDs.

---

## 6. Gateway & User-Agent

### Non-reactive

```java
GatewayContext.extract(request::getHeader);
// Populates MDC with: client_ip, user_agent, ua_platform, gateway.consumer, gateway.route, etc.
```

### Reactive

```java
var gwCtx = GatewayContext.extractMap(request.getHeaders()::getFirst);
// Returns Map — store in Reactor Context (see WebFilter above)
```

**Headers detected:** `X-Real-IP`, `X-Forwarded-For`, `CF-Connecting-IP`, `X-Consumer-Username`, `X-Kong-Route-Name`, `X-Kong-Service-Name`, `X-Kong-Request-ID`, `X-Request-ID`, `User-Agent`

**User-Agent platforms detected:** `flutter` (Dart/dio), `android` (okhttp), `ios` (CFNetwork), `postman`, `curl`, `python`, `nodejs` (axios/node-fetch), `browser`

---

## 7. Event Hooks

```java
// Alert on every error
LogEventBus.onError(event -> slackAlert(event));

// Alert on slow operations (> 1 second)
LogEventBus.onSlowOp(1000, event -> pagerDuty(event));

// Custom: DB failures only
var sub = LogEventBus.on("task_type", "db",
    event -> !((boolean) event.get("success")),
    event -> metrics.increment("db.failures"));

// Unsubscribe
sub.cancel();
```

All listeners execute asynchronously — never block the logging thread.

---

## 8. Metrics

```java
// Get a snapshot of all counters
Map<String, Object> stats = LogMetrics.snapshot();
// {"trace":0,"debug":45,"info":1034,"warn":12,"error":3,
//  "db.pool.acquire":{"count":500,"failures":2,"total_ms":1500,"avg_ms":3,"slow":5},
//  "r2dbc.select":{"count":200,"failures":1,"total_ms":2400,"avg_ms":12,"slow":3}}

// Optional: bind to Micrometer (if on classpath)
LogMetrics.bindTo(meterRegistry);
// Registers gauges: cbq.log.count{level=info}, cbq.log.count{level=error}, etc.
```

---

## 9. Spring Boot Configuration

```yaml
cbq:
  log:
    service-name: payment-service
    format: JSON                    # JSON or TEXT
    async: true                     # virtual thread async logging
    environment: ${SPRING_PROFILES_ACTIVE:default}
    mask-fields: customField1,customField2
    mask-profiles: PCI,KONG_GATEWAY,NIGERIA_FINTECH
    mask-json-paths: response.data.bvn,payment.card.pan
    prod-mask-override: true
    slow-query-threshold-ms: 500
    default-sample-rate: 1.0        # 1.0 = log everything
```

---

## 10. Non-Spring Usage

CbqLog works without Spring. Configure programmatically:

```java
CbqLog.configure(CbqLogConfig.builder()
        .serviceName("payment-service")
        .format(CbqLogConfig.Format.JSON)
        .async(true)
        .maskProfile(MaskProfile.PCI)
        .maskProfile(MaskProfile.NIGERIA_FINTECH)
        .environment("production")
        .prodMaskOverride(true)
        .slowQueryThresholdMs(500)
        .build());

CbqLog log = CbqLog.getLogger("com.myapp.PaymentService");
```

---

## Package Overview

```
com.cbq.log
├── core/           CbqLog                          — main logger
├── config/         CbqLogConfig                    — builder-based configuration
├── context/        LogContext                       — MDC correlation + thread propagation
├── mask/           MaskEngine, MaskProfile,         — field masking engine
│                   @MaskSensitive
├── format/         JsonLogFormatter,                — output formatting
│                   TextLogFormatter
├── async/          AsyncLogWriter                   — virtual thread writer
├── db/             DbLogProxyDataSource,            — JDBC proxy
│                   R2dbcLogListener                 — R2DBC wrapper
├── gateway/        GatewayContext                   — Kong/proxy/User-Agent extraction
├── timed/          TimedOp                          — AutoCloseable operation timer
├── sampling/       LogSampler                       — zero-cost log sampling
├── event/          LogEventBus, LogEventListener    — async log event hooks
├── metrics/        LogMetrics                       — lock-free counters + Micrometer
└── autoconfigure/  CbqLogAutoConfiguration          — Spring Boot auto-config
```
