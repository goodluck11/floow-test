# CBQ Log - Comprehensive Guide

`cbq-log` is a high-performance, structured logging library for Java applications, specifically designed for systems requiring strict data masking (PCI, PII), asynchronous efficiency, and deep observability.

---

### 1. Core Logging API

`CbqLog` provides multiple ways to log data, balancing developer ergonomics with structured output.

#### SLF4J-style Placeholders `{}`
The most common way to log. Efficiently formats messages and handles trailing Payloads or Throwables.
```java
private static final CbqLog log = CbqLog.getLogger(MyService.class);

// Simple message with parameters
log.info("Order {} processed for user {}", orderId, user);

// With trailing Throwable (extracted as 'error' field in structured output)
try {
    processOrder(order);
} catch (Exception ex) {
    log.error("Failed to process order {}", orderId, ex);
}

// With trailing Object as payload (captured in 'data' field)
log.info("Status of {} updated", itemId, metadataMap);
```

#### Structured Key-Value Logging (`Kv`)
Ideal for logs that need to be easily queryable in ELK or Splunk.
```java
log.infoKv("transaction completed", 
    "txId", txId, 
    "amount", 1500.0, 
    "currency", "USD"
);
```

#### Single Object Logging
Logs a single String, Map, or POJO directly. Masking is automatically applied.
```java
log.info(myPojo); // Full POJO masked and logged as JSON
log.info(myMap);  // Map masked and logged
log.info("Simple status message"); // Logged as 'message'

// JSON String Detection
// If a string looks like JSON, the library parses and masks it automatically
log.info("{\"password\": \"secret123\", \"user\": \"admin\"}");
```

---

### 2. Annotation-Driven Masking

One of the library's core strengths is protecting sensitive data via the `MaskEngine`.

#### `@MaskSensitive`
Annotate fields in your POJOs to ensure they never leak into logs.
```java
public class User {
    private String name;
    
    // Partial masking: Output: 12******90
    @MaskSensitive(leftVisible = 2, rightVisible = 2)
    private String accountNumber; 
    
    // Full masking: Output: ***
    @MaskSensitive(fullyMask = true)
    private String cvv; 
}
```

#### Global & Path-based Masking
You can also mask by field names or JSON paths globally via configuration.
- **Field-based**: Masks any field named `password` or `secret` regardless of where it appears (even in Maps or nested JSON).
- **Path-based**: Masks specific paths in JSON structures, e.g., `payment.card.number`.

---

### 3. Configuration & Production Readiness

Configuration is managed via `CbqLogConfig`. It is thread-safe and can be updated at runtime.

#### The Builder
```java
CbqLogConfig config = CbqLogConfig.builder()
    .serviceName("payment-gateway")
    .async(true)                      // Enable async logging
    .asyncQueueCapacity(10000)        // Large queue for spikes
    .maskProfile(MaskProfile.PCI)     // Pre-defined masking rules
    .maskFields("apiKey", "token")    // Custom global sensitive fields
    .maskJsonPaths("user.ssn")        // Specific JSON paths to mask
    .environment("production")        // Forces masking rules
    .jsonFormat()                     // Optimized JSON output
    .build();

CbqLog.configure(config);
```

#### Best Practices for Production
- **Async Mode**: Always use `async(true)` in performance-critical apps. It uses **Virtual Threads** automatically on Java 21+.
- **Backpressure**: The library uses a `CallerRunsPolicy`. If the queue is full, the calling thread will execute the log write, providing natural backpressure and ensuring no logs are lost.
- **Sampling**: Use `.sampled(rate)` for high-frequency events to reduce I/O.
```java
log.sampled(0.01).info("Heartbeat data", stats); // Only logs 1% of the time
```

---

### 4. Asynchronous Logging & Metrics

The `AsyncLogWriter` handles background processing using a shared executor.

#### Monitoring Health
Monitor your logging performance via `LogMetrics`:
- **Submit Count**: Total logs submitted to the async system.
- **Avg Latency**: hand-off time from application to the logging background.
- **Backpressure Events**: Indicates when the system is under heavy load.
- **Queue Status**: Current and peak queue depth.

#### Micrometer Integration
Expose logging metrics to Prometheus/Grafana:
```java
LogMetrics.bindTo(meterRegistry);
```
Available gauges: `cbq.async.submit.avg.latency`, `cbq.async.backpressure.events`, `cbq.async.queue.current.size`, etc.

---

### 5. Log Event Bus (Alerting & Interception)

React to log events programmatically without blocking the main application flow.

```java
// Alert on all ERROR level events
LogEventBus.onError(event -> slackClient.send(event));

// Custom filter: Capture slow database operations
LogEventBus.on(
    e -> "task".equals(e.get("type")) && "db".equals(e.get("task_type")) && (long)e.get("duration_ms") > 500,
    e -> alertService.notifySlowDb(e)
);

// Listeners are executed asynchronously on the virtual thread pool.
```

---

### 6. Specialized Logging Tasks

#### Task Performance
Record duration and success for specific operations. Automatically tracked in metrics.
```java
log.task("db", "select", "users_table", durationMs, true, "Optional query detail");
```

#### HTTP Request/Response
Built-in support for HTTP logging with automatic header masking (e.g., `Authorization`).
```java
log.httpRequest("POST", "/v1/charges", headers, requestBody);
log.httpResponse("POST", "/v1/charges", 201, durationMs, responseBody);
```

#### Database Proxy Logging
Wrap your `DataSource` with `DbLogProxyDataSource` to automatically log all SQL queries, their durations, and results.
```java
DataSource proxyDs = DbLogProxyDataSource.wrap(actualDataSource);
```
It tracks metrics like `db.select`, `db.insert`, `db.pool.acquire` automatically.

---

### 7. Context Propagation (MDC)

`CbqLog` correctly propagates `MDC` even in asynchronous mode.

- **Correlation/Request IDs**: Handled via `LogContext`.
- **Custom MDC**: Configure `mdcFields` in `CbqLogConfig` to include specific MDC keys in every structured log entry.

```java
MDC.put("user_id", "123");
log.info("Action performed"); // Resulting JSON includes "user_id": "123"
```
