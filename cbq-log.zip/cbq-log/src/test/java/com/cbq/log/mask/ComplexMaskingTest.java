package com.cbq.log.mask;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ComplexMaskingTest {

   @BeforeEach
   void setUp() {
      CbqLog.configure(CbqLogConfig.defaults());
   }

   @Test
   void testJsonListMasking() {
      String json = """
              [
                {
                  "userId": "usr_99210",
                  "fullName": "Marcus Aurelius",
                  "username": "marcus_gladiator",
                  "password": "hashed_password_8821x",
                  "accountNumber": "8822991023",
                  "iban": "GB29NWBK60161331926819",
                  "cardNumber": "4532-1190-8842-1002",
                  "cvv": "442",
                  "expiryDate": "12/27",
                  "status": "active"
                }
              ]
              """;

      Set<String> fieldsToMask = Set.of("password", "accountNumber", "iban", "cardNumber", "cvv");
      String maskedJson = MaskEngine.maskJson(json, fieldsToMask, '*');
      System.out.println("--- testJsonListMasking Masked Result ---");
      System.out.println(maskedJson);

      // Verify masking
      assertTrue(maskedJson.contains("\"password\":\"" + "*".repeat(21) + "\""));
      assertTrue(maskedJson.contains("\"accountNumber\":\"" + "*".repeat(10) + "\""));
      assertTrue(maskedJson.contains("\"iban\":\"" + "*".repeat(22) + "\""));
      assertTrue(maskedJson.contains("\"cardNumber\":\"" + "*".repeat(19) + "\""));
      assertTrue(maskedJson.contains("\"cvv\":\"" + "*".repeat(3) + "\""));

      // Verify non-masked fields
      assertTrue(maskedJson.contains("\"userId\":\"usr_99210\""));
      assertTrue(maskedJson.contains("\"fullName\":\"Marcus Aurelius\""));
      assertTrue(maskedJson.contains("\"status\":\"active\""));
   }

   @Test
   void testNestedJsonAndListMasking() {
      String json = """
              {
                "metadata": {
                  "totalCount": 1,
                  "page": 1,
                  "requestTimestamp": "2026-02-13T12:40:00Z"
                },
                "accounts": [
                  {
                    "accountType": "Savings",
                    "balance": 12550.50,
                    "currency": "USD",
                    "accountNumber": "100044921",
                    "iban": "US89CHAS11002233445566",
                    "linkedCard": {
                      "cardNumber": "5521-4400-9921-3341",
                      "cvv": "109",
                      "provider": "MasterCard"
                    }
                  }
                ]
              }
              """;

      // Test field-based masking (recursive)
      Set<String> fieldsToMask2 = Set.of("accountNumber", "iban", "cardNumber", "cvv");
      String maskedJson2 = MaskEngine.maskJson(json, fieldsToMask2, '*');
      System.out.println("--- testNestedJsonAndListMasking (Field-based) Masked Result ---");
      System.out.println(maskedJson2);

      assertTrue(maskedJson2.contains("\"accountNumber\":\"*********\""));
      assertTrue(maskedJson2.contains("\"iban\":\"" + "*".repeat(22) + "\""));
      assertTrue(maskedJson2.contains("\"cardNumber\":\"" + "*".repeat(19) + "\""));
      assertTrue(maskedJson2.contains("\"cvv\":\"***\""));

      // Test JsonPath-based masking
      CbqLog.configure(CbqLogConfig.builder()
              .prettyFormat()
              .leftVisible(4)
              .maskJsonPaths("accounts.accountNumber", "accounts.linkedCard.cvv")
              .build());

      String pathMaskedJson = MaskEngine.maskJson(json, Set.of("iban"), Set.of("accounts.accountNumber", "accounts.linkedCard.cvv"), '*');
      System.out.println("--- testNestedJsonAndListMasking (Path-based) Masked Result ---");
      System.out.println(pathMaskedJson);

      // Verify that accountNumber (9 digits) has 4 visible chars
      // Actually accountNumber is "100044921", leftVisible(4) should show "1000"
      assertTrue(pathMaskedJson.contains("\"accountNumber\" : \"1000*****\""), "accountNumber should have 4 visible chars");
      
      // Verify that cvv (3 digits) is FULLY masked because it's shorter than leftVisible(4)
      assertTrue(pathMaskedJson.contains("\"cvv\" : \"***\""), "cvv should be fully masked because length (3) < leftVisible (4)");

      // Verify non-masked in path-based
      assertTrue(pathMaskedJson.contains("\"iban\" : \"US89******************\""), "iban should have 4 visible chars because it was in fields set but not in path set");
   }

   @Test
   void testDeeplyNestedJsonMasking() {
      String json = """
              {
                "userProfile": {
                  "identity": {
                    "firstName": "Elena",
                    "lastName": "Rossi",
                    "credentials": {
                      "username": "erossi_dev",
                      "password": "argon2_id_99210055",
                      "lastPasswordChange": "2025-11-20"
                    }
                  },
                  "financials": {
                    "primaryBank": {
                      "bankName": "Global Trust",
                      "accountNumber": "772211003",
                      "iban": "IT55L0200805000000044332211",
                      "securityCode": "9910"
                    },
                    "activeMethods": {
                      "creditCard": {
                        "cardNumber": "3782-441029-31002",
                        "cvv": "882",
                        "type": "Amex",
                        "billingAddress": "123 Via Roma, Milan, Italy"
                      }
                    }
                  },
                  "preferences": {
                    "mfaEnabled": true,
                    "notificationType": "SMS"
                  }
                }
              }
              """;

      Set<String> fieldsToMask3 = Set.of("password", "accountNumber", "iban", "securityCode", "cardNumber", "cvv");
      String maskedJson3 = MaskEngine.maskJson(json, fieldsToMask3, '*');
      System.out.println("--- testDeeplyNestedJsonMasking (Field-based) Masked Result ---");
      System.out.println(maskedJson3);

      assertTrue(maskedJson3.contains("\"password\":\"" + "*".repeat(18) + "\""));
      assertTrue(maskedJson3.contains("\"accountNumber\":\"" + "*".repeat(9) + "\""));
      assertTrue(maskedJson3.contains("\"securityCode\":\"****\""));
      assertTrue(maskedJson3.contains("\"cvv\":\"***\""));

      // Test with JsonPaths
      Set<String> paths = Set.of(
              "userProfile.identity.credentials.password",
              "userProfile.financials.primaryBank.accountNumber",
              "userProfile.financials.activeMethods.creditCard.cardNumber"
      );
      String pathMasked = MaskEngine.maskJson(json, Set.of(), paths, '*');
      System.out.println("--- testDeeplyNestedJsonMasking (Path-based) Masked Result ---");
      System.out.println(pathMasked);

      assertTrue(pathMasked.contains("\"password\":\"" + "*".repeat(18) + "\""));
      assertTrue(pathMasked.contains("\"accountNumber\":\"" + "*".repeat(9) + "\""));
      assertTrue(pathMasked.contains("\"cardNumber\":\"" + "*".repeat(17) + "\""));
   }

   @Test
   void testEfficiencyAndCleanJson() {
      String jsonStr = """
              {
                "user": "Marcus",
                "secrets": ["pass1", "pass2"],
                "nested": {
                   "deep": "secret_value"
                }
              }
              """;

      long start = System.nanoTime();
      String masked = MaskEngine.maskJson(jsonStr, Set.of("user", "deep"), Set.of("secrets"), '*');
      long end = System.nanoTime();

      System.out.println("--- testEfficiencyAndCleanJson Masked Result ---");
      System.out.println(masked);
      System.out.println("[DEBUG_LOG] Masking took " + (end - start) / 1000 + " us");

      // Clean JSON check: no escaped quotes outside what's normal
      assertFalse(masked.contains("\\\""), "Masked JSON should not contain escaped quotes");
      assertTrue(masked.startsWith("{"), "Should be a valid JSON object");

      // Verify array masking via path
      assertTrue(masked.contains("\"secrets\":[\"*****\",\"*****\"]"));
      assertTrue(masked.contains("\"user\":\"******\""));
      assertTrue(masked.contains("\"deep\":\"************\""));
   }

   @Test
   void testNestedArrayObjectsMasking() {
      String json = """
              {
                "organization": "FinancialCorp",
                "departments": [
                  {
                    "name": "Wealth Management",
                    "clients": [
                      {
                        "name": "Alice",
                        "taxId": "TAX-123456",
                        "accounts": ["ACC-111", "ACC-222"]
                      },
                      {
                        "name": "Bob",
                        "taxId": "TAX-987654",
                        "accounts": ["ACC-333"]
                      }
                    ]
                  }
                ]
              }
              """;

      CbqLog.configure(CbqLogConfig.builder()
              .leftVisible(2)
              .maskJsonPaths("departments.clients.taxId", "departments.clients.accounts")
              .build());

      String masked = MaskEngine.maskJson(json, Set.of(), Set.of("departments.clients.taxId", "departments.clients.accounts"), '*');
      System.out.println("--- testNestedArrayObjectsMasking Result ---");
      System.out.println(masked);

      // Verify taxId: "TAX-123456" (10 chars), leftVisible 2 -> "TA********"
      assertTrue(masked.contains("\"taxId\":\"TA********\""));
      assertTrue(masked.contains("\"taxId\":\"TA********\""));

      // Verify accounts array: "ACC-111" (7 chars) -> "AC*****"
      assertTrue(masked.contains("\"accounts\":[\"AC*****\",\"AC*****\"]"));
      assertTrue(masked.contains("\"accounts\":[\"AC*****\"]"));

      // Verify non-masked
      assertTrue(masked.contains("\"organization\":\"FinancialCorp\""));
      assertTrue(masked.contains("\"name\":\"Alice\""));
   }

   @Test
   void testEdgeCases() {
      // 1. Empty string
      assertEquals("\"\"", MaskEngine.maskJson("\"\"", Set.of("any"), '*'));
      
      // 2. Short string vs visibility
      CbqLog.configure(CbqLogConfig.builder().leftVisible(10).build());
      String shortVal = "short"; // length 5
      assertEquals("*****", MaskEngine.maskValue(shortVal, '*', 10, 0, false));
      
      // 3. Null handling
      assertNull(MaskEngine.maskValue(null, '*', 0, 0, false));
      
      // 4. Object with no fields to mask
      String clean = "{\"a\":1}";
      assertEquals(clean, MaskEngine.maskJson(clean, Set.of("b"), '*'));
      
      // 5. Very long string
      String longStr = "A".repeat(100);
      String maskedLong = (String) MaskEngine.maskValue(longStr, '*', 10, 10, false);
      assertEquals("A".repeat(10) + "*".repeat(80) + "A".repeat(10), maskedLong);
   }
}
