package com.cbq.log.mask.model;

import com.cbq.log.mask.MaskSensitive;
import lombok.Data;

@Data
public class UserProfilePayload {
    private UserProfile userProfile;

    public void setUserProfile(UserProfile userProfile) { this.userProfile = userProfile; }

    @Data
    public static class UserProfile {
        private Identity identity;
        private Financials financials;
        private Preferences preferences;

        public void setIdentity(Identity identity) { this.identity = identity; }
        public void setFinancials(Financials financials) { this.financials = financials; }
        public void setPreferences(Preferences preferences) { this.preferences = preferences; }
    }

    @Data
    public static class Identity {
        private String firstName;
        private String lastName;
        private Credentials credentials;

        public void setFirstName(String firstName) { this.firstName = firstName; }
        public void setLastName(String lastName) { this.lastName = lastName; }
        public void setCredentials(Credentials credentials) { this.credentials = credentials; }
    }

    @Data
    public static class Credentials {
        private String username;
        
        @MaskSensitive
        private String password;
        
        private String lastPasswordChange;

        public void setUsername(String username) { this.username = username; }
        public void setPassword(String password) { this.password = password; }
        public void setLastPasswordChange(String lastPasswordChange) { this.lastPasswordChange = lastPasswordChange; }
    }

    @Data
    public static class Financials {
        private PrimaryBank primaryBank;
        private ActiveMethods activeMethods;

        public void setPrimaryBank(PrimaryBank primaryBank) { this.primaryBank = primaryBank; }
        public void setActiveMethods(ActiveMethods activeMethods) { this.activeMethods = activeMethods; }
    }

    @Data
    public static class PrimaryBank {
        private String bankName;
        
        @MaskSensitive(rightVisible = 3)
        private String accountNumber;
        
        @MaskSensitive(leftVisible = 4, rightVisible = 4)
        private String iban;
        
        @MaskSensitive(fullyMask = true)
        private String securityCode;

        public void setBankName(String bankName) { this.bankName = bankName; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
        public void setIban(String iban) { this.iban = iban; }
        public void setSecurityCode(String securityCode) { this.securityCode = securityCode; }
    }

    @Data
    public static class ActiveMethods {
        private CreditCard creditCard;

        public void setCreditCard(CreditCard creditCard) { this.creditCard = creditCard; }
    }

    @Data
    public static class CreditCard {
        @MaskSensitive(leftVisible = 4, rightVisible = 4)
        private String cardNumber;
        
        @MaskSensitive(fullyMask = true)
        private String cvv;
        
        private String type;
        private String billingAddress;

        public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
        public void setCvv(String cvv) { this.cvv = cvv; }
        public void setType(String type) { this.type = type; }
        public void setBillingAddress(String billingAddress) { this.billingAddress = billingAddress; }
    }

    @Data
    public static class Preferences {
        private boolean mfaEnabled;
        private String notificationType;

        public void setMfaEnabled(boolean mfaEnabled) { this.mfaEnabled = mfaEnabled; }
        public void setNotificationType(String notificationType) { this.notificationType = notificationType; }
    }
}
