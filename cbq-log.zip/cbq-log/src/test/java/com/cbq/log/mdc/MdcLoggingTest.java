package com.cbq.log.mdc;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.context.LogContext;
import com.cbq.log.core.CbqLog;
import com.cbq.log.event.LogEventBus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class MdcLoggingTest {

    @BeforeEach
    void setUp() {
        MDC.clear();
        LogEventBus.clear();
        CbqLog.configure(CbqLogConfig.defaults());
    }

    @Test
    void testMdcFieldsInStructuredLog() throws InterruptedException {
        CbqLog.configure(CbqLogConfig.builder()
                .sync()
                .mdcFields("custom_key", "another_key")
                .build());

        LogContext.setCorrelationId("test-cid");
        LogContext.setRequestId("test-rid");
        MDC.put("custom_key", "custom_val");
        // "another_key" is missing from MDC, should not be in log

        CbqLog log = CbqLog.getLogger(MdcLoggingTest.class);
        
        // Let's use a custom LogEventListener to verify the structured map
        final Map<String, Object>[] captured = new Map[1];
        LogEventBus.on(e -> true, entry -> captured[0] = entry);

        log.info("test message");

        // Even with sync() CBQ, LogEventBus.fire still submits to AsyncLogWriter
        // so we still need to wait.
        int count = 0;
        while (captured[0] == null && count < 20) {
            Thread.sleep(50);
            count++;
        }

        assertNotNull(captured[0]);
        assertEquals("test-cid", captured[0].get("cid"));
        assertEquals("test-rid", captured[0].get("rid"));
        assertEquals("custom_val", captured[0].get("custom_key"));
        assertNull(captured[0].get("another_key"));
    }

    @Test
    void testAsyncMdcPropagation() throws InterruptedException {
        CbqLog.configure(CbqLogConfig.builder()
                .async(true)
                .mdcFields("async_key")
                .build());

        MDC.put("async_key", "async_val");
        CbqLog log = CbqLog.getLogger(MdcLoggingTest.class);

        final Map<String, Object>[] captured = new Map[1];
        com.cbq.log.event.LogEventBus.on(e -> true, entry -> captured[0] = entry);

        log.info("async test");
        
        // Wait for async task
        int count = 0;
        while (captured[0] == null && count < 10) {
            Thread.sleep(100);
            count++;
        }

        assertNotNull(captured[0]);
        assertEquals("async_val", captured[0].get("async_key"));
    }
}
