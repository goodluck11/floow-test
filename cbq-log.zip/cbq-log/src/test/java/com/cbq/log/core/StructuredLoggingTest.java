package com.cbq.log.core;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.event.LogEventBus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

class StructuredLoggingTest {

    @BeforeEach
    void setUp() {
        LogEventBus.clear();
        CbqLog.configure(CbqLogConfig.builder().sync().build());
    }

    @Test
    void testStructuredKvLogging() throws InterruptedException {
        CbqLog log = CbqLog.getLogger(StructuredLoggingTest.class);
        AtomicReference<Map<String, Object>> captured = new AtomicReference<>();
        LogEventBus.on(e -> true, captured::set);

        log.infoKv("order processed", "orderId", "ORD-123", "amount", 99.99, "status", "SUCCESS");

        // Wait for async dispatch from fire()
        Thread.sleep(200);

        Map<String, Object> event = captured.get();
        assertNotNull(event);
        assertEquals("order processed", event.get("message"));
        assertEquals("ORD-123", event.get("orderId"));
        assertEquals(99.99, event.get("amount"));
        assertEquals("SUCCESS", event.get("status"));
    }

    @Test
    void testStructuredKvWithSinglePayloadFallback() throws InterruptedException {
        CbqLog log = CbqLog.getLogger(StructuredLoggingTest.class);
        AtomicReference<Map<String, Object>> captured = new AtomicReference<>();
        LogEventBus.on(e -> true, captured::set);

        Map<String, String> payload = Map.of("key", "value");
        log.infoKv("event with payload", payload);

        Thread.sleep(200);

        Map<String, Object> event = captured.get();
        assertNotNull(event);
        assertEquals("event with payload", event.get("message"));
        assertEquals(payload, event.get("data"));
    }

    @Test
    void testMixedPlaceholderAndKv() throws InterruptedException {
        // This test ensures that the two different API styles don't conflict
        CbqLog log = CbqLog.getLogger(StructuredLoggingTest.class);
        
        // 1. Test Placeholders
        AtomicReference<Map<String, Object>> captured1 = new AtomicReference<>();
        LogEventBus.clear();
        LogEventBus.on(e -> "placeholder message: val1".equals(e.get("message")), captured1::set);
        log.info("placeholder message: {}", "val1");
        
        // 2. Test KV
        AtomicReference<Map<String, Object>> captured2 = new AtomicReference<>();
        LogEventBus.on(e -> "kv message".equals(e.get("message")), captured2::set);
        log.infoKv("kv message", "key", "val2");

        Thread.sleep(300);

        assertNotNull(captured1.get(), "Placeholder log should be captured");
        assertNotNull(captured2.get(), "KV log should be captured");
        assertEquals("val2", captured2.get().get("key"));
    }
}
