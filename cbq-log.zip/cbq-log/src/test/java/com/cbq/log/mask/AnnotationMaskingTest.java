package com.cbq.log.mask;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.cbq.log.mask.model.AccountPayload;
import com.cbq.log.mask.model.UserPayload;
import com.cbq.log.mask.model.UserProfilePayload;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class AnnotationMaskingTest {

    @BeforeEach
    void setUp() {
        CbqLog.configure(CbqLogConfig.defaults());
    }

    @Test
    void testUserPayloadAnnotationMasking() {
        UserPayload user = new UserPayload();
        user.setUserId("usr_99210");
        user.setFullName("Marcus Aurelius");
        user.setUsername("marcus_gladiator");
        user.setPassword("hashed_password_8821x");
        user.setAccountNumber("8822991023");
        user.setIban("GB29NWBK60161331926819");
        user.setCardNumber("4532-1190-8842-1002");
        user.setCvv("442");
        user.setExpiryDate("12/27");
        user.setStatus("active");

        String masked = MaskEngine.mask(user);
        System.out.println("--- UserPayload Masked Result ---");
        System.out.println(masked);

        assertTrue(masked.contains("\"password\":\"" + "*".repeat(21) + "\""));
        assertTrue(masked.contains("\"accountNumber\":\"88******23\""));
        assertTrue(masked.contains("\"iban\":\"GB29**************6819\""));
        assertTrue(masked.contains("\"cardNumber\":\"4532***********1002\""));
        assertTrue(masked.contains("\"cvv\":\"***\""));
    }

    @Test
    void testAccountPayloadAnnotationMasking() {
        AccountPayload payload = new AccountPayload();
        
        AccountPayload.Metadata meta = new AccountPayload.Metadata();
        meta.setTotalCount(1);
        meta.setPage(1);
        meta.setRequestTimestamp("2026-02-13T12:40:00Z");
        payload.setMetadata(meta);

        AccountPayload.Account acc = new AccountPayload.Account();
        acc.setAccountType("Savings");
        acc.setBalance(12550.50);
        acc.setCurrency("USD");
        acc.setAccountNumber("100044921");
        acc.setIban("US89CHAS11002233445566");
        
        AccountPayload.LinkedCard card = new AccountPayload.LinkedCard();
        card.setCardNumber("5521-4400-9921-3341");
        card.setCvv("109");
        card.setProvider("MasterCard");
        acc.setLinkedCard(card);
        
        payload.setAccounts(List.of(acc));

        String masked = MaskEngine.mask(payload);
        System.out.println("--- AccountPayload Masked Result ---");
        System.out.println(masked);

        // Nested POJO masking verification
        assertTrue(masked.contains("\"accountNumber\":\"*****4921\""));
        assertTrue(masked.contains("\"iban\":\"US89**************5566\""));
        assertTrue(masked.contains("\"cardNumber\":\"5521***********3341\""));
        assertTrue(masked.contains("\"cvv\":\"***\""));
    }

    @Test
    void testUserProfilePayloadAnnotationMasking() {
        UserProfilePayload payload = new UserProfilePayload();
        UserProfilePayload.UserProfile profile = new UserProfilePayload.UserProfile();
        
        UserProfilePayload.Identity id = new UserProfilePayload.Identity();
        id.setFirstName("Elena");
        id.setLastName("Rossi");
        
        UserProfilePayload.Credentials creds = new UserProfilePayload.Credentials();
        creds.setUsername("erossi_dev");
        creds.setPassword("argon2_id_99210055");
        creds.setLastPasswordChange("2025-11-20");
        id.setCredentials(creds);
        profile.setIdentity(id);
        
        UserProfilePayload.Financials fin = new UserProfilePayload.Financials();
        UserProfilePayload.PrimaryBank bank = new UserProfilePayload.PrimaryBank();
        bank.setBankName("Global Trust");
        bank.setAccountNumber("772211003");
        bank.setIban("IT55L0200805000000044332211");
        bank.setSecurityCode("9910");
        fin.setPrimaryBank(bank);
        
        UserProfilePayload.ActiveMethods am = new UserProfilePayload.ActiveMethods();
        UserProfilePayload.CreditCard cc = new UserProfilePayload.CreditCard();
        cc.setCardNumber("3782-441029-31002");
        cc.setCvv("882");
        cc.setType("Amex");
        cc.setBillingAddress("123 Via Roma, Milan, Italy");
        am.setCreditCard(cc);
        fin.setActiveMethods(am);
        profile.setFinancials(fin);
        
        UserProfilePayload.Preferences pref = new UserProfilePayload.Preferences();
        pref.setMfaEnabled(true);
        pref.setNotificationType("SMS");
        profile.setPreferences(pref);
        
        payload.setUserProfile(profile);

        String masked = MaskEngine.mask(payload);
        System.out.println("--- UserProfilePayload Masked Result ---");
        System.out.println(masked);

        assertTrue(masked.contains("\"password\":\"" + "*".repeat(18) + "\""));
        assertTrue(masked.contains("\"accountNumber\":\"******003\""));
        assertTrue(masked.contains("\"iban\":\"IT55"));
        assertTrue(masked.contains("2211\""));
        assertTrue(masked.contains("\"securityCode\":\"****\""));
        assertTrue(masked.contains("\"cardNumber\":\"3782"));
        assertTrue(masked.contains("1002\""));
        assertTrue(masked.contains("\"cvv\":\"***\""));
    }
    
    @Test
    void testSupportedFormats() {
        UserPayload user = new UserPayload();
        user.setPassword("secret");

        // PRETTY Format
        CbqLog.configure(CbqLogConfig.builder().prettyFormat().build());
        String pretty = MaskEngine.mask(user);
        System.out.println("--- PRETTY Format Result ---");
        System.out.println(pretty);
        assertTrue(pretty.contains("\n"));
        assertTrue(pretty.contains("  \"password\" : \"******\""));

        // JSON Format (Default)
        CbqLog.configure(CbqLogConfig.builder().jsonFormat().build());
        String json = MaskEngine.mask(user);
        System.out.println("--- JSON Format Result ---");
        System.out.println(json);
        assertFalse(json.contains("\n"));
        assertTrue(json.contains("\"password\":\"******\""));

        // TEXT Format
        CbqLog.configure(CbqLogConfig.builder().textFormat().build());
        // MaskEngine.mask(obj) always returns JSON because it uses toJson(maskToMap(obj)).
        // CbqLog uses LogFormatter to format the final entry.
        String text = MaskEngine.mask(user); 
        System.out.println("--- TEXT Format (via MaskEngine.mask) Result ---");
        System.out.println(text);
        // MaskEngine.mask still returns JSON string but masked.
    }

    @Test
    void testPlaceholderMasking() throws InterruptedException {
        UserPayload user = new UserPayload();
        user.setPassword("secret123");
        user.setAccountNumber("1234567890");

        final String[] capturedMsg = new String[1];
        com.cbq.log.event.LogEventBus.clear();
        com.cbq.log.event.LogEventBus.on(e -> true, entry -> capturedMsg[0] = (String) entry.get("message"));

        CbqLog.configure(CbqLogConfig.builder().sync().build());
        CbqLog log = CbqLog.getLogger(AnnotationMaskingTest.class);
        
        log.info("User details: {}", user);

        // Wait for async task from LogEventBus
        int count = 0;
        while (capturedMsg[0] == null && count < 20) {
            Thread.sleep(50);
            count++;
        }

        assertNotNull(capturedMsg[0]);
        assertTrue(capturedMsg[0].contains("User details:"));
        assertTrue(capturedMsg[0].contains("password=*********"));
        assertTrue(capturedMsg[0].contains("accountNumber=12******90"));
    }
}
