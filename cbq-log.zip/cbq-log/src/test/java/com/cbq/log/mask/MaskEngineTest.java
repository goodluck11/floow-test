package com.cbq.log.mask;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MaskEngineTest {

    @BeforeEach
    void setUp() {
        CbqLog.configure(CbqLogConfig.defaults());
    }

    @Test
    void testBasicMasking() {
        String masked = (String) MaskEngine.maskValue("1234567890", '*', 0, 0, false);
        assertEquals("**********", masked);
    }

    @Test
    void testLeftVisibleMasking() {
        String masked = (String) MaskEngine.maskValue("1234567890", '*', 4, 0, false);
        assertEquals("1234******", masked);
    }

    @Test
    void testRightVisibleMasking() {
        String masked = (String) MaskEngine.maskValue("1234567890", '*', 0, 4, false);
        assertEquals("******7890", masked);
    }

    @Test
    void testInBetweenMasking() {
        String masked = (String) MaskEngine.maskValue("1234567890", '*', 2, 2, false);
        assertEquals("12******90", masked);
    }

    @Test
    void testFullyMasked() {
        String masked = (String) MaskEngine.maskValue("1234567890", '*', 2, 2, true);
        assertEquals("**********", masked);
    }

    @Test
    void testAnnotationMasking() {
        User user = new User();
        user.name = "John Doe";
        user.password = "secret123";
        user.creditCard = "1234567812345678";
        user.cvv = "123";

        Map<String, Object> maskedMap = MaskEngine.maskToMap(user);
        assertEquals("John Doe", maskedMap.get("name"));
        assertEquals("*********", maskedMap.get("password")); // fully masked
        assertEquals("1234********5678", maskedMap.get("creditCard")); // left 4, right 4
        assertNull(maskedMap.get("cvv")); // excluded
    }

    @Test
    void testJsonMaskingClean() {
        String json = "{\"password\":\"secret123\", \"email\":\"user@example.com\"}";
        String maskedJson = MaskEngine.maskJson(json, Set.of("password"), '*');

        // Ensure no backslashes and correct masking
        assertTrue(maskedJson.contains("\"password\":\"*********\""));
        assertTrue(maskedJson.contains("\"email\":\"user@example.com\""));
        assertFalse(maskedJson.contains("\\\""));
    }

    @Test
    void testJsonPathMasking() {
        String json = "{\"user\":{\"details\":{\"ssn\":\"123-456-789\"}}}";
        CbqLog.configure(CbqLogConfig.builder().maskJsonPaths("user.details.ssn").build());
        
        String maskedJson = MaskEngine.maskJson(json, Set.of(), Set.of("user.details.ssn"), '*');
        assertTrue(maskedJson.contains("\"ssn\":\"***********\""));
    }

    @Test
    void testPrettyJson() {
        CbqLog.configure(CbqLogConfig.builder().prettyFormat().build());
        Map<String, Object> data = Map.of("key", "value");
        String json = MaskEngine.toJson(data);
        assertTrue(json.contains("\n"));
        assertTrue(json.contains("  \"key\""));
    }

    static class User {
        String name;
        
        @MaskSensitive
        String password;
        
        @MaskSensitive(leftVisible = 4, rightVisible = 4)
        String creditCard;
        
        @MaskSensitive(exclude = true)
        String cvv;
    }
}
