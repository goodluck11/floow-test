package com.cbq.log.core;

import com.cbq.log.event.LogEventBus;
import org.junit.jupiter.api.Test;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PlaceholderTest {

    @Test
    public void testPlaceholderLoggingWithThrowable() throws InterruptedException {
        LogEventBus.clear();
        AtomicReference<Map<String, Object>> capturedEvent = new AtomicReference<>();
        LogEventBus.on(e -> true, capturedEvent::set);

        CbqLog log = CbqLog.getLogger(PlaceholderTest.class);
        Exception ex = new RuntimeException("Test Error");
        log.error("Failed to process {} due to error", "Order123", ex);

        // Give it a moment as LogEventBus.fire uses AsyncLogWriter.submit for listeners
        int retries = 0;
        while (capturedEvent.get() == null && retries < 100) {
            Thread.sleep(10);
            retries++;
        }

        Map<String, Object> event = capturedEvent.get();
        String message = (String) event.get("message");
        
        assertTrue(message.contains("Failed to process Order123 due to error"), 
            "Expected message to have placeholders replaced, but got: " + message);
        assertTrue("RuntimeException".equals(event.get("error")));
        assertTrue("Test Error".equals(event.get("error_message")));
    }

    @Test
    public void testPlaceholderLoggingWithPayload() throws InterruptedException {
        LogEventBus.clear();
        AtomicReference<Map<String, Object>> capturedEvent = new AtomicReference<>();
        LogEventBus.on(e -> true, capturedEvent::set);

        CbqLog log = CbqLog.getLogger(PlaceholderTest.class);
        Map<String, String> data = Map.of("key", "value");
        log.info("Status of {} updated", "Item456", data);

        int retries = 0;
        while (capturedEvent.get() == null && retries < 100) {
            Thread.sleep(10);
            retries++;
        }

        Map<String, Object> event = capturedEvent.get();
        String message = (String) event.get("message");
        
        assertTrue(message.contains("Status of Item456 updated"), 
            "Expected message to have placeholders replaced, but got: " + message);
        assertTrue(data.equals(event.get("data")));
    }
}
