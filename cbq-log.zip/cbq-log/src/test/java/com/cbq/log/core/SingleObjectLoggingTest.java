package com.cbq.log.core;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.event.LogEventBus;
import com.cbq.log.mask.model.UserPayload;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

class SingleObjectLoggingTest {

    @BeforeEach
    void setUp() {
        LogEventBus.clear();
        CbqLog.configure(CbqLogConfig.builder()
                .sync()
                .maskFields("password")
                .build());
    }

    @Test
    void testStringOnlyLogging() throws InterruptedException {
        CbqLog log = CbqLog.getLogger(SingleObjectLoggingTest.class);
        AtomicReference<Map<String, Object>> captured = new AtomicReference<>();
        LogEventBus.on(e -> true, captured::set);

        log.info("Simple message");

        Thread.sleep(100);

        Map<String, Object> event = captured.get();
        assertNotNull(event);
        assertEquals("Simple message", event.get("message"));
        assertNull(event.get("data"));
    }

    @Test
    void testJsonStringMasking() throws InterruptedException {
        CbqLog log = CbqLog.getLogger(SingleObjectLoggingTest.class);
        AtomicReference<Map<String, Object>> captured = new AtomicReference<>();
        LogEventBus.on(e -> true, captured::set);

        String json = "{\"username\":\"admin\", \"password\":\"secret123\"}";
        log.info(json);

        Thread.sleep(100);

        Map<String, Object> event = captured.get();
        assertNotNull(event);
        String msg = (String) event.get("message");
        assertTrue(msg.contains("\"username\":\"admin\""));
        assertTrue(msg.contains("\"password\":\"*********\""));
    }

    @Test
    void testMapOnlyLogging() throws InterruptedException {
        CbqLog log = CbqLog.getLogger(SingleObjectLoggingTest.class);
        AtomicReference<Map<String, Object>> captured = new AtomicReference<>();
        LogEventBus.on(e -> true, captured::set);

        Map<String, Object> data = Map.of("userId", 123, "password", "pass123");
        log.info(data);

        Thread.sleep(100);

        Map<String, Object> event = captured.get();
        assertNotNull(event);
        assertNull(event.get("message"));
        
        Map<String, Object> loggedData = (Map<String, Object>) event.get("data");
        assertNotNull(loggedData);
        assertEquals(123, loggedData.get("userId"));
        assertEquals("*******", loggedData.get("password"));
    }

    @Test
    void testPojoOnlyLogging() throws InterruptedException {
        CbqLog log = CbqLog.getLogger(SingleObjectLoggingTest.class);
        AtomicReference<Map<String, Object>> captured = new AtomicReference<>();
        LogEventBus.on(e -> true, captured::set);

        UserPayload user = new UserPayload();
        user.setUsername("john_doe");
        user.setPassword("top_secret");
        log.info(user);

        Thread.sleep(100);

        Map<String, Object> event = captured.get();
        assertNotNull(event);
        
        Map<String, Object> loggedData = (Map<String, Object>) event.get("data");
        assertNotNull(loggedData);
        assertEquals("john_doe", loggedData.get("username"));
        assertEquals("**********", loggedData.get("password"));
    }
}
