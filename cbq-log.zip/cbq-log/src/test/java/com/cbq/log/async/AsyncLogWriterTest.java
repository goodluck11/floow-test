package com.cbq.log.async;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.cbq.log.mask.model.UserPayload;
import com.cbq.log.metrics.LogMetrics;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AsyncLogWriterTest {

   @BeforeEach
   void setUp() {
      LogMetrics.reset();
   }

   @AfterEach
   void tearDown() {
      AsyncLogWriter.shutdown();
      resetAsyncLogWriter();
   }

   private void resetAsyncLogWriter() {
      try {
         Field field = AsyncLogWriter.class.getDeclaredField("executorRef");
         field.setAccessible(true);
         ((AtomicReference<?>) field.get(null)).set(null);

         Field shutdownField = AsyncLogWriter.class.getDeclaredField("shutdown");
         shutdownField.setAccessible(true);
         ((java.util.concurrent.atomic.AtomicBoolean) shutdownField.get(null)).set(false);
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   @Test
   void testSyncLogging() throws InterruptedException {
      CbqLog.configure(CbqLogConfig.builder()
              .sync()
              .build());

      CbqLog log = CbqLog.getLogger(AsyncLogWriterTest.class);

      // Use a listener to verify it's sync (LogEventBus.fire is still async but CbqLog dispatch isn't)
      // Actually, dispatch is sync, but it calls write() directly.
      // We can check if it stays on the same thread.
      AsyncLogWriter.submit(() -> {}); // Initialize to avoid overhead later

      log.info("sync message");

      // LogEventBus.fire still submits to AsyncLogWriter for listeners, but if no listeners registered...
      // wait a bit to ensure no background tasks are running
      Thread.sleep(100);

      // Verify that NO tasks were submitted to AsyncLogWriter by the logger itself
      // We check for > 1 because we submitted one task manually at line 65
      assertEquals(1, LogMetrics.getSubmitCount(), "LogMetrics should only show 1 async submission (the manual one)");
   }

   @Test
   void testBoundedExecutorConfiguration() throws Exception {
      CbqLogConfig config = CbqLogConfig.builder()
              .asyncCorePoolSize(5)
              .asyncMaxPoolSize(15)
              .asyncQueueCapacity(50)
              .build();

      CbqLog.configure(config);

      // Trigger executor creation
      AsyncLogWriter.submit(() -> {
      });

      Field field = AsyncLogWriter.class.getDeclaredField("executorRef");
      field.setAccessible(true);
      Object executor = ((AtomicReference<?>) field.get(null)).get();

      // If Java 21+, it might be a VirtualThreadPerTaskExecutor which isn't a ThreadPoolExecutor
      if (executor instanceof ThreadPoolExecutor pool) {
         assertEquals(5, pool.getCorePoolSize());
         assertEquals(15, pool.getMaximumPoolSize());
         assertEquals(50, pool.getQueue().remainingCapacity() + pool.getQueue().size());
         assertTrue(pool.getRejectedExecutionHandler() instanceof ThreadPoolExecutor.CallerRunsPolicy);
      } else {
         // Assume VirtualThreadPerTaskExecutor
         System.out.println("Executor type: " + executor.getClass().getName());
      }
   }

   @Test
   void testRealHighLoadBenchmark() throws InterruptedException {
      int threads = 10;
      int logsPerThread = 1000; // Reduced to make test practical
      int totalLogs = threads * logsPerThread;

      // Use a real log destination that actually blocks
      BlockingQueue<String> mockLogDestination = new LinkedBlockingQueue<>();

      // Configure with smaller queue to test backpressure
      CbqLog.configure(CbqLogConfig.builder()
              .prettyFormat()
              .async(true)
              .asyncCorePoolSize(2)
              .asyncMaxPoolSize(4)
              .asyncQueueCapacity(100) // Small queue to force backpressure
              .build());

      CountDownLatch submitterLatch = new CountDownLatch(threads);
      CountDownLatch processingLatch = new CountDownLatch(totalLogs);

      // Track metrics
      AtomicLong totalSubmitTime = new AtomicLong(0);
      AtomicBoolean backpressureObserved = new AtomicBoolean(false);

      long start = System.currentTimeMillis();
      var user = createTestUser();

      // Start submitters
      for (int i = 0; i < threads; i++) {
         int threadId = i;
         new Thread(() -> {
            try {
               for (int j = 0; j < logsPerThread; j++) {
                  long submitStart = System.currentTimeMillis();

                  // Submit work DIRECTLY to AsyncLogWriter to simulate realistic I/O
                  int finalJ = j;
                  AsyncLogWriter.submit(() -> {
                     try {
                        // Simulate realistic I/O latency (2ms)
                        Thread.sleep(ThreadLocalRandom.current().nextInt(1, 15));
                        // Optional: we can still do a tiny bit of work here
                        String.format("Log task %d-%d", threadId, finalJ);
                     } catch (InterruptedException e1) {
                        Thread.currentThread().interrupt();
                     } finally {
                        mockLogDestination.add("done");
                        processingLatch.countDown();
                     }
                  });

                  long submitEnd = System.currentTimeMillis();
                  totalSubmitTime.addAndGet(submitEnd - submitStart);

                  // Check if we experienced backpressure (submission blocked)
                  if ((submitEnd - submitStart) > 1) { // >1ms indicates potential blocking/slowdown
                     backpressureObserved.set(true);
                  }

                  // Small yield to prevent overwhelming the system
                  Thread.yield();
               }
            } finally {
               submitterLatch.countDown();
            }
         }).start();
      }

      // Wait for all submissions to complete (or timeout)
      boolean submissionsCompleted = submitterLatch.await(30, TimeUnit.SECONDS);
      long submissionEnd = System.currentTimeMillis();

      // Wait for all processing to complete
      boolean processingCompleted = processingLatch.await(30, TimeUnit.SECONDS);
      long processingEnd = System.currentTimeMillis();

      // Calculate metrics
      long submissionTimeMs = submissionEnd - start;
      long totalTimeMs = processingEnd - start;
      double submitRate = totalLogs / (Math.max(1, submissionTimeMs) / 1000.0);
      double processRate = totalLogs / (Math.max(1, totalTimeMs) / 1000.0);
      double avgSubmitLatencyMs = totalSubmitTime.get() / (double) totalLogs;

      Map<String, Object> snapshot = LogMetrics.snapshot();
      Map<String, Object> async = (Map<String, Object>) snapshot.get("async_logger");

      // Log Metrics results
      System.err.println("\n=== DETAILED METRICS ===");
      System.err.printf("Submit count: %d%n", async.get("submit_count"));
      System.err.printf("Avg latency: %.2f ms%n", async.get("avg_submit_latency_ms"));
      System.err.printf("Backpressure events: %d (%.2f%%)%n", async.get("backpressure_events"), async.get("backpressure_rate_pct"));
      System.err.printf("Queue full events: %d%n", async.get("queue_full_events"));
      System.err.printf("Peak queue size: %d%n", async.get("peak_queue_size"));
      System.err.printf("Peak active threads: %d%n", async.get("peak_active_threads"));

      // Log results
      System.err.println("=== BENCHMARK RESULTS ===");
      System.err.printf("Total logs: %d%n", totalLogs);
      System.err.printf("Submission time: %d ms%n", submissionTimeMs);
      System.err.printf("Total time (including processing): %d ms%n", totalTimeMs);
      System.err.printf("Submission rate: %.2f logs/sec%n", submitRate);
      System.err.printf("Processing rate: %.2f logs/sec%n", processRate);
      System.err.printf("Average submit latency: %.3f ms%n", avgSubmitLatencyMs);
      System.err.printf("Backpressure observed: %s%n", backpressureObserved.get());
      System.err.printf("Final queue size: %d%n", AsyncLogWriter.getQueueSize());
      System.err.printf("Active threads: %d%n", AsyncLogWriter.getActiveThreads());
      System.err.printf("Mock log destination size: %d%n", mockLogDestination.size());

      // Assertions
      assertTrue(submissionsCompleted, "Submissions timed out");
      assertTrue(processingCompleted, "Processing timed out");
      // Note: we removed mockLogDestination.put from the log task because we are using CbqLog directly
      // So we can't easily check mockLogDestination size unless we use a listener.
      
      // Verify backpressure protection worked
      if (backpressureObserved.get()) {
         System.err.println("✅ Backpressure mechanism activated - good!");
      }

      // Cleanup
      AsyncLogWriter.shutdown();
      resetAsyncLogWriter();
   }

   private UserPayload createTestUser() {
      UserPayload user = new UserPayload();
      user.setUserId("usr_99210");
      user.setFullName("Marcus Aurelius");
      user.setUsername("marcus_gladiator");
      user.setPassword("hashed_password_8821x");
      user.setAccountNumber("8822991023");
      user.setIban("GB29NWBK60161331926819");
      user.setCardNumber("4532-1190-8842-1002");
      user.setCvv("442");
      user.setExpiryDate("12/27");
      user.setStatus("active");
      return user;
   }
}
