package com.cbq.log.mask.model;

import com.cbq.log.mask.MaskSensitive;
import lombok.Data;

@Data
public class UserPayload {
    private String userId;
    private String fullName;
    private String username;
    
    @MaskSensitive
    private String password;
    
    @MaskSensitive(leftVisible = 2, rightVisible = 2)
    private String accountNumber;
    
    @MaskSensitive(leftVisible = 4, rightVisible = 4)
    private String iban;
    
    @MaskSensitive(leftVisible = 4, rightVisible = 4)
    private String cardNumber;
    
    @MaskSensitive(fullyMask = true)
    private String cvv;

    private String expiryDate;
    private String status;

    public void setUserId(String userId) { this.userId = userId; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public void setIban(String iban) { this.iban = iban; }
    public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
    public void setCvv(String cvv) { this.cvv = cvv; }
    public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }
    public void setStatus(String status) { this.status = status; }
}
