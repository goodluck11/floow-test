package com.cbq.log.db;

import com.cbq.log.metrics.LogMetrics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DbLogProxyDataSourceTest {

    private DataSource proxyDataSource;
    private DriverManagerDataSource h2DataSource;

    @BeforeEach
    void setUp() {
        LogMetrics.reset();
        DbLogProxyDataSource.setMetricsSampleRate(1.0); // 100% for tests
        h2DataSource = new DriverManagerDataSource();
        h2DataSource.setDriverClassName("org.h2.Driver");
        h2DataSource.setUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        h2DataSource.setUsername("sa");
        h2DataSource.setPassword("");

        proxyDataSource = DbLogProxyDataSource.wrap(h2DataSource, 100);
    }

    @Test
    void testConnectionAcquireAndRelease() throws SQLException {
        try (Connection conn = proxyDataSource.getConnection()) {
            assertNotNull(conn);
            assertTrue(LogMetrics.snapshot().containsKey("db.pool.acquire"));
        }
        assertTrue(LogMetrics.snapshot().containsKey("db.pool.release"));
        
        Map<String, Object> poolAcquire = (Map<String, Object>) LogMetrics.snapshot().get("db.pool.acquire");
        assertEquals(1L, poolAcquire.get("count"));

        Map<String, Object> poolRelease = (Map<String, Object>) LogMetrics.snapshot().get("db.pool.release");
        assertEquals(1L, poolRelease.get("count"));
    }

    @Test
    void testThreadSafetyUnderLoad() throws InterruptedException {
        int threads = 10;
        int iterations = 100;
        java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(threads);
        java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(threads);

        for (int i = 0; i < threads; i++) {
            executor.submit(() -> {
                try {
                    for (int j = 0; j < iterations; j++) {
                        try (Connection conn = proxyDataSource.getConnection();
                             Statement stmt = conn.createStatement()) {
                            stmt.execute("SELECT 1");
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await();
        executor.shutdown();

        Map<String, Object> snapshot = LogMetrics.snapshot();
        Map<String, Object> select = (Map<String, Object>) snapshot.get("db.select");
        assertEquals((long) threads * iterations, select.get("count"));
        
        Map<String, Object> acquire = (Map<String, Object>) snapshot.get("db.pool.acquire");
        assertEquals((long) threads * iterations, acquire.get("count"));
    }

    @Test
    void testRawJdbcQueryDuration() throws SQLException {
        try (Connection conn = proxyDataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE test (id INT PRIMARY KEY, name VARCHAR(255))");
            stmt.executeUpdate("INSERT INTO test VALUES (1, 'test')");
            
            try (ResultSet rs = stmt.executeQuery("SELECT * FROM test")) {
                assertTrue(rs.next());
                assertEquals("test", rs.getString("name"));
            }
        }

        Map<String, Object> snapshot = LogMetrics.snapshot();
        assertTrue(snapshot.containsKey("db.create"), "Should track create");
        assertTrue(snapshot.containsKey("db.insert"), "Should track insert");
        assertTrue(snapshot.containsKey("db.select"), "Should track select");
    }

    @Test
    void testPreparedStatement() throws SQLException {
        try (Connection conn = proxyDataSource.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO test (id, name) VALUES (?, ?)")) {
            // Need to create table first
            try (Statement s = conn.createStatement()) {
                s.execute("CREATE TABLE IF NOT EXISTS test (id INT PRIMARY KEY, name VARCHAR(255))");
            }
            
            pstmt.setInt(1, 2);
            pstmt.setString(2, "prepared");
            pstmt.executeUpdate();
        }
        
        Map<String, Object> snapshot = LogMetrics.snapshot();
        assertTrue(snapshot.containsKey("db.insert"));
    }

    @Test
    void testJdbcTemplateCompatibility() {
        JdbcTemplate template = new JdbcTemplate(proxyDataSource);
        template.execute("CREATE TABLE jt (id INT PRIMARY KEY)");
        template.update("INSERT INTO jt VALUES (1)");
        Integer count = template.queryForObject("SELECT COUNT(*) FROM jt", Integer.class);
        assertEquals(1, count);

        Map<String, Object> snapshot = LogMetrics.snapshot();
        assertTrue(snapshot.containsKey("db.create"));
        assertTrue(snapshot.containsKey("db.insert"));
        assertTrue(snapshot.containsKey("db.select"));
    }

    @Test
    void testJdbcClientCompatibility() {
        JdbcClient client = JdbcClient.create(proxyDataSource);
        client.sql("CREATE TABLE jc (id INT PRIMARY KEY)").update();
        client.sql("INSERT INTO jc VALUES (1)").update();
        Integer count = client.sql("SELECT COUNT(*) FROM jc").query(Integer.class).single();
        assertEquals(1, count);

        Map<String, Object> snapshot = LogMetrics.snapshot();
        assertTrue(snapshot.containsKey("db.create"));
        assertTrue(snapshot.containsKey("db.insert"));
        assertTrue(snapshot.containsKey("db.select"));
    }

    @Test
    void testSlowQueryDisabled() throws SQLException {
        DataSource disabledProxy = DbLogProxyDataSource.wrap(h2DataSource, -1, true);
        try (Connection conn = disabledProxy.getConnection();
             Statement stmt = conn.createStatement()) {
            LogMetrics.reset();
            stmt.execute("SELECT 1");
            Map<String, Object> snapshot = LogMetrics.snapshot();
            assertTrue(!snapshot.containsKey("db.select"), "Slow query metrics should not be recorded when disabled with -1");
        }
    }

    @Test
    void testPoolMonitoringDisabled() throws SQLException {
        DataSource disabledProxy = DbLogProxyDataSource.wrap(h2DataSource, 100, false);
        LogMetrics.reset();
        try (Connection conn = disabledProxy.getConnection()) {
            assertNotNull(conn);
            Map<String, Object> snapshot = LogMetrics.snapshot();
            assertTrue(!snapshot.containsKey("db.pool.acquire"), "Pool acquire metrics should not be recorded when disabled");
        }
    }
}
