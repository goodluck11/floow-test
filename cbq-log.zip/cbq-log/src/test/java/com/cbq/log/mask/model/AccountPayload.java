package com.cbq.log.mask.model;

import com.cbq.log.mask.MaskSensitive;
import lombok.Data;
import java.util.List;

@Data
public class AccountPayload {
    private Metadata metadata;
    private List<Account> accounts;

    public void setMetadata(Metadata metadata) { this.metadata = metadata; }
    public void setAccounts(List<Account> accounts) { this.accounts = accounts; }

    @Data
    public static class Metadata {
        private int totalCount;
        private int page;
        private String requestTimestamp;

        public void setTotalCount(int totalCount) { this.totalCount = totalCount; }
        public void setPage(int page) { this.page = page; }
        public void setRequestTimestamp(String requestTimestamp) { this.requestTimestamp = requestTimestamp; }
    }

    @Data
    public static class Account {
        private String accountType;
        private double balance;
        private String currency;
        
        @MaskSensitive(rightVisible = 4)
        private String accountNumber;
        
        @MaskSensitive(leftVisible = 4, rightVisible = 4)
        private String iban;
        
        private LinkedCard linkedCard;

        public void setAccountType(String accountType) { this.accountType = accountType; }
        public void setBalance(double balance) { this.balance = balance; }
        public void setCurrency(String currency) { this.currency = currency; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
        public void setIban(String iban) { this.iban = iban; }
        public void setLinkedCard(LinkedCard linkedCard) { this.linkedCard = linkedCard; }
    }

    @Data
    public static class LinkedCard {
        @MaskSensitive(leftVisible = 4, rightVisible = 4)
        private String cardNumber;
        
        @MaskSensitive(fullyMask = true)
        private String cvv;
        
        private String provider;

        public void setCardNumber(String cardNumber) { this.cardNumber = cardNumber; }
        public void setCvv(String cvv) { this.cvv = cvv; }
        public void setProvider(String provider) { this.provider = provider; }
    }
}
