package com.cbq.log.metrics;

import com.cbq.log.async.AsyncLogWriter;
import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class LogMetricsTest {

    @BeforeEach
    void setUp() {
        LogMetrics.reset();
        AsyncLogWriter.shutdown();
    }

    @Test
    void testBasicMetrics() {
        LogMetrics.incrementInfo();
        LogMetrics.incrementInfo();
        LogMetrics.incrementError();

        assertEquals(2, LogMetrics.getInfoCount());
        assertEquals(1, LogMetrics.getErrorCount());
        assertEquals(0, LogMetrics.getWarnCount());
    }

    @Test
    void testTaskMetrics() {
        LogMetrics.recordTask("db", "query", 100, true);
        LogMetrics.recordTask("db", "query", 600, true); // slow
        LogMetrics.recordTask("db", "query", 50, false); // failure

        Map<String, Object> snapshot = LogMetrics.snapshot();
        Map<String, Object> dbQuery = (Map<String, Object>) snapshot.get("db.query");

        assertNotNull(dbQuery);
        assertEquals(3L, dbQuery.get("count"));
        assertEquals(1L, dbQuery.get("failures"));
        assertEquals(1L, dbQuery.get("slow"));
        assertEquals(750L, dbQuery.get("total_ms"));
    }

    @Test
    void testAsyncMetrics() throws InterruptedException {
        CbqLog.configure(CbqLogConfig.builder()
                .async(true)
                .asyncQueueCapacity(100)
                .build());

        CbqLog log = CbqLog.getLogger(LogMetricsTest.class);

        // Submit some logs
        for (int i = 0; i < 50; i++) {
            log.info("Test message " + i);
        }

        // Wait a bit for processing
        Thread.sleep(500);

        Map<String, Object> snapshot = LogMetrics.snapshot();
        Map<String, Object> async = (Map<String, Object>) snapshot.get("async_logger");

        assertNotNull(async);
        assertTrue((Long) async.get("submit_count") >= 50);
        assertTrue((Double) async.get("avg_submit_latency_ms") >= 0);
        
        // Peaks should be tracked
        assertTrue((Integer) async.get("peak_queue_size") >= 0);
        assertTrue((Integer) async.get("peak_active_threads") >= 0);
    }
}
