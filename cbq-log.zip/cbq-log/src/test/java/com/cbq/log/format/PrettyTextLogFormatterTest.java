package com.cbq.log.format;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.cbq.log.mask.MaskEngine;
import com.cbq.log.mask.MaskProfile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;

class PrettyTextLogFormatterTest {

   @BeforeEach
   void setUp() {
      CbqLog.configure(CbqLogConfig.builder().prettyTextFormat().build());
   }

   @Test
   void testPrettyTextFormat() {
      var headers = Map.of(
              "Content-Type", "application/json",
              "Authorization", "Basic 772211003req-99210-abc",
              "X-Trace-Id", "trace-5566"
      );

      var body = Map.of(
              "userProfile", Map.of(
                      "username", "erossi_dev",
                      "accountNumber", "772211003"
              )
      );

      PrettyTextLogFormatter formatter = new PrettyTextLogFormatter();

      Map<String, Object> entry = new java.util.LinkedHashMap<>();
      entry.put("type", "http_response");
      entry.put("request_id", "req-99210-abc");
      entry.put("status", 200);
      entry.put("duration_ms", 142);
      entry.put("headers", headers);
      entry.put("response", body);

      String output = formatter.format(entry);
      System.out.println(output);

      assertTrue(output.contains("╔"));
      assertTrue(output.contains("CBQ HTTP RESPONSE"));
      assertTrue(output.contains("Request id: req-99210-abc"));
      assertTrue(output.contains("Status: 200"));
      assertTrue(output.contains("Duration ms: 142"));
      assertTrue(output.contains("headers:"));
      assertTrue(output.contains("response:"));
      assertTrue(output.contains("\"username\" : \"erossi_dev\""));
      assertTrue(output.contains("╚"));
   }

   @Test
   void testPrettyTextWithMasking() {
      CbqLog.configure(CbqLogConfig.builder()
              .prettyTextFormat()
              .maskProfile(MaskProfile.KONG_GATEWAY)
              .maskFields("password", "cvv", "Authorization")
              .build());

      var body = new java.util.LinkedHashMap<>();
      body.put("username", "admin");
      body.put("password", "secret123");
      body.put("cvv", "123");

      var headers = Map.of(
              "Content-Type", "application/json",
              "Authorization", "Basic 772211003req-99210-abc",
              "X-Trace-Id", "trace-5566"
      );

      var formatter = new PrettyTextLogFormatter();

      Map<String, Object> entry = new java.util.LinkedHashMap<>();
      entry.put("type", "login_request");

      var maskedHeaders = MaskEngine.mask(headers);

      // Manual masking for the formatter test:
      var maskedBody = MaskEngine.maskToMap(body);
      entry.put("body", maskedBody);
      entry.put("headers", maskedHeaders);

      String output = formatter.format(entry);
      System.out.println("--- Masked Pretty Text ---");
      System.out.println(output);

      assertTrue(output.contains("\"password\" : \"*********\""));
      assertTrue(output.contains("\"cvv\" : \"****\""));
      assertTrue(output.contains("\"username\" : \"admin\""));
      assertTrue(output.contains("\"Authorization\" : \"Basic 7...****\""));
   }
}
