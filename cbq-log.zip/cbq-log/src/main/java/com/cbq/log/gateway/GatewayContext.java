package com.cbq.log.gateway;

import com.cbq.log.context.LogContext;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.UnaryOperator;

/**
 * Extracts gateway metadata (Kong, Nginx, CloudFlare, generic) and User-Agent
 * from request headers into structured maps.
 *
 * <p>Works in both servlet (MDC) and reactive (Reactor Context) environments.
 *
 * <h3>Servlet (MDC-based):</h3>
 * <pre>{@code
 * GatewayContext.extract(request::getHeader);
 * // Values in MDC, available in all log output on this thread
 * }</pre>
 *
 */
public final class GatewayContext {

   /**
    * Reactor Context key for storing the gateway context map
    */
   public static final String REACTOR_CTX_KEY = "cbq.gatewayContext";

   // MDC / structured log keys
   public static final String CLIENT_IP = "client_ip";
   public static final String USER_AGENT = "user_agent";
   public static final String UA_PLATFORM = "ua_platform";
   public static final String GATEWAY_CONSUMER = "gateway.consumer";
   public static final String GATEWAY_ROUTE = "gateway.route";
   public static final String GATEWAY_SERVICE = "gateway.service";
   public static final String GATEWAY_REQUEST_ID = "gateway.request_id";
   public static final String GATEWAY_LATENCY = "gateway.latency";

   // Kong header names
   private static final String[] KONG_CONSUMER_HEADERS = {
           "X-Consumer-Username", "X-Consumer-Custom-ID", "X-Consumer-ID"};
   private static final String[] CLIENT_IP_HEADERS = {
           "X-Real-IP", "X-Forwarded-For", "CF-Connecting-IP", "True-Client-IP"};

   private GatewayContext() {
   }

   /**
    * Extract gateway + User-Agent info from headers into MDC AND return as map.
    * Use this in servlet filters where MDC works (thread-per-request).
    */
   public static Map<String, String> extract(UnaryOperator<String> headerLookup) {
      var ctx = doExtract(headerLookup);
      // Also store in MDC for servlet environments
      ctx.forEach(LogContext::put);
      return ctx;
   }

   /**
    * Extract gateway info into a plain map WITHOUT touching MDC.
    * Use this in reactive WebFilters — store the result in Reactor Context.
    * <pre>{@code
    * var gwCtx = GatewayContext.extractMap(exchange.getRequest().getHeaders()::getFirst);
    * return chain.filter(exchange)
    *         .contextWrite(ctx -> ctx.put(GatewayContext.REACTOR_CTX_KEY, gwCtx));
    * }</pre>
    */
   public static Map<String, String> extractMap(UnaryOperator<String> headerLookup) {
      return doExtract(headerLookup);
   }

   /**
    * Extract and return as structured log-ready map
    */
   public static Map<String, Object> extractForLog(UnaryOperator<String> headerLookup) {
      return new LinkedHashMap<>(doExtract(headerLookup));
   }

   /**
    * Parse User-Agent into structured components
    */
   public static Map<String, String> parseUserAgent(String ua) {
      if (ua == null || ua.isBlank()) return Map.of();
      var m = new LinkedHashMap<String, String>();
      m.put("raw", ua);

      // Detect common patterns
      if (ua.contains("Dart") || ua.contains("dio")) m.put("platform", "flutter");
      else if (ua.contains("okhttp")) m.put("platform", "android");
      else if (ua.contains("CFNetwork") || ua.contains("Darwin")) m.put("platform", "ios");
      else if (ua.contains("PostmanRuntime")) m.put("platform", "postman");
      else if (ua.contains("curl")) m.put("platform", "curl");
      else if (ua.contains("python-requests")) m.put("platform", "python");
      else if (ua.contains("axios") || ua.contains("node-fetch")) m.put("platform", "nodejs");
      else if (ua.contains("Mozilla")) m.put("platform", "browser");
      else m.put("platform", "unknown");

      // Extract app version if present: "AppName/1.2.3" pattern
      int slashIdx = ua.indexOf('/');
      if (slashIdx > 0 && slashIdx < 50) {
         String prefix = ua.substring(0, slashIdx);
         if (!prefix.contains(" ") && !prefix.equals("Mozilla")) {
            m.put("app", prefix);
            int spaceIdx = ua.indexOf(' ', slashIdx);
            m.put("version", ua.substring(slashIdx + 1, spaceIdx > 0 ? spaceIdx : Math.min(ua.length(), slashIdx + 20)));
         }
      }

      return m;
   }

   /**
    * Clear all gateway MDC entries (servlet only)
    */
   public static void clear() {
      LogContext.remove(CLIENT_IP, USER_AGENT, UA_PLATFORM, GATEWAY_CONSUMER, GATEWAY_ROUTE,
              GATEWAY_SERVICE, GATEWAY_REQUEST_ID, GATEWAY_LATENCY, "auth.user");
   }
   private static Map<String, String> doExtract(UnaryOperator<String> headerLookup) {
      var ctx = new LinkedHashMap<String, String>();

      // Client IP
      for (var h : CLIENT_IP_HEADERS) {
         var v = headerLookup.apply(h);
         if (v != null && !v.isBlank()) {
            var ip = v.contains(",") ? v.substring(0, v.indexOf(',')).trim() : v.trim();
            ctx.put(CLIENT_IP, ip);
            break;
         }
      }

      // User-Agent + platform detection
      var ua = headerLookup.apply("User-Agent");
      if (ua != null && !ua.isBlank()) {
         ctx.put(USER_AGENT, ua);
         var parsed = parseUserAgent(ua);
         if (parsed.containsKey("platform")) ctx.put(UA_PLATFORM, parsed.get("platform"));
      }

      // Kong consumer
      for (var h : KONG_CONSUMER_HEADERS) {
         var v = headerLookup.apply(h);
         if (v != null && !v.isBlank()) {
            ctx.put(GATEWAY_CONSUMER, v);
            break;
         }
      }

      // Kong route/service
      putIfPresent(ctx, GATEWAY_ROUTE, headerLookup.apply("X-Kong-Route-Name"));
      putIfPresent(ctx, GATEWAY_SERVICE, headerLookup.apply("X-Kong-Service-Name"));

      // Gateway request ID
      var reqId = firstNonNull(headerLookup,
              "X-Kong-Request-ID", "X-Request-ID", "X-Amzn-Trace-Id", "CF-Ray");
      if (reqId != null) ctx.put(GATEWAY_REQUEST_ID, reqId);

      // Kong proxy latency
      putIfPresent(ctx, GATEWAY_LATENCY, headerLookup.apply("X-Kong-Proxy-Latency"));

      // Authenticated user
      putIfPresent(ctx, "auth.user", headerLookup.apply("X-Authenticated-User"));

      return ctx;
   }

   private static void putIfPresent(Map<String, String> ctx, String key, String value) {
      if (value != null && !value.isBlank()) ctx.put(key, value);
   }

   private static String firstNonNull(UnaryOperator<String> lookup, String... headers) {
      for (var h : headers) {
         var v = lookup.apply(h);
         if (v != null && !v.isBlank()) return v;
      }
      return null;
   }
}

