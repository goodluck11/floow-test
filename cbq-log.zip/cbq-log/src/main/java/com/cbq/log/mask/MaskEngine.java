package com.cbq.log.mask;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * High-performance masking engine. Caches reflection metadata per class.
 *
 * <p>Three masking approaches:
 * <ol>
 *   <li><b>Annotation-based</b> — reads {@link MaskSensitive} from POJO fields</li>
 *   <li><b>Field-name based</b> — mask by field name set (for JSON strings / Maps)</li>
 *   <li><b>Combined</b> — annotations take precedence, field names as fallback</li>
 * </ol>
 *
 * <pre>{@code
 * // Annotation-based
 * String masked = MaskEngine.mask(payment);              // reads @MaskSensitive on Payment fields
 * Map<String,Object> map = MaskEngine.maskToMap(payment); // same, as Map
 *
 * // Field-name based (for raw JSON)
 * String masked = MaskEngine.maskJson(jsonStr, Set.of("cardNumber", "cvv"), '*');
 *
 * // Combined
 * String masked = MaskEngine.mask(payment, Set.of("extraSecret"), '*');
 * }</pre>
 * <p>
 * Thread-safe. All caches are concurrent.
 */
public final class MaskEngine {

   private static final ObjectMapper MAPPER = new ObjectMapper()
           .registerModule(new JavaTimeModule())
           .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
           .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

   private static final ConcurrentHashMap<Class<?>, List<FieldMaskSpec>> CACHE = new ConcurrentHashMap<>();

   private MaskEngine() {
   }

   // ── Annotation-based masking ─────────────────────────────────────────────

   private static final ObjectMapper PRETTY_MAPPER = new ObjectMapper()
           .registerModule(new JavaTimeModule())
           .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
           .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
           .enable(SerializationFeature.INDENT_OUTPUT);

   public static Map<String, Object> maskMap(Map<?, ?> raw) {
      CbqLogConfig cfg = CbqLog.getConfig();
      return maskMap(raw, cfg != null ? cfg.maskFields() : Set.of(), cfg != null ? cfg.maskSymbol() : '*');
   }

   public static String mask(Object obj) {
      return mask(obj, Set.of(), '*');
   }

   public static String mask(Object obj, Set<String> extra, char sym) {
      if (obj == null) return "null";
      if (obj instanceof String s) return maskJson(s, extra, sym);
      return toJson(maskToMap(obj, extra, sym));
   }

   public static Map<String, Object> maskToMap(Object obj) {
      return maskToMap(obj, Set.of(), '*');
   }

   public static Map<String, Object> maskToMap(Object obj, Set<String> extra, char sym) {
      if (obj == null) return Map.of();
      if (obj instanceof Map<?, ?> raw) return maskMap(raw, extra, sym);
      if (obj instanceof Collection<?> col) {
         return Map.of("items", col.stream().map(o -> maskToMap(o, extra, sym)).toList());
      }

      var cfg = CbqLog.getConfig();
      Set<String> combinedFields = new HashSet<>(extra);
      if (cfg != null) combinedFields.addAll(cfg.maskFields());

      boolean prodOverride = isProdOverride();
      List<FieldMaskSpec> specs = getSpecs(obj.getClass());
      var result = new LinkedHashMap<String, Object>();

      for (var spec : specs) {
         if (spec.exclude) continue;
         Object val;
         try {
            val = spec.field.get(obj);
         } catch (IllegalAccessException e) {
            continue;
         }

         if (spec.masked) {
            int left = (prodOverride && spec.leftVisible > 0) ? 0 : spec.leftVisible;
            int right = (prodOverride && (spec.rightVisible > 0 || spec.visibleChars > 0)) ? 0 : Math.max(spec.rightVisible, spec.visibleChars);
            boolean fully = prodOverride || spec.fullyMask;
            result.put(spec.name, maskValue(val, spec.symbol, left, right, fully));
         } else if (matchesField(spec.name, combinedFields)) {
            int left = (cfg != null) ? cfg.leftVisible() : 0;
            int right = (cfg != null) ? cfg.rightVisible() : 0;
            result.put(spec.name, maskValue(val, sym, left, right, prodOverride));
         } else {
            // Recursive masking for nested objects
            if (val != null && !isPrimitiveOrWrapper(val.getClass()) && !(val instanceof String)) {
               if (val instanceof Map<?, ?> m) {
                  result.put(spec.name, maskMap(m, combinedFields, sym));
               } else if (val instanceof Collection<?> c) {
                  result.put(spec.name, c.stream().map(o -> {
                     if (o == null || isPrimitiveOrWrapper(o.getClass()) || o instanceof String) return o;
                     return maskToMap(o, combinedFields, sym);
                  }).toList());
               } else if (val.getClass().isArray()) {
                  // handle array?
                  result.put(spec.name, val);
               } else {
                  result.put(spec.name, maskToMap(val, combinedFields, sym));
               }
            } else {
               result.put(spec.name, val);
            }
         }
      }
      return result;
   }

   private static boolean isPrimitiveOrWrapper(Class<?> type) {
      return type.isPrimitive() || type == Double.class || type == Float.class || type == Long.class ||
              type == Integer.class || type == Short.class || type == Character.class ||
              type == Byte.class || type == Boolean.class;
   }

   // ── JSON string masking ──────────────────────────────────────────────────

   public static String maskJson(String json, Set<String> fields, char sym) {
      if (json == null || json.isBlank()) return json;
      CbqLogConfig cfg = CbqLog.getConfig();
      Set<String> combinedFields = new HashSet<>(fields);
      if (cfg != null) combinedFields.addAll(cfg.maskFields());

      if (combinedFields.isEmpty()) return json;

      try {
         JsonNode node = MAPPER.readTree(json);
         maskJsonNode(node, combinedFields, sym, "");
         return toJson(node);
      } catch (JsonProcessingException e) {
         return json;
      }
   }

   /**
    * Mask with both field names and JSON paths (e.g. "payment.card.number")
    */
   public static String maskJson(String json, Set<String> fields, Set<String> jsonPaths, char sym) {
      if (json == null || json.isBlank()) return json;
      CbqLogConfig cfg = CbqLog.getConfig();
      Set<String> combinedFields = new HashSet<>(fields);
      Set<String> combinedPaths = new HashSet<>(jsonPaths);
      if (cfg != null) {
         combinedFields.addAll(cfg.maskFields());
         combinedPaths.addAll(cfg.maskJsonPaths());
      }

      if (combinedFields.isEmpty() && combinedPaths.isEmpty()) return json;
      try {
         JsonNode node = MAPPER.readTree(json);
         maskJsonNode(node, combinedFields, sym, "");
         for (String path : combinedPaths) maskByPath(node, path.split("\\."), 0, sym);
         return toJson(node);
      } catch (JsonProcessingException e) {
         return json;
      }
   }

   // ── Header masking ───────────────────────────────────────────────────────

   public static String maskHeader(String name, String value, Set<String> sensitive, char sym) {
      if (name == null || value == null) return value;
      if (name.equalsIgnoreCase("Authorization"))
         return value.length() > 10 ? value.substring(0, Math.min(7, value.length())) + "..." + rep(sym, 4) : rep(sym, value.length());

      CbqLogConfig cfg = CbqLog.getConfig();
      Set<String> combinedFields = new HashSet<>(sensitive);
      if (cfg != null) combinedFields.addAll(cfg.maskFields());

      if (matchesField(name, combinedFields)) return rep(sym, Math.max(value.length(), 4));
      return value;
   }

   // ── JSON path masking ────────────────────────────────────────────────────

   private static void maskByPath(JsonNode node, String[] segments, int idx, char sym) {
      if (node == null || idx >= segments.length) return;

      String seg = segments[idx];

      if (node.isArray()) {
         for (JsonNode el : node) maskByPath(el, segments, idx, sym);
         return;
      }

      if (!node.isObject()) return;

      ObjectNode obj = (ObjectNode) node;
      if (idx == segments.length - 1) {
         // Terminal: mask this field
         JsonNode target = obj.get(seg);
         if (target != null) {
            if (target.isArray()) {
               for (int i = 0; i < target.size(); i++) {
                  JsonNode item = target.get(i);
                  if (item.isValueNode()) {
                     ((com.fasterxml.jackson.databind.node.ArrayNode) target).set(i, new TextNode(String.valueOf(maskValue(item.asText(""), sym, getLeft(), getRight(), false))));
                  } else {
                     // Array of objects - if we are at terminal path but it's an array of objects, 
                     // usually means we might want to mask the whole object or we have a wrong path.
                     // But based on requirements, let's just mask values.
                     maskJsonNode(item, Set.of(), sym, "");
                  }
               }
            } else if (target.isObject()) {
               maskJsonNode(target, Set.of(), sym, "");
            } else {
               obj.set(seg, new TextNode(String.valueOf(maskValue(target.asText(""), sym, getLeft(), getRight(), false))));
            }
         }
      } else {
         // Traverse deeper
         JsonNode child = obj.get(seg);
         if (child != null) maskByPath(child, segments, idx + 1, sym);
      }
   }

   private static int getLeft() {
      CbqLogConfig cfg = CbqLog.getConfig();
      return (cfg != null) ? cfg.leftVisible() : 0;
   }

   private static int getRight() {
      CbqLogConfig cfg = CbqLog.getConfig();
      return (cfg != null) ? cfg.rightVisible() : 0;
   }

   // ── Internals ────────────────────────────────────────────────────────────

   private static List<FieldMaskSpec> getSpecs(Class<?> clazz) {
      return CACHE.computeIfAbsent(clazz, MaskEngine::buildSpecs);
   }

   private static List<FieldMaskSpec> buildSpecs(Class<?> clazz) {
      var specs = new ArrayList<FieldMaskSpec>();
      for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
         for (Field f : c.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (!f.trySetAccessible()) continue;

            MaskSensitive ann = f.getAnnotation(MaskSensitive.class);
            if (ann != null)
               specs.add(new FieldMaskSpec(f, f.getName(), true, ann.maskSymbol(), ann.visibleChars(), ann.leftVisible(), ann.rightVisible(), ann.fullyMask(), ann.exclude()));
            else specs.add(new FieldMaskSpec(f, f.getName(), false, '*', 0, 0, 0, false, false));
         }
      }
      return List.copyOf(specs);
   }

   private record FieldMaskSpec(Field field, String name, boolean masked, char symbol, int visibleChars,
                                int leftVisible, int rightVisible, boolean fullyMask, boolean exclude) {
   }

   static Object maskValue(Object val, char symbol, int left, int right, boolean fully) {
      if (val == null) return null;
      String s = val.toString();
      if (s.isEmpty()) return "";

      // If we are in production override, or requested full masking, or if the string is too short to show requested chars
      // then we mask the whole thing.
      if (fully || (left <= 0 && right <= 0) || (s.length() <= left + right)) {
         return rep(symbol, Math.max(s.length(), 3));
      }

      StringBuilder sb = new StringBuilder();
      if (left > 0) sb.append(s, 0, left);
      sb.append(rep(symbol, s.length() - left - right));
      if (right > 0) sb.append(s.substring(s.length() - right));
      return sb.toString();
   }

   public static Map<String, Object> maskMap(Map<?, ?> raw, Set<String> fields, char sym) {
      var result = new LinkedHashMap<String, Object>();
      CbqLogConfig cfg = CbqLog.getConfig();
      int left = (cfg != null) ? cfg.leftVisible() : 0;
      int right = (cfg != null) ? cfg.rightVisible() : 0;
      boolean prodOverride = isProdOverride();

      Set<String> combinedFields = new HashSet<>(fields);
      if (cfg != null) combinedFields.addAll(cfg.maskFields());

      raw.forEach((k, v) -> {
         String key = String.valueOf(k);
         if (matchesField(key, combinedFields)) {
            if (v instanceof String s) {
               result.put(key, maskHeader(key, s, combinedFields, sym));
            } else {
               result.put(key, maskValue(v, sym, left, right, prodOverride));
            }
         } else {
            result.put(key, v);
         }
      });
      return result;
   }

   private static void maskJsonNode(JsonNode node, Set<String> fields, char sym, String prefix) {
      if (node.isObject()) {
         ObjectNode obj = (ObjectNode) node;
         var it = obj.fields();
         CbqLogConfig cfg = CbqLog.getConfig();
         int left = (cfg != null) ? cfg.leftVisible() : 0;
         int right = (cfg != null) ? cfg.rightVisible() : 0;
         boolean prodOverride = isProdOverride();

         while (it.hasNext()) {
            var e = it.next();
            if (matchesField(e.getKey(), fields)) {
               obj.set(e.getKey(), new TextNode(String.valueOf(maskValue(e.getValue().asText(""), sym, left, right, prodOverride))));
            } else {
               maskJsonNode(e.getValue(), fields, sym, prefix.isEmpty() ? e.getKey() : prefix + "." + e.getKey());
            }
         }
      } else if (node.isArray()) {
         for (JsonNode el : node) maskJsonNode(el, fields, sym, prefix);
      }
   }

   private static boolean matchesField(String name, Set<String> fields) {
      for (String f : fields) if (name.equalsIgnoreCase(f)) return true;
      return false;
   }

   private static boolean isProdOverride() {
      try {
         var cfg = CbqLog.getConfig();
         return cfg != null && cfg.prodMaskOverride() && cfg.isProduction();
      } catch (Exception e) {
         return false;
      }
   }

   static String rep(char c, int n) {
      return String.valueOf(c).repeat(Math.max(n, 1));
   }

   public static String toJson(Object obj) {
      try {
         var cfg = CbqLog.getConfig();
         if (cfg != null && (cfg.format() == CbqLogConfig.LogFormat.PRETTY || cfg.format() == CbqLogConfig.LogFormat.PRETTY_TEXT)) {
            return PRETTY_MAPPER.writeValueAsString(obj);
         }
         return MAPPER.writeValueAsString(obj);
      } catch (JsonProcessingException e) {
         return String.valueOf(obj);
      }
   }
}