package com.cbq.log.mask;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * High-performance masking engine. Caches reflection metadata per class.
 *
 * <p>Three masking approaches:
 * <ol>
 *   <li><b>Annotation-based</b> — reads {@link MaskSensitive} from POJO fields</li>
 *   <li><b>Field-name based</b> — mask by field name set (for JSON strings / Maps)</li>
 *   <li><b>Combined</b> — annotations take precedence, field names as fallback</li>
 * </ol>
 *
 * <pre>{@code
 * // Annotation-based
 * String masked = MaskEngine.mask(payment);              // reads @MaskSensitive on Payment fields
 * Map<String,Object> map = MaskEngine.maskToMap(payment); // same, as Map
 *
 * // Field-name based (for raw JSON)
 * String masked = MaskEngine.maskJson(jsonStr, Set.of("cardNumber", "cvv"), '*');
 *
 * // Combined
 * String masked = MaskEngine.mask(payment, Set.of("extraSecret"), '*');
 * }</pre>
 * <p>
 * Thread-safe. All caches are concurrent.
 */
public final class MaskEngine {

   private static final ObjectMapper MAPPER = new ObjectMapper()
           .registerModule(new JavaTimeModule())
           .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
           .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

   private static final ConcurrentHashMap<Class<?>, List<FieldMaskSpec>> CACHE = new ConcurrentHashMap<>();

   private MaskEngine() {
   }

   // ── Annotation-based masking ─────────────────────────────────────────────

   public static String mask(Object obj) {
      return mask(obj, Set.of(), '*');
   }

   public static String mask(Object obj, Set<String> extra, char sym) {
      if (obj == null) return "null";
      if (obj instanceof String s) return maskJson(s, extra, sym);
      return toJson(maskToMap(obj, extra, sym));
   }

   public static Map<String, Object> maskToMap(Object obj) {
      return maskToMap(obj, Set.of(), '*');
   }

   public static Map<String, Object> maskToMap(Object obj, Set<String> extra, char sym) {
      if (obj == null) return Map.of();
      if (obj instanceof Map<?, ?> raw) return maskMap(raw, extra, sym);

      boolean prodOverride = isProdOverride();
      List<FieldMaskSpec> specs = getSpecs(obj.getClass());
      var result = new LinkedHashMap<String, Object>();

      for (var spec : specs) {
         if (spec.exclude) continue;
         Object val;
         try {
            val = spec.field.get(obj);
         } catch (IllegalAccessException e) {
            continue;
         }
         if (spec.masked) {
            int visible = (prodOverride && spec.visibleChars > 0) ? 0 : spec.visibleChars;
            boolean fully = prodOverride || spec.fullyMask;
            result.put(spec.name, maskValue(val, spec.symbol, visible, fully));
         } else if (matchesField(spec.name, extra)) {
            result.put(spec.name, maskValue(val, sym, 0, true));
         } else {
            result.put(spec.name, val);
         }
      }
      return result;
   }

   // ── JSON string masking ──────────────────────────────────────────────────

   public static String maskJson(String json, Set<String> fields, char sym) {
      if (json == null || json.isBlank() || fields.isEmpty()) return json;
      try {
         JsonNode node = MAPPER.readTree(json);
         maskJsonNode(node, fields, sym, "");
         return MAPPER.writeValueAsString(node);
      } catch (JsonProcessingException e) {
         return json;
      }
   }

   /**
    * Mask with both field names and JSON paths (e.g. "payment.card.number")
    */
   public static String maskJson(String json, Set<String> fields, Set<String> jsonPaths, char sym) {
      if (json == null || json.isBlank()) return json;
      if (fields.isEmpty() && jsonPaths.isEmpty()) return json;
      try {
         JsonNode node = MAPPER.readTree(json);
         maskJsonNode(node, fields, sym, "");
         for (String path : jsonPaths) maskByPath(node, path.split("\\."), 0, sym);
         return MAPPER.writeValueAsString(node);
      } catch (JsonProcessingException e) {
         return json;
      }
   }

   // ── Header masking ───────────────────────────────────────────────────────

   public static String maskHeader(String name, String value, Set<String> sensitive, char sym) {
      if (name == null || value == null) return value;
      if (name.equalsIgnoreCase("Authorization"))
         return value.length() > 10 ? value.substring(0, Math.min(7, value.length())) + "..." + rep(sym, 4) : rep(sym, value.length());
      if (matchesField(name, sensitive)) return rep(sym, Math.max(value.length(), 4));
      return value;
   }

   // ── JSON path masking ────────────────────────────────────────────────────

   private static void maskByPath(JsonNode node, String[] segments, int idx, char sym) {
      if (node == null || !node.isObject() || idx >= segments.length) return;
      ObjectNode obj = (ObjectNode) node;
      String seg = segments[idx];
      if (idx == segments.length - 1) {
         // Terminal: mask this field
         JsonNode target = obj.get(seg);
         if (target != null) obj.set(seg, new TextNode(rep(sym, Math.max(target.asText("").length(), 3))));
      } else {
         // Traverse deeper
         JsonNode child = obj.get(seg);
         if (child != null) maskByPath(child, segments, idx + 1, sym);
      }
   }

   // ── Internals ────────────────────────────────────────────────────────────

   private static List<FieldMaskSpec> getSpecs(Class<?> clazz) {
      return CACHE.computeIfAbsent(clazz, MaskEngine::buildSpecs);
   }

   private static List<FieldMaskSpec> buildSpecs(Class<?> clazz) {
      var specs = new ArrayList<FieldMaskSpec>();
      for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
         for (Field f : c.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (!f.trySetAccessible()) continue;

            MaskSensitive ann = f.getAnnotation(MaskSensitive.class);
            if (ann != null)
               specs.add(new FieldMaskSpec(f, f.getName(), true, ann.maskSymbol(), ann.visibleChars(), ann.fullyMask(), ann.exclude()));
            else specs.add(new FieldMaskSpec(f, f.getName(), false, '*', 0, false, false));
         }
      }
      return List.copyOf(specs);
   }

   private record FieldMaskSpec(Field field, String name, boolean masked, char symbol, int visibleChars,
                                boolean fullyMask, boolean exclude) {
   }

   static Object maskValue(Object val, char symbol, int visible, boolean fully) {
      if (val == null) return null;
      String s = val.toString();
      if (s.isEmpty()) return "";
      if (fully || visible <= 0) return rep(symbol, Math.max(s.length(), 3));
      if (visible >= s.length()) return rep(symbol, 3) + s;
      return rep(symbol, s.length() - visible) + s.substring(s.length() - visible);
   }

   private static Map<String, Object> maskMap(Map<?, ?> raw, Set<String> fields, char sym) {
      var result = new LinkedHashMap<String, Object>();
      raw.forEach((k, v) -> {
         String key = String.valueOf(k);
         result.put(key, matchesField(key, fields) ? maskValue(v, sym, 0, true) : v);
      });
      return result;
   }

   private static void maskJsonNode(JsonNode node, Set<String> fields, char sym, String prefix) {
      if (node.isObject()) {
         ObjectNode obj = (ObjectNode) node;
         var it = obj.fields();
         while (it.hasNext()) {
            var e = it.next();
            if (matchesField(e.getKey(), fields))
               obj.set(e.getKey(), new TextNode(rep(sym, Math.max(e.getValue().asText("").length(), 3))));
            else maskJsonNode(e.getValue(), fields, sym, prefix.isEmpty() ? e.getKey() : prefix + "." + e.getKey());
         }
      } else if (node.isArray()) {
         for (JsonNode el : node) maskJsonNode(el, fields, sym, prefix);
      }
   }

   private static boolean matchesField(String name, Set<String> fields) {
      for (String f : fields) if (name.equalsIgnoreCase(f)) return true;
      return false;
   }

   private static boolean isProdOverride() {
      try {
         CbqLogConfig cfg = CbqLog.getConfig();
         return cfg != null && cfg.prodMaskOverride() && cfg.isProduction();
      } catch (Exception e) {
         return false;
      }
   }

   static String rep(char c, int n) {
      return String.valueOf(c).repeat(Math.max(n, 1));
   }

   static String toJson(Object obj) {
      try {
         return MAPPER.writeValueAsString(obj);
      } catch (JsonProcessingException e) {
         return String.valueOf(obj);
      }
   }
}