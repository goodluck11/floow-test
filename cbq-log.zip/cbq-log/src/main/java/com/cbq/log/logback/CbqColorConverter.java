package com.cbq.log.logback;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import org.springframework.boot.logging.logback.ColorConverter;

/**
 * Custom color converter that provides distinct colors for TRACE and DEBUG levels.
 * Standard Spring ColorConverter uses Green for TRACE, DEBUG, and INFO.
 */
public class CbqColorConverter extends ColorConverter {

    @Override
    protected String transform(ILoggingEvent event, String in) {
        Level level = event.getLevel();
        String colorCode = switch (level.toInt()) {
            case Level.ERROR_INT -> "31"; // Red
            case Level.WARN_INT -> "33";  // Yellow
            case Level.INFO_INT -> "32";  // Green
            case Level.DEBUG_INT -> "35"; // Magenta
            case Level.TRACE_INT -> "36"; // Cyan
            default -> null;
        };

        if (colorCode == null) {
            return super.transform(event, in);
        }

        return "\033[" + colorCode + "m" + in + "\033[0;39m";
    }
}
