package com.cbq.log.timed;

import com.cbq.log.core.CbqLog;
import com.cbq.log.metrics.LogMetrics;

/**
 * AutoCloseable timed operation. Logs duration + success/failure on close.
 *
 * <pre>{@code
 * try (var op = TimedOp.start(log, "db", "findUser")) {
 *     User u = repo.findById(id);
 *     op.detail("userId=" + id);
 * }
 * // auto-logs: {"type":"task","task_type":"db","operation":"findUser","duration_ms":12,"success":true,"detail":"userId=42"}
 *
 * // On exception: auto-logs success=false with error detail
 * try (var op = TimedOp.start(log, "cache", "getSession")) {
 *     throw new RuntimeException("timeout");
 * }
 * // auto-logs: {"task_type":"cache","operation":"getSession","duration_ms":5003,"success":false,"detail":"timeout"}
 * }</pre>
 */
public final class TimedOp implements AutoCloseable {
   private final CbqLog logger;
   private final String taskType;
   private final String operation;
   private final String target;
   private final long startNanos;
   private String detail;
   private boolean success = true;
   private boolean closed = false;

   private TimedOp(CbqLog logger, String taskType, String operation, String target) {
      this.logger = logger;
      this.taskType = taskType;
      this.operation = operation;
      this.target = target;
      this.startNanos = System.nanoTime();
   }

   public static TimedOp start(CbqLog logger, String taskType, String operation) {
      return new TimedOp(logger, taskType, operation, null);
   }

   public static TimedOp start(CbqLog logger, String taskType, String operation, String target) {
      return new TimedOp(logger, taskType, operation, target);
   }

   public TimedOp detail(String d) {
      this.detail = d;
      return this;
   }

   public TimedOp target(String t) {
      return new TimedOp(logger, taskType, operation, t);
   }

   public TimedOp fail() {
      this.success = false;
      return this;
   }

   public TimedOp fail(String reason) {
      this.success = false;
      this.detail = reason;
      return this;
   }

   public long elapsedMs() {
      return (System.nanoTime() - startNanos) / 1_000_000;
   }

   @Override
   public void close() {
      if (closed) return;
      closed = true;
      long ms = elapsedMs();
      // Check for suppressed/uncaught exception to auto-detect failure
      // We detect this via Throwable inspection not possible in close() directly,
      // so we rely on try-with-resources behavior: if exception thrown, success is set via fail()
      logger.task(taskType, operation, target != null ? target : "", ms, success, detail);
      LogMetrics.recordTask(taskType, operation, ms, success);
   }

   /**
    * Execute a runnable as a timed block, auto-detecting failure.
    * <pre>{@code
    * TimedOp.run(log, "db", "save", "orders", () -> repo.save(order));
    * }</pre>
    */
   public static void run(CbqLog logger, String taskType, String op, String target, Runnable task) {
      try (var t = start(logger, taskType, op, target)) {
         try {
            task.run();
         } catch (Exception e) {
            t.fail(e.getMessage());
            throw e;
         }
      }
   }

   /**
    * Execute a callable as a timed block, auto-detecting failure.
    * <pre>{@code
    * User u = TimedOp.call(log, "db", "findById", "users", () -> repo.findById(id));
    * }</pre>
    */
   public static <T> T call(CbqLog logger, String taskType, String op, String target, java.util.concurrent.Callable<T> task) {
      try (var t = start(logger, taskType, op, target)) {
         try {
            return task.call();
         } catch (Exception e) {
            t.fail(e.getMessage());
            throw new RuntimeException(e);
         }
      }
   }
}