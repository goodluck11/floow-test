package com.cbq.log.config;

import com.cbq.log.async.AsyncLogWriter;
import com.cbq.log.mask.MaskProfile;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Immutable configuration for CbqLog. Fluent builder.
 *
 * <pre>{@code
 * CbqLogConfig.builder()
 *     .serviceName("payment-service")
 *     .jsonFormat()
 *     .async(true)
 *     .maskProfile(MaskProfile.PCI)
 *     .maskProfile(MaskProfile.KONG_GATEWAY)
 *     .maskFields("customField")
 *     .maskJsonPaths("payment.card.number", "user.ssn")
 *     .environment("production")       // prod = force fullyMask override
 *     .slowQueryThresholdMs(500)
 *     .defaultSampleRate(1.0)
 *     .build();
 * }</pre>
 */
public record CbqLogConfig(
        String serviceName,
        LogFormat format,
        boolean async,
        Set<String> maskFields,
        Set<String> maskJsonPaths,
        char maskSymbol,
        int leftVisible,
        int rightVisible,
        int maxBodySize,
        String correlationKey,
        String requestIdKey,
        boolean includeCallerInfo,
        String environment,
        long slowQueryThresholdMs,
        double defaultSampleRate,
        boolean prodMaskOverride,
        int asyncCorePoolSize,
        int asyncMaxPoolSize,
        int asyncQueueCapacity,
        Set<String> mdcFields
) {
   public enum LogFormat {TEXT, JSON, PRETTY, PRETTY_TEXT}

   public boolean isProduction() {
      return environment != null && (environment.equalsIgnoreCase("production")
              || environment.equalsIgnoreCase("prod") || environment.equalsIgnoreCase("live"));
   }

   public static CbqLogConfig defaults() {
      return new CbqLogConfig("app", LogFormat.JSON, true, Set.of(), Set.of(), '*', 0, 0, 4096,
              "correlationId", "requestId", false, "default", 500, 1.0,
              false, 4, 16, 5000, Set.of());
   }

   public static Builder builder() {
      return new Builder();
   }

   public static final class Builder {
      private String serviceName = "app";
      private LogFormat format = LogFormat.JSON;
      private boolean async = true;
      private final Set<String> maskFields = new LinkedHashSet<>();
      private final Set<String> maskJsonPaths = new LinkedHashSet<>();
      private char maskSymbol = '*';
      private int leftVisible = 0;
      private int rightVisible = 0;
      private int maxBodySize = 4096;
      private String correlationKey = "correlationId";
      private String requestIdKey = "requestId";
      private boolean includeCallerInfo = false;
      private String environment = "default";
      private long slowQueryThresholdMs = 500;
      private double defaultSampleRate = 1.0;
      private boolean prodMaskOverride = false;
      private int asyncCorePoolSize = 2;
      private int asyncMaxPoolSize = 4;
      private int asyncQueueCapacity = 5000;
      private final Set<String> mdcFields = new LinkedHashSet<>();

      public Builder serviceName(String v) {
         this.serviceName = v;
         return this;
      }

      public Builder jsonFormat() {
         this.format = LogFormat.JSON;
         return this;
      }

      public Builder textFormat() {
         this.format = LogFormat.TEXT;
         return this;
      }

      public Builder prettyFormat() {
         this.format = LogFormat.PRETTY;
         return this;
      }

      public Builder prettyTextFormat() {
         this.format = LogFormat.PRETTY_TEXT;
         return this;
      }

      public Builder async(boolean v) {
         this.async = v;
         return this;
      }

      public Builder sync() {
         this.async = false;
         return this;
      }

      public Builder maskFields(String... f) {
         Collections.addAll(maskFields, f);
         return this;
      }

      public Builder maskProfile(MaskProfile p) {
         maskFields.addAll(p.fields());
         return this;
      }

      public Builder maskJsonPaths(String... p) {
         Collections.addAll(maskJsonPaths, p);
         return this;
      }

      public Builder maskSymbol(char c) {
         this.maskSymbol = c;
         return this;
      }
      
      public Builder leftVisible(int v) {
         this.leftVisible = v;
         return this;
      }
      
      public Builder rightVisible(int v) {
         this.rightVisible = v;
         return this;
      }

      public Builder maxBodySize(int v) {
         this.maxBodySize = v;
         return this;
      }

      public Builder correlationKey(String v) {
         this.correlationKey = v;
         return this;
      }

      public Builder requestIdKey(String v) {
         this.requestIdKey = v;
         return this;
      }

      public Builder includeCallerInfo(boolean v) {
         this.includeCallerInfo = v;
         return this;
      }

      public Builder environment(String v) {
         this.environment = v;
         return this;
      }

      public Builder slowQueryThresholdMs(long v) {
         this.slowQueryThresholdMs = v;
         return this;
      }

      public Builder defaultSampleRate(double v) {
         this.defaultSampleRate = v;
         return this;
      }

      public Builder prodMaskOverride(boolean v) {
         this.prodMaskOverride = v;
         return this;
      }

      public Builder asyncCorePoolSize(int v) {
         this.asyncCorePoolSize = v;
         return this;
      }

      public Builder asyncMaxPoolSize(int v) {
         this.asyncMaxPoolSize = v;
         return this;
      }

      public Builder asyncQueueCapacity(int v) {
         this.asyncQueueCapacity = v;
         return this;
      }

      public Builder mdcFields(String... f) {
         Collections.addAll(mdcFields, f);
         return this;
      }

      public CbqLogConfig build() {
         return new CbqLogConfig(serviceName, format, async, Set.copyOf(maskFields), Set.copyOf(maskJsonPaths),
                 maskSymbol, leftVisible, rightVisible, maxBodySize, correlationKey, requestIdKey, includeCallerInfo,
                 environment, slowQueryThresholdMs, defaultSampleRate, prodMaskOverride,
                 asyncCorePoolSize, asyncMaxPoolSize, asyncQueueCapacity, Set.copyOf(mdcFields));
      }
   }

//   @PreDestroy
   public void shutdown() {
      AsyncLogWriter.shutdown();
   }
}



