package com.cbq.log.db;

import com.cbq.log.context.LogContext;
import com.cbq.log.core.CbqLog;
import com.cbq.log.metrics.LogMetrics;
import io.r2dbc.spi.*;
import org.reactivestreams.Publisher;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.time.Duration;
import java.util.Map;
import java.util.function.Function;

/**
 * R2DBC ConnectionFactory wrapper for non-blocking performance logging.
 * Safe with {@code r2dbc-pool} — wraps each Connection in a lightweight decorator
 * that delegates all calls to the real {@code PooledConnection} while observing
 * {@code close()} for release tracking.
 *
 * <p>For correlation ID propagation in reactive chains, you must set the correlation
 * and request IDs in the Reactor subscriber context via {@link #contextWrite(String, String)}.
 * This is typically done in a WebFilter:
 * <pre>{@code
 * @Component
 * public class CorrelationWebFilter implements WebFilter {
 *     public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
 *         String corrId = exchange.getRequest().getHeaders().getFirst("X-Correlation-ID");
 *         if (corrId == null) corrId = UUID.randomUUID().toString();
 *         String reqId = UUID.randomUUID().toString();
 *         return chain.filter(exchange)
 *                 .contextWrite(R2dbcLogListener.contextWrite(corrId, reqId));
 *     }
 * }
 * }</pre>
 *
 * <h3>Usage:</h3>
 * <pre>{@code
 * @Bean
 * public DatabaseClient databaseClient(ConnectionFactory connectionFactory) {
 *     return DatabaseClient.builder()
 *             .connectionFactory(R2dbcLogListener.wrap(connectionFactory))
 *             .build();
 * }
 * }</pre>
 */
/**
 * R2DBC ConnectionFactory wrapper for non-blocking performance logging.
 * Safe with {@code r2dbc-pool} — wraps each Connection in a lightweight decorator
 * that delegates all calls to the real {@code PooledConnection} while observing
 * {@code close()} for release tracking.
 *
 * <p>For correlation ID propagation in reactive chains, you must set the correlation
 * and request IDs in the Reactor subscriber context via {@link #contextWrite(String, String)}.
 * This is typically done in a WebFilter:
 * <pre>{@code
 * @Component
 * public class CorrelationWebFilter implements WebFilter {
 *     public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
 *         String corrId = exchange.getRequest().getHeaders().getFirst("X-Correlation-ID");
 *         if (corrId == null) corrId = UUID.randomUUID().toString();
 *         String reqId = UUID.randomUUID().toString();
 *         return chain.filter(exchange)
 *                 .contextWrite(R2dbcLogListener.contextWrite(corrId, reqId));
 *     }
 * }
 * }</pre>
 *
 * <h3>Usage:</h3>
 * <pre>{@code
 * @Bean
 * public DatabaseClient databaseClient(ConnectionFactory connectionFactory) {
 *     return DatabaseClient.builder()
 *             .connectionFactory(R2dbcLogListener.wrap(connectionFactory))
 *             .build();
 * }
 * }</pre>
 */
public final class R2dbcLogListener implements ConnectionFactory {

   private static final CbqLog log = CbqLog.getLogger("cbq.r2dbc");
   private static volatile long slowQueryMs = LogMetrics.getSlowQueryThreshold();

   // Reactor Context keys for correlation propagation
   static final String CTX_CORR_ID = "cbq.correlationId";
   static final String CTX_REQ_ID = "cbq.requestId";

   private final ConnectionFactory delegate;

   private R2dbcLogListener(ConnectionFactory delegate) {
      this.delegate = delegate;
   }

   public static ConnectionFactory wrap(ConnectionFactory delegate) {
      return new R2dbcLogListener(delegate);
   }

   /** @deprecated Use {@link #wrap(ConnectionFactory)} instead */
   @Deprecated
   public static Object wrapConnectionFactory(Object connectionFactory) {
      return wrap((ConnectionFactory) connectionFactory);
   }

   public static void setSlowQueryThreshold(long ms) { slowQueryMs = ms; }

   /**
    * Returns a context modifier for Reactor's {@code contextWrite()}.
    * Use in a WebFilter to propagate correlation/request IDs through the reactive chain.
    * <pre>{@code
    * return chain.filter(exchange)
    *         .contextWrite(R2dbcLogListener.contextWrite(corrId, reqId));
    * }</pre>
    */
   public static Function<reactor.util.context.Context, reactor.util.context.Context> contextWrite(String corrId, String reqId) {
      return ctx -> {
         if (corrId != null) ctx = ctx.put(CTX_CORR_ID, corrId);
         if (reqId != null) ctx = ctx.put(CTX_REQ_ID, reqId);
         return ctx;
      };
   }

   // ── ConnectionFactory implementation ─────────────────────────────────────

   @Override
   public Mono<? extends Connection> create() {
      long acquireStart = System.nanoTime();

      // Use deferContextual to read correlation from Reactor Context (not MDC)
      return Mono.deferContextual(ctx -> {
         String corrId = ctx.getOrDefault(CTX_CORR_ID, LogContext.getCorrelationId());
         String reqId = ctx.getOrDefault(CTX_REQ_ID, LogContext.getRequestId());
         Map<String, String> gwCtx = ctx.getOrDefault(
                 com.cbq.log.gateway.GatewayContext.REACTOR_CTX_KEY, Map.of());

         return Mono.from(delegate.create())
                 .map(conn -> {
                    long acquireMs = ms(acquireStart);
                    LogMetrics.recordTask("r2dbc", "pool.acquire", acquireMs, true);
                    log.info("R2DBC connection acquired", "event", "pool.acquire",
                            "wait_ms", acquireMs, "cid", corrId, "rid", reqId,
                            "client_ip", gwCtx.get("client_ip"), "ua_platform", gwCtx.get("ua_platform"));
                    if (acquireMs > slowQueryMs) {
                       log.warn("Slow R2DBC connection acquire", "event", "pool.acquire",
                               "wait_ms", acquireMs, "cid", corrId, "rid", reqId);
                    }
                    // Wrap with a decorator that intercepts close() for release tracking
                    return (Connection) new ObservedConnection(conn, System.nanoTime(), acquireMs, corrId, reqId, gwCtx);
                 })
                 .doOnError(t -> {
                    long acquireMs = ms(acquireStart);
                    LogMetrics.recordTask("r2dbc", "pool.acquire", acquireMs, false);
                    log.error("R2DBC connection acquire failed", "event", "pool.acquire",
                            "wait_ms", acquireMs, "cid", corrId, "error", t.getMessage());
                 });
      });
   }

   @Override
   public ConnectionFactoryMetadata getMetadata() {
      return delegate.getMetadata();
   }

   // ── Connection decorator (intercepts close + createStatement) ─────────────

   /**
    * Thin decorator over the real Connection (including PooledConnection).
    * Delegates ALL methods to the real connection. Only adds logging to
    * {@code close()} and {@code createStatement()}.
    *
    * <p>Implements {@code Wrapped<Connection>} so frameworks can unwrap if needed,
    * and the pool's internal lifecycle management continues to work because
    * we delegate {@code close()} to the real PooledConnection which handles
    * returning to the pool.
    */
   static final class ObservedConnection implements Connection, Wrapped<Connection> {
      private final Connection real;
      private final long acquiredAt;
      private final long acquireWaitMs;
      private final String corrId;
      private final String reqId;
      private final Map<String, String> gwCtx;

      ObservedConnection(Connection real, long acquiredAt, long acquireWaitMs,
                         String corrId, String reqId, Map<String, String> gwCtx) {
         this.real = real; this.acquiredAt = acquiredAt; this.acquireWaitMs = acquireWaitMs;
         this.corrId = corrId; this.reqId = reqId; this.gwCtx = gwCtx;
      }

      @Override
      public Connection unwrap() { return real; }

      // ── close: log release ──

      @Override
      public Publisher<Void> close() {
         long holdMs = ms(acquiredAt);
         return Mono.from(real.close())
                 .doOnSuccess(v -> {
                    LogMetrics.recordTask("r2dbc", "pool.release", holdMs, true);
                    log.info("R2DBC connection released", "event", "pool.release",
                            "hold_ms", holdMs, "acquire_wait_ms", acquireWaitMs,
                            "cid", corrId, "rid", reqId,
                            "client_ip", gwCtx.get("client_ip"), "ua_platform", gwCtx.get("ua_platform"));
                    if (holdMs > slowQueryMs * 5) {
                       log.warn("Long R2DBC connection hold", "event", "pool.release",
                               "hold_ms", holdMs, "acquire_wait_ms", acquireWaitMs,
                               "cid", corrId, "rid", reqId);
                    }
                 })
                 .doOnError(t -> {
                    LogMetrics.recordTask("r2dbc", "pool.release", holdMs, false);
                    log.error("R2DBC connection release failed", "event", "pool.release",
                            "hold_ms", holdMs, "error", t.getMessage(),
                            "cid", corrId, "rid", reqId);
                 });
      }

      // ── createStatement: wrap for query timing ──

      @Override
      public Statement createStatement(String sql) {
         Statement stmt = real.createStatement(sql);
         return new ObservedStatement(stmt, sql, corrId, reqId, gwCtx);
      }

      // ── Pure delegation ──

      @Override public Publisher<Void> beginTransaction()                 { return real.beginTransaction(); }
      @Override public Publisher<Void> beginTransaction(TransactionDefinition def) { return real.beginTransaction(def); }
      @Override public Publisher<Void> commitTransaction()                { return real.commitTransaction(); }
      @Override public Publisher<Void> rollbackTransaction()              { return real.rollbackTransaction(); }
      @Override public Publisher<Void> rollbackTransactionToSavepoint(String name) { return real.rollbackTransactionToSavepoint(name); }
      @Override public Publisher<Void> createSavepoint(String name)       { return real.createSavepoint(name); }
      @Override public Publisher<Void> releaseSavepoint(String name)      { return real.releaseSavepoint(name); }
      @Override public boolean isAutoCommit()                             { return real.isAutoCommit(); }
      @Override public Publisher<Void> setAutoCommit(boolean autoCommit)  { return real.setAutoCommit(autoCommit); }
      @Override public Publisher<Void> setTransactionIsolationLevel(IsolationLevel level) { return real.setTransactionIsolationLevel(level); }
      @Override public IsolationLevel getTransactionIsolationLevel()      { return real.getTransactionIsolationLevel(); }
      @Override public Publisher<Void> setLockWaitTimeout(Duration t)     { return real.setLockWaitTimeout(t); }
      @Override public Publisher<Void> setStatementTimeout(Duration t)    { return real.setStatementTimeout(t); }
      @Override public Batch createBatch()                                { return real.createBatch(); }
      @Override public ConnectionMetadata getMetadata()                   { return real.getMetadata(); }
      @Override public Publisher<Boolean> validate(ValidationDepth depth) { return real.validate(depth); }
   }

   // ── Statement decorator (auto query timing) ──────────────────────────────

   /**
    * Wraps a Statement to automatically time {@code execute()} calls.
    * Every query gets logged at DEBUG with timing. Slow queries get WARN.
    */
   static final class ObservedStatement implements Statement {
      private final Statement real;
      private final String sql;
      private final String corrId;
      private final String reqId;
      private final Map<String, String> gwCtx;

      ObservedStatement(Statement real, String sql, String corrId, String reqId, Map<String, String> gwCtx) {
         this.real = real; this.sql = sql; this.corrId = corrId; this.reqId = reqId; this.gwCtx = gwCtx;
      }

      @Override
      public Publisher<? extends Result> execute() {
         long start = System.nanoTime();
         String op = DbLogProxyDataSource.classifyQuery(sql);
         return Flux.from(real.execute())
                 .doOnComplete(() -> {
                    long dur = ms(start);
                    LogMetrics.recordTask("r2dbc", op, dur, true);
                    log.debug("R2DBC query executed", "operation", op,
                            "duration_ms", dur, "sql", DbLogProxyDataSource.truncSql(sql),
                            "cid", corrId, "rid", reqId);
                    if (dur > slowQueryMs) {
                       log.warn("Slow R2DBC query", "operation", op, "duration_ms", dur,
                               "sql", DbLogProxyDataSource.truncSql(sql),
                               "cid", corrId, "rid", reqId);
                    }
                 })
                 .doOnError(t -> {
                    long dur = ms(start);
                    LogMetrics.recordTask("r2dbc", op, dur, false);
                    log.error("R2DBC query failed", "operation", op,
                            "sql", DbLogProxyDataSource.truncSql(sql),
                            "duration_ms", dur, "error", t.getMessage(),
                            "cid", corrId, "rid", reqId);
                 });
      }

      // ── Fluent delegation (return this for chaining) ──

      @Override public Statement add()                                   { real.add(); return this; }
      @Override public Statement bind(int index, Object value)           { real.bind(index, value); return this; }
      @Override public Statement bind(String name, Object value)         { real.bind(name, value); return this; }
      @Override public Statement bindNull(int index, Class<?> type)      { real.bindNull(index, type); return this; }
      @Override public Statement bindNull(String name, Class<?> type)    { real.bindNull(name, type); return this; }
      @Override public Statement returnGeneratedValues(String... columns) { real.returnGeneratedValues(columns); return this; }
      @Override public Statement fetchSize(int rows)                     { real.fetchSize(rows); return this; }
   }

   // ── Per-query timing: QueryHandle (manual approach) ──────────────────────

   /**
    * Start tracking a query manually. Useful when you want timing at the Flux/Mono level
    * rather than at the Statement level.
    * <pre>{@code
    * var h = R2dbcLogListener.before("SELECT * FROM posts");
    * return databaseClient.sql("SELECT * FROM posts")
    *     .map(this::mapRowToPost).all()
    *     .doOnComplete(h.onComplete())
    *     .doOnError(h.onError());
    * }</pre>
    */
   public static QueryHandle before(String sql) {
      return new QueryHandle(sql, System.nanoTime(),
              LogContext.getCorrelationId(), LogContext.getRequestId());
   }

   public static final class QueryHandle {
      private final String sql;
      private final long startNanos;
      private final String corrId;
      private final String reqId;
      private volatile boolean completed = false;

      QueryHandle(String sql, long startNanos, String corrId, String reqId) {
         this.sql = sql; this.startNanos = startNanos;
         this.corrId = corrId; this.reqId = reqId;
      }

      public void success() {
         if (completed) return; completed = true;
         long dur = ms(startNanos);
         String op = DbLogProxyDataSource.classifyQuery(sql);
         LogMetrics.recordTask("r2dbc", op, dur, true);
         log.debug("R2DBC query executed", "operation", op,
                 "duration_ms", dur, "sql", DbLogProxyDataSource.truncSql(sql),
                 "cid", corrId, "rid", reqId);
         if (dur > slowQueryMs) {
            log.warn("Slow R2DBC query", "operation", op, "duration_ms", dur,
                    "sql", DbLogProxyDataSource.truncSql(sql),
                    "cid", corrId, "rid", reqId);
         }
      }

      public void failure(Throwable t) {
         if (completed) return; completed = true;
         long dur = ms(startNanos);
         String op = DbLogProxyDataSource.classifyQuery(sql);
         LogMetrics.recordTask("r2dbc", op, dur, false);
         log.error("R2DBC query failed", "operation", op,
                 "sql", DbLogProxyDataSource.truncSql(sql),
                 "duration_ms", dur, "error", t.getMessage(),
                 "cid", corrId, "rid", reqId);
      }

      public Runnable onComplete() { return this::success; }
      public java.util.function.Consumer<Throwable> onError() { return this::failure; }
   }

   // ── Convenience: wrap Flux/Mono with timing ──────────────────────────────

   /**
    * Observe a Flux with query timing.
    * <pre>{@code
    * public Flux<Post> findAll() {
    *     return R2dbcLogListener.observe("SELECT * FROM posts",
    *         databaseClient.sql("SELECT * FROM posts").map(this::mapRowToPost).all());
    * }
    * }</pre>
    */
   public static <T> Flux<T> observe(String sql, Flux<T> flux) {
      var h = before(sql);
      return flux.doOnComplete(h.onComplete()).doOnError(h.onError());
   }

   /**
    * Observe a Mono with query timing.
    * <pre>{@code
    * public Mono<Post> findById(Long id) {
    *     return R2dbcLogListener.observe("SELECT * FROM posts WHERE id = ?",
    *         databaseClient.sql("...").bind("id", id).map(this::mapRowToPost).one());
    * }
    * }</pre>
    */
   public static <T> Mono<T> observe(String sql, Mono<T> mono) {
      var h = before(sql);
      return mono.doOnSuccess(v -> h.success()).doOnError(h.onError());
   }

   private static long ms(long startNanos) { return (System.nanoTime() - startNanos) / 1_000_000; }
}