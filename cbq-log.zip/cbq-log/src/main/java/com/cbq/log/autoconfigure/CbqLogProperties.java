package com.cbq.log.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Set;

@ConfigurationProperties(prefix = "cbq.log")
public class CbqLogProperties {
   private String serviceName = "app";
   private String format = "JSON";
   private boolean async = true;
   private Set<String> maskFields = Set.of();
   private Set<String> maskProfiles = Set.of();
   private Set<String> maskJsonPaths = Set.of();
   private char maskSymbol = '*';
   private int leftVisible = 0;
   private int rightVisible = 0;
   private int maxBodySize = 4096;
   private String correlationKey = "cid";
   private String requestIdKey = "rid";
   private boolean includeCallerInfo = false;
   private String environment = "default";
   private long slowQueryThresholdMs = 500;
   private double defaultSampleRate = 1.0;
   private boolean prodMaskOverride = false;
   private int asyncCorePoolSize = 2;
   private int asyncMaxPoolSize = 10;
   private int asyncQueueCapacity = 1000;
   private Set<String> mdcFields = Set.of();

   public String getServiceName() {
      return serviceName;
   }

   public void setServiceName(String v) {
      this.serviceName = v;
   }

   public String getFormat() {
      return format;
   }

   public void setFormat(String v) {
      this.format = v;
   }

   public boolean isAsync() {
      return async;
   }

   public void setAsync(boolean v) {
      this.async = v;
   }

   public Set<String> getMaskFields() {
      return maskFields;
   }

   public void setMaskFields(Set<String> v) {
      this.maskFields = v;
   }

   public Set<String> getMaskProfiles() {
      return maskProfiles;
   }

   public void setMaskProfiles(Set<String> v) {
      this.maskProfiles = v;
   }

   public Set<String> getMaskJsonPaths() {
      return maskJsonPaths;
   }

   public void setMaskJsonPaths(Set<String> v) {
      this.maskJsonPaths = v;
   }

   public char getMaskSymbol() {
      return maskSymbol;
   }

   public void setMaskSymbol(char v) {
      this.maskSymbol = v;
   }

   public int getLeftVisible() {
      return leftVisible;
   }

   public void setLeftVisible(int leftVisible) {
      this.leftVisible = leftVisible;
   }

   public int getRightVisible() {
      return rightVisible;
   }

   public void setRightVisible(int rightVisible) {
      this.rightVisible = rightVisible;
   }

   public int getMaxBodySize() {
      return maxBodySize;
   }

   public void setMaxBodySize(int v) {
      this.maxBodySize = v;
   }

   public String getCorrelationKey() {
      return correlationKey;
   }

   public void setCorrelationKey(String v) {
      this.correlationKey = v;
   }

   public String getRequestIdKey() {
      return requestIdKey;
   }

   public void setRequestIdKey(String v) {
      this.requestIdKey = v;
   }

   public boolean isIncludeCallerInfo() {
      return includeCallerInfo;
   }

   public void setIncludeCallerInfo(boolean v) {
      this.includeCallerInfo = v;
   }

   public String getEnvironment() {
      return environment;
   }

   public void setEnvironment(String v) {
      this.environment = v;
   }

   public long getSlowQueryThresholdMs() {
      return slowQueryThresholdMs;
   }

   public void setSlowQueryThresholdMs(long v) {
      this.slowQueryThresholdMs = v;
   }

   public double getDefaultSampleRate() {
      return defaultSampleRate;
   }

   public void setDefaultSampleRate(double v) {
      this.defaultSampleRate = v;
   }

   public boolean isProdMaskOverride() {
      return prodMaskOverride;
   }

   public void setProdMaskOverride(boolean v) {
      this.prodMaskOverride = v;
   }

   public int getAsyncCorePoolSize() {
      return asyncCorePoolSize;
   }

   public void setAsyncCorePoolSize(int asyncCorePoolSize) {
      this.asyncCorePoolSize = asyncCorePoolSize;
   }

   public int getAsyncMaxPoolSize() {
      return asyncMaxPoolSize;
   }

   public void setAsyncMaxPoolSize(int asyncMaxPoolSize) {
      this.asyncMaxPoolSize = asyncMaxPoolSize;
   }

   public int getAsyncQueueCapacity() {
      return asyncQueueCapacity;
   }

   public void setAsyncQueueCapacity(int asyncQueueCapacity) {
      this.asyncQueueCapacity = asyncQueueCapacity;
   }

   public Set<String> getMdcFields() {
      return mdcFields;
   }

   public void setMdcFields(Set<String> mdcFields) {
      this.mdcFields = mdcFields;
   }
}
