package com.cbq.log.db;

import com.cbq.log.context.LogContext;
import com.cbq.log.core.CbqLog;
import com.cbq.log.metrics.LogMetrics;
import org.slf4j.MDC;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.*;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Lightweight DataSource proxy for JDBC connection + query performance logging.
 * Zero dependencies beyond java.sql. Non-blocking — all logging is async via CbqLog.
 *
 * <p>Tracks:
 * <ul>
 *   <li>Connection checkout time (getConnection latency)</li>
 *   <li>Connection hold duration (checkout → close)</li>
 *   <li>Slow queries above threshold</li>
 *   <li>Statement execution time</li>
 * </ul>
 *
 * <pre>{@code
 * // Wrap any DataSource
 * DataSource proxied = DbLogProxyDataSource.wrap(originalDataSource);
 *
 * // Or with custom settings
 * DataSource proxied = DbLogProxyDataSource.wrap(originalDataSource, 100); // 100ms slow query threshold
 * }</pre>
 */
public final class DbLogProxyDataSource implements DataSource {

   private static final CbqLog log = CbqLog.getLogger("cbq.db");
   private final DataSource delegate;
   private final long slowQueryMs;

   private DbLogProxyDataSource(DataSource delegate, long slowQueryMs) {
      this.delegate = delegate;
      this.slowQueryMs = slowQueryMs;
   }

   public static DataSource wrap(DataSource ds) {
      return wrap(ds, LogMetrics.getSlowQueryThreshold());
   }

   public static DataSource wrap(DataSource ds, long slowQueryMs) {
      return new DbLogProxyDataSource(ds, slowQueryMs);
   }

   @Override
   public Connection getConnection() throws SQLException {
      // Snapshot caller's MDC (correlation ID, request ID, gateway context)
      Map<String, String> callerMdc = MDC.getCopyOfContextMap();
      String corrId = LogContext.getCorrelationId();
      String reqId = LogContext.getRequestId();

      long start = System.nanoTime();
      try {
         Connection conn = delegate.getConnection();
         long checkoutMs = ms(start);
         LogMetrics.recordTask("db", "pool.acquire", checkoutMs, true);
         log.debug("Connection acquired", "event", "pool.acquire",
                 "wait_ms", checkoutMs, "cid", corrId, "rid", reqId);
         if (checkoutMs > slowQueryMs)
            log.warn("Slow connection checkout", "event", "pool.acquire",
                    "wait_ms", checkoutMs, "cid", corrId, "rid", reqId);
         return proxyConnection(conn, System.nanoTime(), checkoutMs, callerMdc, corrId, reqId);
      } catch (SQLException e) {
         LogMetrics.recordTask("db", "pool.acquire", ms(start), false);
         log.error("Connection acquire failed", "event", "pool.acquire",
                 "wait_ms", ms(start), "cid", corrId, "error", e.getMessage());
         throw e;
      }
   }

   @Override
   public Connection getConnection(String user, String pass) throws SQLException {
      Map<String, String> callerMdc = MDC.getCopyOfContextMap();
      String corrId = LogContext.getCorrelationId();
      String reqId = LogContext.getRequestId();

      long start = System.nanoTime();
      try {
         Connection conn = delegate.getConnection(user, pass);
         long checkoutMs = ms(start);
         LogMetrics.recordTask("db", "pool.acquire", checkoutMs, true);
         log.debug("Connection acquired", "event", "pool.acquire",
                 "wait_ms", checkoutMs, "cid", corrId, "rid", reqId);
         if (checkoutMs > slowQueryMs)
            log.warn("Slow connection checkout", "event", "pool.acquire",
                    "wait_ms", checkoutMs, "cid", corrId, "rid", reqId);
         return proxyConnection(conn, System.nanoTime(), checkoutMs, callerMdc, corrId, reqId);
      } catch (SQLException e) {
         LogMetrics.recordTask("db", "pool.acquire", ms(start), false);
         log.error("Connection acquire failed", "event", "pool.acquire",
                 "wait_ms", ms(start), "cid", corrId, "error", e.getMessage());
         throw e;
      }
   }

   private Connection proxyConnection(Connection real, long acquiredAt, long acquireWaitMs,
                                      Map<String, String> callerMdc, String corrId, String reqId) {
      return (Connection) Proxy.newProxyInstance(
              real.getClass().getClassLoader(),
              new Class[]{Connection.class},
              new ConnectionHandler(real, acquiredAt, acquireWaitMs, callerMdc, corrId, reqId));
   }

   // ── Connection proxy ─────────────────────────────────────────────────────

   private final class ConnectionHandler implements InvocationHandler {
      private final Connection real;
      private final long acquiredAt;
      private final long acquireWaitMs;
      private final Map<String, String> callerMdc;
      private final String corrId;
      private final String reqId;

      ConnectionHandler(Connection real, long acquiredAt, long acquireWaitMs,
                        Map<String, String> callerMdc, String corrId, String reqId) {
         this.real = real;
         this.acquiredAt = acquiredAt;
         this.acquireWaitMs = acquireWaitMs;
         this.callerMdc = callerMdc;
         this.corrId = corrId;
         this.reqId = reqId;
      }

      @Override
      public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
         String name = method.getName();

         if ("close".equals(name)) {
            long holdMs = ms(acquiredAt);
            LogMetrics.recordTask("db", "pool.release", holdMs, true);
            // Restore caller's MDC so the log entry carries the original request context
            withCallerMdc(() -> {
               log.debug("Connection released", "event", "pool.release",
                       "hold_ms", holdMs, "acquire_wait_ms", acquireWaitMs,
                       "cid", corrId, "rid", reqId);
               if (holdMs > slowQueryMs * 5)
                  log.warn("Long connection hold", "event", "pool.release",
                          "hold_ms", holdMs, "acquire_wait_ms", acquireWaitMs,
                          "cid", corrId, "rid", reqId);
            });
            return method.invoke(real, args);
         }

         if ("prepareStatement".equals(name) || "prepareCall".equals(name)) {
            Object stmt = method.invoke(real, args);
            String sql = args != null && args.length > 0 ? String.valueOf(args[0]) : "";
            return proxyStatement(stmt, sql, stmt instanceof PreparedStatement, callerMdc, corrId);
         }

         if ("createStatement".equals(name)) {
            Object stmt = method.invoke(real, args);
            return proxyStatement(stmt, null, false, callerMdc, corrId);
         }

         return method.invoke(real, args);
      }

      private void withCallerMdc(Runnable action) {
         Map<String, String> prev = MDC.getCopyOfContextMap();
         try {
            if (callerMdc != null) MDC.setContextMap(callerMdc);
            else MDC.clear();
            action.run();
         } finally {
            if (prev != null) MDC.setContextMap(prev);
            else MDC.clear();
         }
      }
   }

   private Object proxyStatement(Object real, String sql, boolean prepared,
                                 Map<String, String> callerMdc, String corrId) {
      Class<?>[] ifaces = prepared ? new Class[]{PreparedStatement.class} : new Class[]{Statement.class};
      return Proxy.newProxyInstance(real.getClass().getClassLoader(), ifaces,
              new StatementHandler(real, sql, callerMdc, corrId));
   }

   // ── Statement proxy ──────────────────────────────────────────────────────

   private final class StatementHandler implements InvocationHandler {
      private final Object real;
      private String sql;
      private final Map<String, String> callerMdc;
      private final String corrId;

      StatementHandler(Object real, String sql, Map<String, String> callerMdc, String corrId) {
         this.real = real;
         this.sql = sql;
         this.callerMdc = callerMdc;
         this.corrId = corrId;
      }

      @Override
      public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
         String name = method.getName();

         if (isExecMethod(name)) {
            if (sql == null && args != null && args.length > 0 && args[0] instanceof String s) sql = s;
            long start = System.nanoTime();
            boolean ok = true;
            try {
               return method.invoke(real, args);
            } catch (Throwable t) {
               ok = false;
               throw t;
            } finally {
               long queryMs = ms(start);
               String op = classifyQuery(sql);
               LogMetrics.recordTask("db", op, queryMs, ok);
               if (queryMs > slowQueryMs) {
                  boolean finalOk = ok;
                  withCallerMdc(() ->
                          log.warn("Slow query", "operation", op, "duration_ms", queryMs,
                                  "sql", truncSql(sql), "cid", corrId, "success", finalOk));
               }
            }
         }
         return method.invoke(real, args);
      }

      private boolean isExecMethod(String n) {
         return "execute".equals(n) || "executeQuery".equals(n) || "executeUpdate".equals(n)
                 || "executeBatch".equals(n) || "executeLargeUpdate".equals(n);
      }

      private void withCallerMdc(Runnable action) {
         Map<String, String> prev = MDC.getCopyOfContextMap();
         try {
            if (callerMdc != null) MDC.setContextMap(callerMdc);
            else MDC.clear();
            action.run();
         } finally {
            if (prev != null) MDC.setContextMap(prev);
            else MDC.clear();
         }
      }
   }

   // ── Utilities ────────────────────────────────────────────────────────────

   static String classifyQuery(String sql) {
      if (sql == null || sql.isBlank()) return "query";
      String upper = sql.stripLeading().substring(0, Math.min(sql.stripLeading().length(), 10)).toUpperCase();
      if (upper.startsWith("SELECT")) return "select";
      if (upper.startsWith("INSERT")) return "insert";
      if (upper.startsWith("UPDATE")) return "update";
      if (upper.startsWith("DELETE")) return "delete";
      if (upper.startsWith("CALL")) return "call";
      return "query";
   }

   static String truncSql(String sql) {
      if (sql == null) return "";
      return sql.length() > 200 ? sql.substring(0, 200) + "..." : sql;
   }

   private static long ms(long startNanos) {
      return (System.nanoTime() - startNanos) / 1_000_000;
   }

   // ── DataSource delegate methods ──────────────────────────────────────────
   @Override
   public PrintWriter getLogWriter() throws SQLException {
      return delegate.getLogWriter();
   }

   @Override
   public void setLogWriter(PrintWriter out) throws SQLException {
      delegate.setLogWriter(out);
   }

   @Override
   public void setLoginTimeout(int s) throws SQLException {
      delegate.setLoginTimeout(s);
   }

   @Override
   public int getLoginTimeout() throws SQLException {
      return delegate.getLoginTimeout();
   }

   @Override
   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
      return delegate.getParentLogger();
   }

   @Override
   public <T> T unwrap(Class<T> iface) throws SQLException {
      return delegate.unwrap(iface);
   }

   @Override
   public boolean isWrapperFor(Class<?> iface) throws SQLException {
      return delegate.isWrapperFor(iface);
   }
}
