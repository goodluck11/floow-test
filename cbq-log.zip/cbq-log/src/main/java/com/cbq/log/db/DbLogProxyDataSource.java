package com.cbq.log.db;

import com.cbq.log.context.LogContext;
import com.cbq.log.core.CbqLog;
import com.cbq.log.metrics.LogMetrics;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.description.modifier.Visibility;
import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
import net.bytebuddy.implementation.FieldAccessor;
import net.bytebuddy.implementation.MethodCall;
import net.bytebuddy.implementation.MethodDelegation;
import net.bytebuddy.implementation.bind.annotation.AllArguments;
import net.bytebuddy.implementation.bind.annotation.Origin;
import net.bytebuddy.implementation.bind.annotation.RuntimeType;
import net.bytebuddy.matcher.ElementMatchers;
import org.slf4j.MDC;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.Statement;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Lightweight DataSource proxy for JDBC connection + query performance logging.
 * Zero dependencies beyond java.sql. Non-blocking — all logging is async via CbqLog.
 *
 * <p>Tracks:
 * <ul>
 *   <li>Connection checkout time (getConnection latency)</li>
 *   <li>Connection hold duration (checkout → close)</li>
 *   <li>Slow queries above threshold</li>
 *   <li>Statement execution time</li>
 * </ul>
 *
 * <pre>{@code
 * // Wrap any DataSource
 * DataSource proxied = DbLogProxyDataSource.wrap(originalDataSource);
 *
 * // Or with custom settings
 * DataSource proxied = DbLogProxyDataSource.wrap(originalDataSource, 100); // 100ms slow query threshold
 * }</pre>
 */
public final class DbLogProxyDataSource implements DataSource {

   private static final CbqLog log = CbqLog.getLogger("cbq.db");
   private final DataSource delegate;
   private final long slowQueryMs;
   private final boolean poolMonitoringEnabled;

   private static final String EVENT_POOL_ACQUIRE = "pool.acquire";
   private static final String EVENT_POOL_RELEASE = "pool.release";

   private static final String[] OP_NAMES = {"select", "insert", "update", "delete", "call", "query", "create", "drop", "alter"};

   private static final Map<String, String> SQL_TYPE_CACHE = new java.util.concurrent.ConcurrentHashMap<>();
   private static final java.util.concurrent.ThreadLocalRandom SAMPLER = java.util.concurrent.ThreadLocalRandom.current();
   private static double sampleRate = 0.01; // 1% sampling by default

   private static final ClassValue<Class<?>> CONNECTION_PROXY_CLASS = new ClassValue<>() {
      @Override
      protected Class<?> computeValue(Class<?> type) {
         try {
            return BYTE_BUDDY.subclass(Connection.class)
                    .defineField("handler", ConnectionHandler.class, Visibility.PUBLIC)
                    .defineConstructor(Visibility.PUBLIC)
                    .withParameters(ConnectionHandler.class)
                    .intercept(MethodCall.invoke(Object.class.getConstructor())
                            .andThen(FieldAccessor.ofField("handler").setsArgumentAt(0)))
                    .method(ElementMatchers.any())
                    .intercept(MethodDelegation.toField("handler"))
                    .make()
                    .load(DbLogProxyDataSource.class.getClassLoader(), LOADING_STRATEGY)
                    .getLoaded();
         } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
         }
      }
   };

   private static final ClassValue<Class<?>> STATEMENT_PROXY_CLASS = new ClassValue<>() {
      @Override
      protected Class<?> computeValue(Class<?> type) {
         try {
            return BYTE_BUDDY.subclass(type)
                    .defineField("handler", StatementHandler.class, Visibility.PUBLIC)
                    .defineConstructor(Visibility.PUBLIC)
                    .withParameters(StatementHandler.class)
                    .intercept(MethodCall.invoke(Object.class.getConstructor())
                            .andThen(FieldAccessor.ofField("handler").setsArgumentAt(0)))
                    .method(ElementMatchers.any())
                    .intercept(MethodDelegation.toField("handler"))
                    .make()
                    .load(DbLogProxyDataSource.class.getClassLoader(), LOADING_STRATEGY)
                    .getLoaded();
         } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
         }
      }
   };
   private static final ByteBuddy BYTE_BUDDY = new ByteBuddy();
   private static final ClassLoadingStrategy<ClassLoader> LOADING_STRATEGY = 
           ClassLoadingStrategy.Default.INJECTION;

   public static void setMetricsSampleRate(double rate) {
      sampleRate = rate;
   }

   private DbLogProxyDataSource(DataSource delegate, long slowQueryMs, boolean poolMonitoringEnabled) {
      this.delegate = delegate;
      this.slowQueryMs = slowQueryMs;
      this.poolMonitoringEnabled = poolMonitoringEnabled;
   }

   public static DataSource wrap(DataSource ds) {
      return wrap(ds, LogMetrics.getSlowQueryThreshold(), true);
   }

   public static DataSource wrap(DataSource ds, boolean poolMonitoringEnabled) {
      return wrap(ds, LogMetrics.getSlowQueryThreshold(), poolMonitoringEnabled);
   }

   public static DataSource wrap(DataSource ds, long slowQueryMs) {
      return wrap(ds, slowQueryMs, true);
   }

   public static DataSource wrap(DataSource ds, long slowQueryMs, boolean poolMonitoringEnabled) {
      return new DbLogProxyDataSource(ds, slowQueryMs, poolMonitoringEnabled);
   }

   @Override
   public Connection getConnection() throws SQLException {
      if (!poolMonitoringEnabled) return delegate.getConnection();

      var corrId = LogContext.getCorrelationId();
      var reqId = LogContext.getRequestId();
      var ck = LogContext.getCorrelationKey();
      var rk = LogContext.getRequestIdKey();

      var start = System.nanoTime();
      try {
         var conn = delegate.getConnection();
         var now = System.nanoTime();
         var checkoutMs = ms(start, now);
         if (SAMPLER.nextDouble() < sampleRate) {
            LogMetrics.recordTask("db", EVENT_POOL_ACQUIRE, checkoutMs, true);
         }
         if (checkoutMs > slowQueryMs) {
            log.warn("Slow connection checkout", "event", EVENT_POOL_ACQUIRE,
                    "wait_ms", checkoutMs, "cid", corrId, "rid", reqId);
         }
         return proxyConnection(conn, now, checkoutMs, corrId, reqId, ck, rk);
      } catch (SQLException e) {
         long durationMs = ms(start);
         if (SAMPLER.nextDouble() < sampleRate) {
            LogMetrics.recordTask("db", EVENT_POOL_ACQUIRE, durationMs, false);
         }
         log.error("Connection acquire failed", "event", EVENT_POOL_ACQUIRE,
                 "wait_ms", durationMs, "cid", corrId, "error", e.getMessage());
         throw e;
      }
   }

   @Override
   public Connection getConnection(String user, String pass) throws SQLException {
      if (!poolMonitoringEnabled) return delegate.getConnection(user, pass);

      var corrId = LogContext.getCorrelationId();
      var reqId = LogContext.getRequestId();
      var ck = LogContext.getCorrelationKey();
      var rk = LogContext.getRequestIdKey();

      var start = System.nanoTime();
      try {
         var conn = delegate.getConnection(user, pass);
         var now = System.nanoTime();
         var checkoutMs = ms(start, now);
         if (SAMPLER.nextDouble() < sampleRate) {
            LogMetrics.recordTask("db", EVENT_POOL_ACQUIRE, checkoutMs, true);
         }
         if (checkoutMs > slowQueryMs) {
            log.warn("Slow connection checkout", "event", EVENT_POOL_ACQUIRE,
                    "wait_ms", checkoutMs, "cid", corrId, "rid", reqId);
         }

         return proxyConnection(conn, now, checkoutMs, corrId, reqId, ck, rk);
      } catch (SQLException e) {
         var durationMs = ms(start);
         if (SAMPLER.nextDouble() < sampleRate) {
            LogMetrics.recordTask("db", EVENT_POOL_ACQUIRE, durationMs, false);
         }
         log.error("Connection acquire failed", "event", EVENT_POOL_ACQUIRE,
                 "wait_ms", durationMs, "cid", corrId, "error", e.getMessage());
         throw e;
      }
   }

   private Connection proxyConnection(Connection real, long acquiredAt, long acquireWaitMs,
                                      String corrId, String reqId, String ck, String rk) {
      Class<?> proxyClass = CONNECTION_PROXY_CLASS.get(real.getClass());

      try {
         var handler = new ConnectionHandler(real, acquiredAt, acquireWaitMs, corrId, reqId, ck, rk);
         return (Connection) proxyClass.getConstructor(ConnectionHandler.class).newInstance(handler);
      } catch (Exception e) {
         return real;
      }
   }

   // ── Connection proxy ─────────────────────────────────────────────────────

   public final class ConnectionHandler {
      private final Connection real;
      private final long acquiredAt;
      private final long acquireWaitMs;
      private final String corrId;
      private final String reqId;
      private final String ck, rk;

      private static final int M_CLOSE = 1;
      private static final int M_PREPARE_STMT = 2;
      private static final int M_PREPARE_CALL = 3;
      private static final int M_CREATE_STMT = 4;

      private final java.util.Map<Method, Integer> methodIndices = new java.util.concurrent.ConcurrentHashMap<>();

      ConnectionHandler(Connection real, long acquiredAt, long acquireWaitMs,
                        String corrId, String reqId, String ck, String rk) {
         this.real = real;
         this.acquiredAt = acquiredAt;
         this.acquireWaitMs = acquireWaitMs;
         this.corrId = corrId;
         this.reqId = reqId;
         this.ck = ck;
         this.rk = rk;
      }

      private int getMethodIndex(Method method) {
         return methodIndices.computeIfAbsent(method, m -> {
            var name = m.getName();
            if ("close".equals(name)) return M_CLOSE;
            if ("prepareStatement".equals(name)) return M_PREPARE_STMT;
            if ("prepareCall".equals(name)) return M_PREPARE_CALL;
            if ("createStatement".equals(name)) return M_CREATE_STMT;
            return 0;
         });
      }

      @RuntimeType
      public Object intercept(@Origin Method method, @AllArguments Object[] args) throws Throwable {
         int idx = getMethodIndex(method);

         if (idx == M_CLOSE) {
            var holdMs = ms(acquiredAt);
            var totalMs = holdMs + acquireWaitMs;
            if (SAMPLER.nextDouble() < sampleRate) {
               LogMetrics.recordTask("db", EVENT_POOL_RELEASE, holdMs, true);
            }
            if (holdMs > slowQueryMs * 5) {
               withCallerMdc(() -> log.warn("Long connection hold", "event", EVENT_POOL_RELEASE,
                       "hold_ms", holdMs, "wait_ms", acquireWaitMs, "total_ms", totalMs,
                       "cid", corrId, "rid", reqId));
            }
            return method.invoke(real, args);
         }

         if (idx == M_PREPARE_STMT || idx == M_PREPARE_CALL) {
            var stmt = method.invoke(real, args);
            var sql = args != null && args.length > 0 ? String.valueOf(args[0]) : "";
            Class<?> type = stmt instanceof PreparedStatement ? PreparedStatement.class :
                    (stmt instanceof CallableStatement ? CallableStatement.class : Statement.class);
            return proxyStatement(stmt, type, sql, corrId, ck);
         }

         if (idx == M_CREATE_STMT) {
            var stmt = method.invoke(real, args);
            return proxyStatement(stmt, Statement.class, null, corrId, ck);
         }

         return method.invoke(real, args);
      }

      private void withCallerMdc(Runnable action) {
         var oldC = MDC.get(ck); var oldR = MDC.get(rk);
         try {
            if (corrId != null) MDC.put(ck, corrId); else MDC.remove(ck);
            if (reqId != null) MDC.put(rk, reqId); else MDC.remove(rk);
            action.run();
         } finally {
            if (oldC != null) MDC.put(ck, oldC); else MDC.remove(ck);
            if (oldR != null) MDC.put(rk, oldR); else MDC.remove(rk);
         }
      }
   }

   private Object proxyStatement(Object real, Class<?> type, String sql,
                                 String corrId, String ck) {
      Class<?> pClass = STATEMENT_PROXY_CLASS.get(type);

      try {
         var handler = new StatementHandler(real, sql, corrId, ck);
         return pClass.getConstructor(StatementHandler.class).newInstance(handler);
      } catch (Exception e) {
         return real;
      }
   }

   // ── Statement proxy ──────────────────────────────────────────────────────

   public final class StatementHandler {
      private final Object real;
      private String sql;
      private final String corrId;
      private final String ck;

      private static final VarHandle SQL_VH;
      static {
         try {
            SQL_VH = MethodHandles.lookup().findVarHandle(StatementHandler.class, "sql", String.class);
         } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
         }
      }

      private final java.util.Map<Method, Boolean> execMethodCache = new java.util.concurrent.ConcurrentHashMap<>();

      StatementHandler(Object real, String sql, String corrId, String ck) {
         this.real = real;
         this.sql = sql;
         this.corrId = corrId;
         this.ck = ck;
      }

      @RuntimeType
      public Object intercept(@Origin Method method, @AllArguments Object[] args) throws Throwable {
         if (execMethodCache.computeIfAbsent(method, m -> isExecMethod(m.getName()))) {
            var currentSql = (String) SQL_VH.get(this);
            if (currentSql == null && args != null && args.length > 0 && args[0] instanceof String s) {
               currentSql = s;
            }
            var start = System.nanoTime();
            var ok = true;
            try {
               return method.invoke(real, args);
            } catch (Throwable t) {
               ok = false;
               throw t;
            } finally {
               if (slowQueryMs > -1) {
                  var queryMs = ms(start);
                  var op = classifyQuery(currentSql);
                  if (SAMPLER.nextDouble() < sampleRate) {
                     LogMetrics.recordTask("db", op, queryMs, ok);
                  }
                  var finalOk = ok;
                  var finalSql = currentSql;
                  if (queryMs > slowQueryMs) {
                     withCallerMdc(() ->
                             log.warn("Slow query", "operation", op, "duration_ms", queryMs,
                                     "sql", truncSql(finalSql), "cid", corrId, "success", finalOk));
                  }
               }
            }
         }

         return method.invoke(real, args);
      }

      private boolean isExecMethod(String n) {
         return "execute".equals(n) || "executeQuery".equals(n) || "executeUpdate".equals(n)
                 || "executeBatch".equals(n) || "executeLargeUpdate".equals(n);
      }

      private void withCallerMdc(Runnable action) {
         var oldC = MDC.get(ck);
         try {
            if (corrId != null) MDC.put(ck, corrId); else MDC.remove(ck);
            action.run();
         } finally {
            if (oldC != null) MDC.put(ck, oldC); else MDC.remove(ck);
         }
      }
   }

   // ── Utilities ────────────────────────────────────────────────────────────

   static String classifyQuery(String sql) {
      if (sql == null || sql.isBlank()) return OP_NAMES[5]; // query
      return SQL_TYPE_CACHE.computeIfAbsent(sql, s -> {
         var normalized = s.trim().toUpperCase();
         if (normalized.startsWith("SELECT")) return OP_NAMES[0];
         if (normalized.startsWith("INSERT")) return OP_NAMES[1];
         if (normalized.startsWith("UPDATE")) return OP_NAMES[2];
         if (normalized.startsWith("DELETE")) return OP_NAMES[3];
         if (normalized.startsWith("CALL")) return OP_NAMES[4];
         if (normalized.startsWith("CREATE")) return OP_NAMES[6];
         if (normalized.startsWith("DROP")) return OP_NAMES[7];
         if (normalized.startsWith("ALTER")) return OP_NAMES[8];
         return OP_NAMES[5];
      });
   }

   static String truncSql(String sql) {
      if (sql == null) return "";
      return sql.length() > 200 ? sql.substring(0, 200) + "..." : sql;
   }

   private static long ms(long startNanos) {
      return (System.nanoTime() - startNanos) / 1_000_000;
   }

   private static long ms(long startNanos, long endNanos) {
      return (endNanos - startNanos) / 1_000_000;
   }

   // ── DataSource delegate methods ──────────────────────────────────────────
   @Override
   public PrintWriter getLogWriter() throws SQLException {
      return delegate.getLogWriter();
   }

   @Override
   public void setLogWriter(PrintWriter out) throws SQLException {
      delegate.setLogWriter(out);
   }

   @Override
   public void setLoginTimeout(int s) throws SQLException {
      delegate.setLoginTimeout(s);
   }

   @Override
   public int getLoginTimeout() throws SQLException {
      return delegate.getLoginTimeout();
   }

   @Override
   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
      return delegate.getParentLogger();
   }

   @Override
   public <T> T unwrap(Class<T> iface) throws SQLException {
      return delegate.unwrap(iface);
   }

   @Override
   public boolean isWrapperFor(Class<?> iface) throws SQLException {
      return delegate.isWrapperFor(iface);
   }
}
