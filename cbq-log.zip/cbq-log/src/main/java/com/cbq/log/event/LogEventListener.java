package com.cbq.log.event;

import java.util.Map;

/**
 * Callback for log events. Implementations must be thread-safe and non-blocking.
 */
@FunctionalInterface
public interface LogEventListener {
   void onEvent(Map<String, Object> event);
}

