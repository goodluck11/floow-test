package com.cbq.log.context;

import org.slf4j.MDC;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;

/**
 * MDC-based correlation/request ID management. Works naturally with virtual threads (Spring Boot 3.2+).
 *
 * <pre>{@code
 * LogContext.setCorrelationId("corr_abc123");
 * LogContext.withCorrelation("corr_new", () -> { ... });
 * String corrId = LogContext.getOrCreateCorrelationId();
 * }</pre>
 * <p>
 * * MDC-based correlation management with context propagation helpers.
 * *
 * * <pre>{@code
 *  * // Propagate to custom thread pool / CompletableFuture:
 *  * executor.submit(LogContext.wrap(() -> doWork()));
 *  * CompletableFuture.supplyAsync(LogContext.wrapSupplier(() -> compute()), myPool);
 *  * }</pre>
 */
public final class LogContext {
   private static volatile String correlationKey = "cid";
   private static volatile String requestIdKey = "rid";

   private LogContext() {
   }

   public static void configure(String corrKey, String reqKey) {
      correlationKey = corrKey;
      requestIdKey = reqKey;
   }

   public static String getCorrelationId() {
      return MDC.get(correlationKey);
   }

   public static String getRequestId() {
      return MDC.get(requestIdKey);
   }

   public static String getOrCreateCorrelationId() {
      String v = MDC.get(correlationKey);
      if (v == null) {
         v = genId("corr");
         MDC.put(correlationKey, v);
      }
      return v;
   }

   public static String newRequestId() {
      String v = genId("req");
      MDC.put(requestIdKey, v);
      return v;
   }

   public static void setCorrelationId(String id) {
      if (id != null) MDC.put(correlationKey, id);
   }

   public static void setRequestId(String id) {
      if (id != null) MDC.put(requestIdKey, id);
   }

   public static void put(String key, String val) {
      MDC.put(key, val);
   }

   public static String get(String key) {
      return MDC.get(key);
   }

   public static void remove(String... keys) {
      for (var k : keys) MDC.remove(k);
   }

   public static void clear() {
      MDC.remove(correlationKey);
      MDC.remove(requestIdKey);
   }

   public static void clearAll() {
      MDC.clear();
   }

   public static String getCorrelationKey() {
      return correlationKey;
   }

   public static String getRequestIdKey() {
      return requestIdKey;
   }

   /**
    * Execute with scoped correlation ID, restoring previous on exit
    */
   public static <T> T withCorrelation(String corrId, Callable<T> fn) throws Exception {
      String prev = MDC.get(correlationKey);
      try {
         MDC.put(correlationKey, corrId);
         return fn.call();
      } finally {
         if (prev != null) MDC.put(correlationKey, prev);
         else MDC.remove(correlationKey);
      }
   }

   public static void withCorrelation(String corrId, Runnable fn) {
      String prev = MDC.get(correlationKey);
      try {
         MDC.put(correlationKey, corrId);
         fn.run();
      } finally {
         if (prev != null) MDC.put(correlationKey, prev);
         else MDC.remove(correlationKey);
      }
   }

   // ── Context Propagation Helpers ──────────────────────────────────────────

   /**
    * Wrap a Runnable, capturing current MDC. Restores it on the target thread.
    */
   public static Runnable wrap(Runnable task) {
      Map<String, String> mdc = MDC.getCopyOfContextMap();
      return () -> {
         Map<String, String> prev = MDC.getCopyOfContextMap();
         try {
            if (mdc != null) MDC.setContextMap(mdc);
            else MDC.clear();
            task.run();
         } finally {
            if (prev != null) MDC.setContextMap(prev);
            else MDC.clear();
         }
      };
   }

   /**
    * Wrap a Callable, capturing current MDC
    */
   public static <T> Callable<T> wrap(Callable<T> task) {
      Map<String, String> mdc = MDC.getCopyOfContextMap();
      return () -> {
         Map<String, String> prev = MDC.getCopyOfContextMap();
         try {
            if (mdc != null) MDC.setContextMap(mdc);
            else MDC.clear();
            return task.call();
         } finally {
            if (prev != null) MDC.setContextMap(prev);
            else MDC.clear();
         }
      };
   }

   /**
    * Wrap a Supplier, capturing current MDC
    */
   public static <T> java.util.function.Supplier<T> wrapSupplier(java.util.function.Supplier<T> task) {
      Map<String, String> mdc = MDC.getCopyOfContextMap();
      return () -> {
         Map<String, String> prev = MDC.getCopyOfContextMap();
         try {
            if (mdc != null) MDC.setContextMap(mdc);
            else MDC.clear();
            return task.get();
         } finally {
            if (prev != null) MDC.setContextMap(prev);
            else MDC.clear();
         }
      };
   }

   private static String genId(String prefix) {
      return prefix + "_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
   }
}
