package com.cbq.log.metrics;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Supplier;

/**
 * Lock-free log metrics using LongAdder. Zero contention on hot paths.
 *
 * <pre>{@code
 * // Auto-incremented by CbqLog on every log call:
 * LogMetrics.getErrorCount();
 * LogMetrics.getWarnCount();
 * LogMetrics.snapshot(); // {"error":5,"warn":12,"info":1034,"db.save":{"count":50,"fail":2,"total_ms":2300}}
 *
 * // Register Micrometer bridge (optional):
 * LogMetrics.bindTo(meterRegistry);
 * }</pre>
 */
public final class LogMetrics {
   private static final LongAdder TRACE = new LongAdder(), DEBUG = new LongAdder(),
           INFO = new LongAdder(), WARN = new LongAdder(), ERROR = new LongAdder();

   // Task metrics: "taskType.operation" → TaskCounter
   private static final ConcurrentHashMap<String, TaskCounter> TASKS = new ConcurrentHashMap<>();

   // Slow query tracking
   private static volatile long slowQueryThresholdMs = 500;

   // ── NEW: Async Logger Metrics ───────────────────────────────────────────
   private static final LongAdder SUBMIT_COUNT = new LongAdder();
   private static final LongAdder SUBMIT_TOTAL_MS = new LongAdder();
   private static final LongAdder BACKPRESSURE_EVENTS = new LongAdder();
   private static final LongAdder QUEUE_FULL_EVENTS = new LongAdder();

   // Volatile references that can be updated externally
   private static volatile Supplier<Integer> queueSizeSupplier = () -> 0;
   private static volatile Supplier<Integer> activeThreadsSupplier = () -> 0;
   private static volatile Supplier<Integer> poolSizeSupplier = () -> 0;
   private static volatile Supplier<Integer> largestPoolSizeSupplier = () -> 0;

   // For tracking peak metrics
   private static final AtomicInteger PEAK_QUEUE_SIZE = new AtomicInteger(0);
   private static final AtomicInteger PEAK_ACTIVE_THREADS = new AtomicInteger(0);

   private LogMetrics() {
   }

   // ── NEW: Register Async Logger Suppliers ────────────────────────────────

   public static void registerAsyncLoggerMetrics(
           Supplier<Integer> queueSizeSupplier,
           Supplier<Integer> activeThreadsSupplier,
           Supplier<Integer> poolSizeSupplier,
           Supplier<Integer> largestPoolSizeSupplier) {

      LogMetrics.queueSizeSupplier = queueSizeSupplier;
      LogMetrics.activeThreadsSupplier = activeThreadsSupplier;
      LogMetrics.poolSizeSupplier = poolSizeSupplier;
      LogMetrics.largestPoolSizeSupplier = largestPoolSizeSupplier;
   }

   // ── NEW: Record Async Logger Operations ─────────────────────────────────

   /**
    * Record a log submission to the async executor
    *
    * @param latencyMs    Time taken to submit in milliseconds (including backpressure wait)
    * @param backpressure Whether this submission experienced backpressure
    * @param queueFull    Whether the queue was full at submission time
    */
   public static void recordAsyncSubmission(long latencyMs, boolean backpressure, boolean queueFull) {
      SUBMIT_COUNT.increment();
      SUBMIT_TOTAL_MS.add(latencyMs);

      if (backpressure) {
         BACKPRESSURE_EVENTS.increment();
      }

      if (queueFull) {
         QUEUE_FULL_EVENTS.increment();
      }

      // Track peaks
      int currentQueueSize = queueSizeSupplier.get();
      updatePeak(PEAK_QUEUE_SIZE, currentQueueSize);

      int currentActiveThreads = activeThreadsSupplier.get();
      updatePeak(PEAK_ACTIVE_THREADS, currentActiveThreads);
   }

   private static void updatePeak(AtomicInteger peakHolder, int currentValue) {
      int currentPeak = peakHolder.get();
      while (currentValue > currentPeak) {
         if (peakHolder.compareAndSet(currentPeak, currentValue)) {
            break;
         }
         currentPeak = peakHolder.get();
      }
   }

   // ── NEW: Getters for Async Metrics ─────────────────────────────────────

   public static long getSubmitCount() {
      return SUBMIT_COUNT.sum();
   }

   public static double getAvgSubmitLatencyMs() {
      long count = SUBMIT_COUNT.sum();
      return count > 0 ? (double) SUBMIT_TOTAL_MS.sum() / count : 0.0;
   }

   public static long getBackpressureEvents() {
      return BACKPRESSURE_EVENTS.sum();
   }

   public static long getQueueFullEvents() {
      return QUEUE_FULL_EVENTS.sum();
   }

   public static int getCurrentQueueSize() {
      return queueSizeSupplier.get();
   }

   public static int getCurrentActiveThreads() {
      return activeThreadsSupplier.get();
   }

   public static int getCurrentPoolSize() {
      return poolSizeSupplier.get();
   }

   public static int getPeakQueueSize() {
      return PEAK_QUEUE_SIZE.get();
   }

   public static int getPeakActiveThreads() {
      return PEAK_ACTIVE_THREADS.get();
   }

   public static double getBackpressureRate() {
      long total = SUBMIT_COUNT.sum();
      return total > 0 ? (BACKPRESSURE_EVENTS.sum() * 100.0 / total) : 0.0;
   }

   // ── Level counters ───────────────────────────────────────────────────────

   public static void incrementTrace() {
      TRACE.increment();
   }

   public static void incrementDebug() {
      DEBUG.increment();
   }

   public static void incrementInfo() {
      INFO.increment();
   }

   public static void incrementWarn() {
      WARN.increment();
   }

   public static void incrementError() {
      ERROR.increment();
   }

   public static long getTraceCount() {
      return TRACE.sum();
   }

   public static long getDebugCount() {
      return DEBUG.sum();
   }

   public static long getInfoCount() {
      return INFO.sum();
   }

   public static long getWarnCount() {
      return WARN.sum();
   }

   public static long getErrorCount() {
      return ERROR.sum();
   }

   // ── Task counters ────────────────────────────────────────────────────────

   public static void recordTask(String taskType, String operation, long durationMs, boolean success) {
      String key = taskType + "." + operation;
      TASKS.computeIfAbsent(key, k -> new TaskCounter()).record(durationMs, success);
   }

   public static void setSlowQueryThreshold(long ms) {
      slowQueryThresholdMs = ms;
   }

   public static long getSlowQueryThreshold() {
      return slowQueryThresholdMs;
   }

   // ── Snapshot ─────────────────────────────────────────────────────────────

   public static Map<String, Object> snapshot() {
      var m = new java.util.LinkedHashMap<String, Object>();

      // Log levels
      m.put("trace", TRACE.sum());
      m.put("debug", DEBUG.sum());
      m.put("info", INFO.sum());
      m.put("warn", WARN.sum());
      m.put("error", ERROR.sum());

      // Task metrics
      TASKS.forEach((k, v) -> m.put(k, v.snapshot()));

      // ── NEW: Async Logger Metrics ──
      Map<String, Object> asyncMetrics = new java.util.LinkedHashMap<>();
      asyncMetrics.put("submit_count", SUBMIT_COUNT.sum());
      asyncMetrics.put("avg_submit_latency_ms", getAvgSubmitLatencyMs());
      asyncMetrics.put("backpressure_events", BACKPRESSURE_EVENTS.sum());
      asyncMetrics.put("queue_full_events", QUEUE_FULL_EVENTS.sum());
      asyncMetrics.put("backpressure_rate_pct", getBackpressureRate());
      asyncMetrics.put("current_queue_size", queueSizeSupplier.get());
      asyncMetrics.put("current_active_threads", activeThreadsSupplier.get());
      asyncMetrics.put("current_pool_size", poolSizeSupplier.get());
      asyncMetrics.put("peak_queue_size", PEAK_QUEUE_SIZE.get());
      asyncMetrics.put("peak_active_threads", PEAK_ACTIVE_THREADS.get());

      m.put("async_logger", asyncMetrics);

      return m;
   }

   public static void reset() {
      TRACE.reset();
      DEBUG.reset();
      INFO.reset();
      WARN.reset();
      ERROR.reset();
      TASKS.clear();

      // ── NEW: Reset async metrics ──
      SUBMIT_COUNT.reset();
      SUBMIT_TOTAL_MS.reset();
      BACKPRESSURE_EVENTS.reset();
      QUEUE_FULL_EVENTS.reset();
      PEAK_QUEUE_SIZE.set(0);
      PEAK_ACTIVE_THREADS.set(0);
   }

   // ── Micrometer bridge (optional) ────────────────────────────────────────

   /**
    * Bind to Micrometer MeterRegistry if available. Call once at startup.
    * Micrometer is an {@code <optional>} dependency — this safely no-ops if absent.
    * <pre>{@code LogMetrics.bindTo(meterRegistry); }</pre>
    */
   public static void bindTo(Object meterRegistry) {
      try {
         MicrometerBridge.bind((io.micrometer.core.instrument.MeterRegistry) meterRegistry);
      } catch (NoClassDefFoundError | Exception e) {
         // Micrometer not on classpath — silently skip
      }
   }

   /**
    * Isolated inner class. Only loaded by the JVM when {@link #bindTo} is called,
    * so if Micrometer is not on the classpath, this class is never touched
    * and no ClassNotFoundException occurs.
    */
   private static final class MicrometerBridge {
      static void bind(io.micrometer.core.instrument.MeterRegistry reg) {
         // Log level counters
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", TRACE, LongAdder::sum).tag("level", "trace").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", DEBUG, LongAdder::sum).tag("level", "debug").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", INFO, LongAdder::sum).tag("level", "info").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", WARN, LongAdder::sum).tag("level", "warn").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", ERROR, LongAdder::sum).tag("level", "error").register(reg);

         // ── NEW: Async Logger Micrometer Metrics ──
         io.micrometer.core.instrument.Gauge.builder("cbq.async.submit.count", SUBMIT_COUNT, LongAdder::sum)
                 .description("Total number of async log submissions")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.submit.avg.latency",
                         LogMetrics::getAvgSubmitLatencyMs)
                 .description("Average async log submission latency in ms")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.backpressure.events", BACKPRESSURE_EVENTS, LongAdder::sum)
                 .description("Number of times backpressure was applied")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.queue.full.events", QUEUE_FULL_EVENTS, LongAdder::sum)
                 .description("Number of times queue was full")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.queue.current.size",
                         LogMetrics::getCurrentQueueSize)
                 .description("Current async logger queue size")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.queue.peak.size",
                         LogMetrics::getPeakQueueSize)
                 .description("Peak async logger queue size")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.threads.active",
                         LogMetrics::getCurrentActiveThreads)
                 .description("Current active async logger threads")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.threads.peak",
                         LogMetrics::getPeakActiveThreads)
                 .description("Peak active async logger threads")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.threads.pool.size",
                         LogMetrics::getCurrentPoolSize)
                 .description("Current async logger thread pool size")
                 .register(reg);

         io.micrometer.core.instrument.Gauge.builder("cbq.async.backpressure.rate",
                         LogMetrics::getBackpressureRate)
                 .description("Percentage of submissions that experienced backpressure")
                 .register(reg);
      }
   }

   // ── Internal ─────────────────────────────────────────────────────────────

   public static final class TaskCounter {
      private final LongAdder count = new LongAdder();
      private final LongAdder failures = new LongAdder();
      private final LongAdder totalMs = new LongAdder();
      private final LongAdder slowCount = new LongAdder();

      void record(long ms, boolean success) {
         count.increment();
         totalMs.add(ms);
         if (!success) failures.increment();
         if (ms > slowQueryThresholdMs) slowCount.increment();
      }

      Map<String, Object> snapshot() {
         long c = count.sum(), f = failures.sum(), t = totalMs.sum(), s = slowCount.sum();
         var m = new java.util.LinkedHashMap<String, Object>();
         m.put("count", c);
         m.put("failures", f);
         m.put("total_ms", t);
         m.put("avg_ms", c > 0 ? t / c : 0);
         m.put("slow", s);
         return m;
      }
   }
}