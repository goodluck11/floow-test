package com.cbq.log.metrics;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

/**
 * Lock-free log metrics using LongAdder. Zero contention on hot paths.
 *
 * <pre>{@code
 * // Auto-incremented by CbqLog on every log call:
 * LogMetrics.getErrorCount();
 * LogMetrics.getWarnCount();
 * LogMetrics.snapshot(); // {"error":5,"warn":12,"info":1034,"db.save":{"count":50,"fail":2,"total_ms":2300}}
 *
 * // Register Micrometer bridge (optional):
 * LogMetrics.bindTo(meterRegistry);
 * }</pre>
 */
public final class LogMetrics {
   private static final LongAdder TRACE = new LongAdder(), DEBUG = new LongAdder(),
           INFO = new LongAdder(), WARN = new LongAdder(), ERROR = new LongAdder();

   // Task metrics: "taskType.operation" → TaskCounter
   private static final ConcurrentHashMap<String, TaskCounter> TASKS = new ConcurrentHashMap<>();

   // Slow query tracking
   private static volatile long slowQueryThresholdMs = 500;

   private LogMetrics() {
   }

   // ── Level counters ───────────────────────────────────────────────────────

   public static void incrementTrace() {
      TRACE.increment();
   }

   public static void incrementDebug() {
      DEBUG.increment();
   }

   public static void incrementInfo() {
      INFO.increment();
   }

   public static void incrementWarn() {
      WARN.increment();
   }

   public static void incrementError() {
      ERROR.increment();
   }

   public static long getTraceCount() {
      return TRACE.sum();
   }

   public static long getDebugCount() {
      return DEBUG.sum();
   }

   public static long getInfoCount() {
      return INFO.sum();
   }

   public static long getWarnCount() {
      return WARN.sum();
   }

   public static long getErrorCount() {
      return ERROR.sum();
   }

   // ── Task counters ────────────────────────────────────────────────────────

   public static void recordTask(String taskType, String operation, long durationMs, boolean success) {
      String key = taskType + "." + operation;
      TASKS.computeIfAbsent(key, k -> new TaskCounter()).record(durationMs, success);
   }

   public static void setSlowQueryThreshold(long ms) {
      slowQueryThresholdMs = ms;
   }

   public static long getSlowQueryThreshold() {
      return slowQueryThresholdMs;
   }

   // ── Snapshot ─────────────────────────────────────────────────────────────

   public static Map<String, Object> snapshot() {
      var m = new java.util.LinkedHashMap<String, Object>();
      m.put("trace", TRACE.sum());
      m.put("debug", DEBUG.sum());
      m.put("info", INFO.sum());
      m.put("warn", WARN.sum());
      m.put("error", ERROR.sum());
      TASKS.forEach((k, v) -> m.put(k, v.snapshot()));
      return m;
   }

   public static void reset() {
      TRACE.reset();
      DEBUG.reset();
      INFO.reset();
      WARN.reset();
      ERROR.reset();
      TASKS.clear();
   }

   // ── Micrometer bridge (optional) ────────────────────────────────────────

   /**
    * Bind to Micrometer MeterRegistry if available. Call once at startup.
    * Micrometer is an {@code <optional>} dependency — this safely no-ops if absent.
    * <pre>{@code LogMetrics.bindTo(meterRegistry); }</pre>
    */
   public static void bindTo(Object meterRegistry) {
      try {
         MicrometerBridge.bind((io.micrometer.core.instrument.MeterRegistry) meterRegistry);
      } catch (NoClassDefFoundError | Exception e) {
         // Micrometer not on classpath — silently skip
      }
   }

   /**
    * Isolated inner class. Only loaded by the JVM when {@link #bindTo} is called,
    * so if Micrometer is not on the classpath, this class is never touched
    * and no ClassNotFoundException occurs.
    */
   private static final class MicrometerBridge {
      static void bind(io.micrometer.core.instrument.MeterRegistry reg) {
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", TRACE, LongAdder::sum).tag("level", "trace").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", DEBUG, LongAdder::sum).tag("level", "debug").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", INFO, LongAdder::sum).tag("level", "info").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", WARN, LongAdder::sum).tag("level", "warn").register(reg);
         io.micrometer.core.instrument.Gauge.builder("cbq.log.count", ERROR, LongAdder::sum).tag("level", "error").register(reg);
      }
   }

   // ── Internal ─────────────────────────────────────────────────────────────

   public static final class TaskCounter {
      private final LongAdder count = new LongAdder();
      private final LongAdder failures = new LongAdder();
      private final LongAdder totalMs = new LongAdder();
      private final LongAdder slowCount = new LongAdder();

      void record(long ms, boolean success) {
         count.increment();
         totalMs.add(ms);
         if (!success) failures.increment();
         if (ms > slowQueryThresholdMs) slowCount.increment();
      }

      Map<String, Object> snapshot() {
         long c = count.sum(), f = failures.sum(), t = totalMs.sum(), s = slowCount.sum();
         var m = new java.util.LinkedHashMap<String, Object>();
         m.put("count", c);
         m.put("failures", f);
         m.put("total_ms", t);
         m.put("avg_ms", c > 0 ? t / c : 0);
         m.put("slow", s);
         return m;
      }
   }
}