package com.cbq.log.sampling;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Zero-cost log sampling. Decides whether to log based on a probability [0.0–1.0].
 * Uses ThreadLocalRandom — no contention, no allocation on skip.
 *
 * <pre>{@code
 * if (LogSampler.shouldLog(0.01)) { ... } // 1% of calls
 * }</pre>
 */
public final class LogSampler {
   private LogSampler() {
   }

   /**
    * Returns true with probability {@code rate} (0.0 = never, 1.0 = always)
    */
   public static boolean shouldLog(double rate) {
      if (rate >= 1.0) return true;
      if (rate <= 0.0) return false;
      return ThreadLocalRandom.current().nextDouble() < rate;
   }
}

