package com.cbq.log.format;

import com.cbq.log.mask.MaskEngine;
import java.util.Map;

/**
 * Boxed text output for high visibility.
 */
public final class PrettyTextLogFormatter implements LogFormatter {
   private static final int WIDTH = 70;

   @Override
   public String format(Map<String, Object> entry) {
      var sb = new StringBuilder();
      
      String type = String.valueOf(entry.getOrDefault("type", "LOG")).replace("_", " ").toUpperCase();
      String header = "CBQ " + type;
      
      // Top border
      sb.append("╔").append("═".repeat(WIDTH)).append("╗\n");
      
      // Header
      sb.append("║ ").append(pad(header, WIDTH - 1)).append("║\n");
      
      // Separator
      sb.append("╠").append("═".repeat(WIDTH)).append("╣\n");
      
      // Fields
      for (var e : entry.entrySet()) {
         String key = e.getKey();
         if ("type".equals(key)) continue;
         
         Object val = e.getValue();
         if (val instanceof Map || "body".equals(key) || "request".equals(key) || "response".equals(key)) {
            sb.append("║ ").append(key).append(":\n");
            String json = MaskEngine.toJson(val);
            for (String line : json.split("\n")) {
               sb.append("║ ").append(line).append("\n");
            }
         } else {
            String label = capitalize(key.replace("_", " "));
            sb.append("║ ").append(label).append(": ").append(val).append("\n");
         }
      }
      
      // Bottom border
      sb.append("╚").append("═".repeat(WIDTH)).append("╝");
      
      return sb.toString();
   }

   private String pad(String s, int n) {
      if (s.length() >= n) return s;
      return s + " ".repeat(n - s.length());
   }

   private String capitalize(String s) {
      if (s == null || s.isEmpty()) return s;
      if (s.length() == 1) return s.toUpperCase();
      return s.substring(0, 1).toUpperCase() + s.substring(1);
   }
}
