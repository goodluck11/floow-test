package com.cbq.log.async;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Non-blocking log writer. Dispatches log writes to a background executor.
 *
 * <p>Uses virtual threads if Java 21+ available, otherwise a single-thread cached pool.
 * The executor is lazily created and shared across all CbqLog instances.
 */
public final class AsyncLogWriter {
    private static volatile ExecutorService executor;
    private static final AtomicBoolean shutdown = new AtomicBoolean(false);

    private AsyncLogWriter() {}

    public static void submit(Runnable task) {
        if (shutdown.get()) { task.run(); return; } // fallback to sync after shutdown
        getExecutor().execute(task);
    }

    public static void shutdown() {
        shutdown.set(true);
        if (executor != null) {
            executor.shutdown();
            try { if (!executor.awaitTermination(3, TimeUnit.SECONDS)) executor.shutdownNow(); }
            catch (InterruptedException e) { executor.shutdownNow(); Thread.currentThread().interrupt(); }
        }
    }

    private static ExecutorService getExecutor() {
        if (executor == null) {
            synchronized (AsyncLogWriter.class) {
                if (executor == null) executor = createExecutor();
            }
        }
        return executor;
    }

    private static ExecutorService createExecutor() {
        try {
            // Try virtual threads first (Java 21+)
            var method = Executors.class.getMethod("newVirtualThreadPerTaskExecutor");
            return (ExecutorService) method.invoke(null);
        } catch (Exception e) {
            // Fallback: cached thread pool with daemon threads
            return Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r, "cbq-log-async");
                t.setDaemon(true);
                return t;
            });
        }
    }
}
