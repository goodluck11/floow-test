package com.cbq.log.async;

import com.cbq.log.metrics.LogMetrics;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Non-blocking log writer. Dispatches log writes to a background executor.
 *
 * <p>Uses virtual threads if Java 21+ available, otherwise a single-thread cached pool.
 * The executor is lazily created and shared across all CbqLog instances.
 */
public final class AsyncLogWriter {
   private static final AtomicReference<ExecutorService> executorRef = new AtomicReference<>();
   private static final AtomicBoolean shutdown = new AtomicBoolean(false);
   private static final AtomicReference<Semaphore> semaphoreRef = new AtomicReference<>();

   private AsyncLogWriter() {
   }

   public static void submit(Runnable task) {
      if (shutdown.get()) {
         task.run();
         return;
      }

      long start = System.currentTimeMillis();
      try {
         ExecutorService exec = getExecutor();
         boolean queueFull = false;

         Semaphore semaphore = semaphoreRef.get();
         if (semaphore != null) {
            if (!semaphore.tryAcquire()) {
               // Backpressure: run in caller thread
               task.run();
               long latencyMs = System.currentTimeMillis() - start;
               LogMetrics.recordAsyncSubmission(latencyMs, true, true);
               return;
            }
         } else if (exec instanceof ThreadPoolExecutor tpe) {
            queueFull = tpe.getQueue().remainingCapacity() == 0;
         }

         exec.execute(() -> {
            try {
               task.run();
            } finally {
               Semaphore sem = semaphoreRef.get();
               if (sem != null) {
                  sem.release();
               }
            }
         });

         long latencyMs = System.currentTimeMillis() - start;
         LogMetrics.recordAsyncSubmission(latencyMs, false, queueFull);
      } catch (RejectedExecutionException e) {
         // Caller runs policy or explicit rejection - counts as backpressure
         task.run();
         long latencyMs = System.currentTimeMillis() - start;
         LogMetrics.recordAsyncSubmission(latencyMs, true, true);
      } catch (Exception e) {
         // Fallback for any other submission error
         task.run();
         long latencyMs = System.currentTimeMillis() - start;
         LogMetrics.recordAsyncSubmission(latencyMs, true, true);
      }
   }

   /**
    * Re-initializes the executor with new configuration.
    */
   public static void setConfiguration(int core, int max, int queue) {
      ExecutorService newExecutor = createBoundedExecutor(core, max, queue);
      if (isVirtualThreadAvailable()) {
         semaphoreRef.set(new Semaphore(queue));
      } else {
         semaphoreRef.set(null);
      }
      registerMetrics(newExecutor);

      ExecutorService oldExecutor = executorRef.getAndSet(newExecutor);
      shutdown.set(false);

      if (oldExecutor != null) {
         oldExecutor.shutdown();
      }
   }

   public static void shutdown() {
      // 1. Mark as shut down immediately so no new tasks are accepted via submit()
      shutdown.set(true);

      // 2. Atomically grab the executor and set the reference to null
      ExecutorService exec = executorRef.getAndSet(null);

      if (exec != null) {
         // 3. Initiate graceful shutdown (stops accepting new tasks at the thread pool level)
         exec.shutdown();
         try {
            // 4. Wait for existing tasks in the queue to finish.
            // In finance, we give this a reasonable window (e.g., 5 seconds).
            if (!exec.awaitTermination(5, TimeUnit.SECONDS)) {
               // 5. If it takes too long, force it (potential data loss here but prevents hang)
               exec.shutdownNow();
            }
         } catch (InterruptedException e) {
            exec.shutdownNow();
            Thread.currentThread().interrupt();
         }
      }
   }

   private static void registerMetrics(ExecutorService exec) {
      if (exec instanceof ThreadPoolExecutor tpe) {
         LogMetrics.registerAsyncLoggerMetrics(
                 () -> tpe.getQueue().size(),
                 tpe::getActiveCount,
                 tpe::getPoolSize,
                 tpe::getLargestPoolSize
         );
      } else if (semaphoreRef.get() != null) {
         LogMetrics.registerAsyncLoggerMetrics(
                 () -> 0,
                 () -> 0,
                 () -> 0,
                 () -> 0
         );
      }
   }

   private static ExecutorService getExecutor() {
      ExecutorService current = executorRef.get();
      if (current == null) {
         current = executorRef.updateAndGet(existing -> {
            if (existing != null) return existing;
            int queueSize = 5000;
            ExecutorService exec = createBoundedExecutor(2, 4, queueSize);
            if (isVirtualThreadAvailable()) {
               semaphoreRef.set(new Semaphore(queueSize));
            }
            registerMetrics(exec);
            return exec;
         });
      }
      return current;
   }

   private static ExecutorService createBoundedExecutor(int core, int max, int queue) {
      if (isVirtualThreadAvailable()) {
         try {
            var method = Executors.class.getMethod("newVirtualThreadPerTaskExecutor");
            return (ExecutorService) method.invoke(null);
         } catch (Exception e) {
            // fallback
         }
      }

      return new ThreadPoolExecutor(
              core, max,
              60L, TimeUnit.SECONDS,
              new LinkedBlockingQueue<>(queue),
              createPlatformThreadFactory(),
              new ThreadPoolExecutor.CallerRunsPolicy()
      );
   }

   public static int getQueueSize() {
      var exec = executorRef.get();
      return (exec instanceof ThreadPoolExecutor tpe) ? tpe.getQueue().size() : 0;
   }

   public static int getActiveThreads() {
      var exec = executorRef.get();
      return (exec instanceof ThreadPoolExecutor tpe) ? tpe.getActiveCount() : -1;
   }

   private static ThreadFactory createPlatformThreadFactory() {
      return r -> {
         var t = new Thread(r, "cbq-plog-" + System.nanoTime());
         t.setDaemon(true);
         return t;
      };
   }

   private static boolean isVirtualThreadAvailable() {
      try {
         var version = System.getProperty("java.version");
         if (version.startsWith("1.") ||
                 Integer.parseInt(version.split("\\.")[0]) < 21) {
            return false;
         }

         Class.forName("java.lang.Thread$Builder$OfVirtual");
         Thread.class.getMethod("ofVirtual");
         return true;
      } catch (ClassNotFoundException | NoSuchMethodException e) {
         return false;
      }
   }
}
