package com.cbq.log.mask;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Pre-built masking profiles for common compliance and gateway scenarios.
 *
 * <pre>{@code
 * CbqLogConfig.builder()
 *     .maskProfile(MaskProfile.PCI)
 *     .maskProfile(MaskProfile.KONG_GATEWAY)
 *     .maskFields("customField")
 *     .build();
 * }</pre>
 */
public final class MaskProfile {
   private final String name;
   private final Set<String> fields;

   private MaskProfile(String name, Set<String> fields) {
      this.name = name;
      this.fields = Set.copyOf(fields);
   }

   public String name() {
      return name;
   }

   public Set<String> fields() {
      return fields;
   }

   /**
    * PCI-DSS: card data, CVV, PINs, auth codes
    */
   public static final MaskProfile PCI = new MaskProfile("PCI", Set.of(
           "cardNumber", "card_number", "pan", "primaryAccountNumber",
           "cvv", "cvv2", "cvc", "securityCode", "security_code",
           "pin", "pinBlock", "pin_block",
           "track1", "track2", "trackData", "track_data",
           "authCode", "auth_code", "authorizationCode"));

   /**
    * GDPR: personal identifiers
    */
   public static final MaskProfile GDPR = new MaskProfile("GDPR", Set.of(
           "email", "emailAddress", "email_address",
           "phone", "phoneNumber", "phone_number", "mobile", "msisdn",
           "firstName", "first_name", "lastName", "last_name", "fullName", "full_name",
           "dateOfBirth", "date_of_birth", "dob",
           "ssn", "socialSecurityNumber", "social_security_number",
           "nationalId", "national_id", "bvn", "nin",
           "address", "streetAddress", "street_address", "postCode", "zipCode"));

   /**
    * HIPAA: health data
    */
   public static final MaskProfile HIPAA = new MaskProfile("HIPAA", Set.of(
           "patientId", "patient_id", "medicalRecordNumber", "medical_record_number", "mrn",
           "diagnosis", "diagnosisCode", "diagnosis_code",
           "prescription", "medication", "treatment",
           "insuranceId", "insurance_id", "insurancePolicyNumber",
           "ssn", "dateOfBirth", "date_of_birth"));

   /**
    * Kong Gateway: headers and fields commonly forwarded by Kong
    */
   public static final MaskProfile KONG_GATEWAY = new MaskProfile("KONG_GATEWAY", Set.of(
           "Authorization", "X-Consumer-Custom-ID", "X-Consumer-Username",
           "X-Credential-Identifier", "X-Anonymous-Consumer",
           "apikey", "api_key", "X-API-Key",
           "X-Consumer-ID", "X-Forwarded-For",
           "cookie", "Cookie", "Set-Cookie"));

   /**
    * Auth: tokens, secrets, API keys
    */
   public static final MaskProfile AUTH = new MaskProfile("AUTH", Set.of(
           "password", "passwd", "secret", "secretKey", "secret_key",
           "token", "accessToken", "access_token", "refreshToken", "refresh_token",
           "idToken", "id_token", "bearerToken", "bearer_token",
           "apiKey", "api_key", "apiSecret", "api_secret",
           "clientSecret", "client_secret", "privateKey", "private_key"));

   /**
    * Nigerian fintech: BVN, NIN, account numbers
    */
   public static final MaskProfile NIGERIA_FINTECH = new MaskProfile("NIGERIA_FINTECH", Set.of(
           "bvn", "nin", "accountNumber", "account_number",
           "nuban", "bankAccountNumber", "bank_account_number",
           "cardNumber", "card_number", "cvv", "pin",
           "phoneNumber", "phone_number", "msisdn",
           "email", "dateOfBirth", "date_of_birth"));

   /**
    * Compose multiple profiles into a single field set
    */
   public static Set<String> compose(MaskProfile... profiles) {
      var all = new LinkedHashSet<String>();
      for (var p : profiles) all.addAll(p.fields);
      return Set.copyOf(all);
   }

   /**
    * Create a custom named profile
    */
   public static MaskProfile of(String name, String... fields) {
      return new MaskProfile(name, Set.of(fields));
   }
}
