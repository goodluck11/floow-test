package com.cbq.log.format;

import java.util.Map;

/**
 * Human-readable key=value text output.
 */
public final class TextLogFormatter implements LogFormatter {
   @Override
   public String format(Map<String, Object> entry) {
      var sb = new StringBuilder();
      entry.forEach((k, v) -> {
         if (!sb.isEmpty()) sb.append(' ');
         sb.append(k).append('=');
         if (v instanceof String s && s.contains(" ")) sb.append('"').append(s).append('"');
         else sb.append(v);
      });
      return sb.toString();
   }
}
