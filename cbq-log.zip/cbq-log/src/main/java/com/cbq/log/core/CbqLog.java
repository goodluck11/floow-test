package com.cbq.log.core;

import com.cbq.log.async.AsyncLogWriter;
import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.context.LogContext;
import com.cbq.log.event.LogEventBus;
import com.cbq.log.format.JsonLogFormatter;
import com.cbq.log.format.LogFormatter;
import com.cbq.log.format.TextLogFormatter;
import com.cbq.log.mask.MaskEngine;
import com.cbq.log.metrics.LogMetrics;
import com.cbq.log.sampling.LogSampler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Structured logger with annotation-driven masking, async/sync modes, and MDC correlation.
 *
 * <h3>Usage:</h3>
 * <pre>{@code
 * private static final CbqLog log = CbqLog.getLogger(PaymentService.class);
 *
 * log.info("order created", order);              // auto-masks @MaskSensitive fields
 * log.error("payment failed", payment, ex);
 * * log.sampled(0.01).info("high-freq event", data);       // 1% sampling
 * log.task("db", "insert", "orders", 45, true);
 * log.httpRequest("POST", "/charges", headers, body);
 * log.httpResponse("POST", "/charges", 201, 245, resp);
 * }</pre>
 *
 * <p>Thread-safe. One CbqLog per class, cached. Lombok @CustomLog compatible.
 *
 */
public final class CbqLog {

   private static volatile CbqLogConfig config = CbqLogConfig.defaults();
   private static volatile LogFormatter formatter = new JsonLogFormatter();

   public static void configure(CbqLogConfig cfg) {
      config = cfg;
      formatter = cfg.format() == CbqLogConfig.LogFormat.JSON ? new JsonLogFormatter() : new TextLogFormatter();
      LogContext.configure(cfg.correlationKey(), cfg.requestIdKey());
      LogMetrics.setSlowQueryThreshold(cfg.slowQueryThresholdMs());
   }

   public static CbqLogConfig getConfig() {
      return config;
   }

   // ── Factory ──────────────────────────────────────────────────────────────
   private static final ConcurrentHashMap<String, CbqLog> CACHE = new ConcurrentHashMap<>();

   public static CbqLog getLogger(Class<?> clazz) {
      return getLogger(clazz.getName());
   }

   public static CbqLog getLogger(String name) {
      return CACHE.computeIfAbsent(name, n -> new CbqLog(LoggerFactory.getLogger(n), 1.0));
   }

   // ── Instance ─────────────────────────────────────────────────────────────
   private final Logger delegate;
   private final double sampleRate;

   private CbqLog(Logger delegate, double sampleRate) {
      this.delegate = delegate;
      this.sampleRate = sampleRate;
   }

   public String getName() {
      return delegate.getName();
   }

   public boolean isTraceEnabled() {
      return delegate.isTraceEnabled();
   }

   public boolean isDebugEnabled() {
      return delegate.isDebugEnabled();
   }

   public boolean isInfoEnabled() {
      return delegate.isInfoEnabled();
   }

   public boolean isWarnEnabled() {
      return delegate.isWarnEnabled();
   }

   public boolean isErrorEnabled() {
      return delegate.isErrorEnabled();
   }

   /**
    * Return a sampled view of this logger. Only logs with given probability.
    * <pre>{@code log.sampled(0.01).info("tick", data); }</pre>
    */
   public CbqLog sampled(double rate) {
      return new CbqLog(delegate, rate);
   }

   // ── Standard levels ──────────────────────────────────────────────────────
   public void trace(String msg) {
      log(Lvl.TRACE, msg, null, null);
   }

   public void trace(String msg, Object payload) {
      log(Lvl.TRACE, msg, payload, null);
   }

   public void debug(String msg) {
      log(Lvl.DEBUG, msg, null, null);
   }

   public void debug(String msg, Object payload) {
      log(Lvl.DEBUG, msg, payload, null);
   }

   public void info(String msg) {
      log(Lvl.INFO, msg, null, null);
   }

   public void info(String msg, Object payload) {
      log(Lvl.INFO, msg, payload, null);
   }

   public void warn(String msg) {
      log(Lvl.WARN, msg, null, null);
   }

   public void warn(String msg, Object payload) {
      log(Lvl.WARN, msg, payload, null);
   }

   public void warn(String msg, Throwable t) {
      log(Lvl.WARN, msg, null, t);
   }

   public void warn(String msg, Object payload, Throwable t) {
      log(Lvl.WARN, msg, payload, t);
   }

   public void error(String msg) {
      log(Lvl.ERROR, msg, null, null);
   }

   public void error(String msg, Throwable t) {
      log(Lvl.ERROR, msg, null, t);
   }

   public void error(String msg, Object payload) {
      log(Lvl.ERROR, msg, payload, null);
   }

   public void error(String msg, Object payload, Throwable t) {
      log(Lvl.ERROR, msg, payload, t);
   }

   // ── Structured kv ────────────────────────────────────────────────────────
   public void info(String msg, Object... kv) {
      logKv(Lvl.INFO, msg, kv);
   }

   public void debug(String msg, Object... kv) {
      logKv(Lvl.DEBUG, msg, kv);
   }

   public void warn(String msg, Object... kv) {
      logKv(Lvl.WARN, msg, kv);
   }

   public void error(String msg, Object... kv) {
      logKv(Lvl.ERROR, msg, kv);
   }

   // ── Task logging ─────────────────────────────────────────────────────────
   public void task(String type, String op, String target, long ms, boolean ok) {
      task(type, op, target, ms, ok, null);
   }

   public void task(String type, String op, String target, long ms, boolean ok, String detail) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "task");
      e.put("task_type", type);
      e.put("operation", op);
      e.put("target", target);
      e.put("duration_ms", ms);
      e.put("success", ok);
      if (detail != null) e.put("detail", detail);
      LogMetrics.recordTask(type, op, ms, ok);
      dispatch(Lvl.INFO, e, null);
   }

   // ── HTTP logging ─────────────────────────────────────────────────────────
   public void httpRequest(String method, String uri, Map<String, String> headers, Object body) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "http_request");
      e.put("method", method);
      e.put("uri", uri);
      if (headers != null) e.put("headers", maskHdrs(headers));
      if (body != null) e.put("body", masked(body));
      dispatch(Lvl.INFO, e, null);
   }

   public void httpResponse(String method, String uri, int status, long ms, Object body) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "http_response");
      e.put("method", method);
      e.put("uri", uri);
      e.put("status", status);
      e.put("duration_ms", ms);
      if (body != null) e.put("body", masked(body));
      dispatch(Lvl.INFO, e, null);
   }

   public void httpError(String method, String uri, long ms, Throwable err) {
      var e = base(Lvl.ERROR);
      e.put("type", "http_error");
      e.put("method", method);
      e.put("uri", uri);
      e.put("duration_ms", ms);
      e.put("error", err.getClass().getSimpleName());
      e.put("error_message", err.getMessage());
      dispatch(Lvl.ERROR, e, err);
   }

   // ── Audit (always sync, never sampled, includes caller) ──────────────────
   public void audit(String msg, Object payload) {
      var e = base(Lvl.INFO);
      e.put("type", "audit");
      e.put("message", msg);
      if (payload != null) e.put("data", masked(payload));
      // Force caller info for audit
      addCallerInfo(e);
      // Always sync, always log
      write(Lvl.INFO, e, null);
      LogMetrics.incrementInfo();
      LogEventBus.fire(e);
   }

   // ── Internal ─────────────────────────────────────────────────────────────
   private enum Lvl {TRACE, DEBUG, INFO, WARN, ERROR}

   private boolean enabled(Lvl l) {
      return switch (l) {
         case TRACE -> delegate.isTraceEnabled();
         case DEBUG -> delegate.isDebugEnabled();
         case INFO -> delegate.isInfoEnabled();
         case WARN -> delegate.isWarnEnabled();
         case ERROR -> delegate.isErrorEnabled();
      };
   }

   private boolean shouldSample() {
      double rate = sampleRate < 1.0 ? sampleRate : config.defaultSampleRate();
      return LogSampler.shouldLog(rate);
   }

   private void log(Lvl l, String msg, Object payload, Throwable err) {
      if (!enabled(l) || !shouldSample()) return;
      var e = base(l);
      e.put("message", msg);
      if (payload != null) e.put("data", masked(payload));
      if (err != null) {
         e.put("error", err.getClass().getSimpleName());
         e.put("error_message", err.getMessage());
      }
      dispatch(l, e, err);
   }

   private void logKv(Lvl l, String msg, Object... kv) {
      if (!enabled(l) || !shouldSample()) return;
      if (kv.length == 1 && !(kv[0] instanceof String)) {
         log(l, msg, kv[0], null);
         return;
      }
      var e = base(l);
      e.put("message", msg);
      for (int i = 0; i + 1 < kv.length; i += 2) e.put(String.valueOf(kv[i]), kv[i + 1]);
      dispatch(l, e, null);
   }

   private void dispatch(Lvl l, Map<String, Object> entry, Throwable err) {
      incrementMetric(l);
      LogEventBus.fire(entry);
      if (config.async()) {
         var mdc = MDC.getCopyOfContextMap();
         AsyncLogWriter.submit(() -> {
            if (mdc != null) MDC.setContextMap(mdc);
            write(l, entry, err);
         });
      } else {
         write(l, entry, err);
      }
   }

   private void write(Lvl l, Map<String, Object> entry, Throwable err) {
      String line = formatter.format(entry);
      switch (l) {
         case TRACE -> delegate.trace(line);
         case DEBUG -> delegate.debug(line);
         case INFO -> delegate.info(line);
         case WARN -> {
            if (err != null) delegate.warn(line, err);
            else delegate.warn(line);
         }
         case ERROR -> {
            if (err != null) delegate.error(line, err);
            else delegate.error(line);
         }
      }
   }

   private LinkedHashMap<String, Object> base(Lvl level) {
      var e = new LinkedHashMap<String, Object>();
      e.put("timestamp", Instant.now().toString());
      e.put("level", level.name());
      e.put("service", config.serviceName());
      String c = LogContext.getCorrelationId(), r = LogContext.getRequestId();
      if (c != null) e.put("cid", c);
      if (r != null) e.put("rid", r);
      // Gateway context from MDC (if extracted via GatewayContext)
      String ua = MDC.get("user_agent"), ip = MDC.get("client_ip"), gw = MDC.get("gateway.consumer");
      if (ua != null) e.put("user_agent", ua);
      if (ip != null) e.put("client_ip", ip);
      if (gw != null) e.put("gateway_consumer", gw);
      if (config.includeCallerInfo()) addCallerInfo(e);
      return e;
   }

   private void addCallerInfo(Map<String, Object> e) {
      var st = Thread.currentThread().getStackTrace();
      for (int i = 3; i < st.length; i++) {
         if (!st[i].getClassName().startsWith("com.cbq.log.")) {
            e.put("caller", st[i].getClassName() + "." + st[i].getMethodName() + ":" + st[i].getLineNumber());
            break;
         }
      }
   }

   private Object masked(Object payload) {
      if (payload instanceof String s) {
         String t = s.length() > config.maxBodySize() ? s.substring(0, config.maxBodySize()) + "...[TRUNCATED]" : s;
         if (config.maskFields().isEmpty() && config.maskJsonPaths().isEmpty()) return t;
         return MaskEngine.maskJson(t, config.maskFields(), config.maskJsonPaths(), config.maskSymbol());
      }
      if (payload instanceof Map<?, ?>)
         return config.maskFields().isEmpty() ? payload : MaskEngine.maskToMap(payload, config.maskFields(), config.maskSymbol());
      return MaskEngine.maskToMap(payload, config.maskFields(), config.maskSymbol());
   }

   private Map<String, String> maskHdrs(Map<String, String> h) {
      var m = new LinkedHashMap<String, String>();
      h.forEach((k, v) -> m.put(k, MaskEngine.maskHeader(k, v, config.maskFields(), config.maskSymbol())));
      return m;
   }

   private void incrementMetric(Lvl l) {
      switch (l) {
         case TRACE -> LogMetrics.incrementTrace();
         case DEBUG -> LogMetrics.incrementDebug();
         case INFO -> LogMetrics.incrementInfo();
         case WARN -> LogMetrics.incrementWarn();
         case ERROR -> LogMetrics.incrementError();
      }
   }
}
