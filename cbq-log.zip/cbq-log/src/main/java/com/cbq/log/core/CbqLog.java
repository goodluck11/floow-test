package com.cbq.log.core;

import com.cbq.log.async.AsyncLogWriter;
import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.context.LogContext;
import com.cbq.log.event.LogEventBus;
import com.cbq.log.format.JsonLogFormatter;
import com.cbq.log.format.LogFormatter;
import com.cbq.log.format.PrettyTextLogFormatter;
import com.cbq.log.format.TextLogFormatter;
import com.cbq.log.mask.MaskEngine;
import com.cbq.log.metrics.LogMetrics;
import com.cbq.log.sampling.LogSampler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.spi.LocationAwareLogger;

import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Structured logger with annotation-driven masking, async/sync modes, and MDC correlation.
 *
 * <h3>Usage:</h3>
 * <pre>{@code
 * private static final CbqLog log = CbqLog.getLogger(PaymentService.class);
 *
 * log.info("order created", order);              // auto-masks @MaskSensitive fields
 * log.error("payment failed", payment, ex);
 * * log.sampled(0.01).info("high-freq event", data);       // 1% sampling
 * log.task("db", "insert", "orders", 45, true);
 * log.httpRequest("POST", "/charges", headers, body);
 * log.httpResponse("POST", "/charges", 201, 245, resp);
 * }</pre>
 *
 * <p>Thread-safe. One CbqLog per class, cached. Lombok @CustomLog compatible.
 *
 */
public final class CbqLog {

   private record State(CbqLogConfig config, LogFormatter formatter) {
   }

   private static volatile State state = new State(CbqLogConfig.defaults(), new JsonLogFormatter());

   public static void configure(CbqLogConfig cfg) {
      LogFormatter fmt;
      if (cfg.format() == CbqLogConfig.LogFormat.JSON || cfg.format() == CbqLogConfig.LogFormat.PRETTY) {
         fmt = new JsonLogFormatter();
      } else if (cfg.format() == CbqLogConfig.LogFormat.PRETTY_TEXT) {
         fmt = new PrettyTextLogFormatter();
      } else {
         fmt = new TextLogFormatter();
      }
      state = new State(cfg, fmt);
      LogContext.configure(cfg.correlationKey(), cfg.requestIdKey());
      LogMetrics.setSlowQueryThreshold(cfg.slowQueryThresholdMs());
      AsyncLogWriter.setConfiguration(cfg.asyncCorePoolSize(), cfg.asyncMaxPoolSize(), cfg.asyncQueueCapacity());
   }

   public static CbqLogConfig getConfig() {
      return state.config();
   }

   // ── Factory ──────────────────────────────────────────────────────────────
   private static final String FQCN = CbqLog.class.getName();
   private static final ConcurrentHashMap<String, CbqLog> CACHE = new ConcurrentHashMap<>();

   public static CbqLog getLogger(Class<?> clazz) {
      return getLogger(clazz.getName());
   }

   public static CbqLog getLogger(String name) {
      return CACHE.computeIfAbsent(name, n -> new CbqLog(LoggerFactory.getLogger(n), 1.0));
   }

   // ── Instance ─────────────────────────────────────────────────────────────
   private final Logger delegate;
   private final double sampleRate;

   private CbqLog(Logger delegate, double sampleRate) {
      this.delegate = delegate;
      this.sampleRate = sampleRate;
   }

   public String getName() {
      return delegate.getName();
   }

   public boolean isTraceEnabled() {
      return delegate.isTraceEnabled();
   }

   public boolean isDebugEnabled() {
      return delegate.isDebugEnabled();
   }

   public boolean isInfoEnabled() {
      return delegate.isInfoEnabled();
   }

   public boolean isWarnEnabled() {
      return delegate.isWarnEnabled();
   }

   public boolean isErrorEnabled() {
      return delegate.isErrorEnabled();
   }

   /**
    * Return a sampled view of this logger. Only logs with the given probability.
    * <pre>{@code log.sampled(0.01).info("tick", data); }</pre>
    */
   public CbqLog sampled(double rate) {
      return new CbqLog(delegate, rate);
   }

   // ── Standard levels ──────────────────────────────────────────────────────
   public void trace(String msg, Object... args) {
      log(Lvl.TRACE, msg, args);
   }

   public void trace(Object obj) {
      log(Lvl.TRACE, obj);
   }

   public void debug(String msg, Object... args) {
      log(Lvl.DEBUG, msg, args);
   }

   public void debug(Object obj) {
      log(Lvl.DEBUG, obj);
   }

   public void info(String msg, Object... args) {
      log(Lvl.INFO, msg, args);
   }

   public void info(Object obj) {
      log(Lvl.INFO, obj);
   }

   public void warn(String msg, Object... args) {
      log(Lvl.WARN, msg, args);
   }

   public void warn(Object obj) {
      log(Lvl.WARN, obj);
   }

   public void error(String msg, Object... args) {
      log(Lvl.ERROR, msg, args);
   }

   public void error(Object obj) {
      log(Lvl.ERROR, obj);
   }

   // ── Structured kv ────────────────────────────────────────────────────────
   public void infoKv(String msg, Object... kv) {
      logKv(Lvl.INFO, msg, kv);
   }

   public void debugKv(String msg, Object... kv) {
      logKv(Lvl.DEBUG, msg, kv);
   }

   public void warnKv(String msg, Object... kv) {
      logKv(Lvl.WARN, msg, kv);
   }

   public void errorKv(String msg, Object... kv) {
      logKv(Lvl.ERROR, msg, kv);
   }

   // ── Task logging ─────────────────────────────────────────────────────────
   public void task(String type, String op, String target, long ms, boolean ok) {
      task(type, op, target, ms, ok, null);
   }

   public void task(String type, String op, String target, long ms, boolean ok, String detail) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "task");
      e.put("task_type", type);
      e.put("operation", op);
      e.put("target", target);
      e.put("duration_ms", ms);
      e.put("success", ok);
      if (detail != null) e.put("detail", detail);
      LogMetrics.recordTask(type, op, ms, ok);
      dispatch(Lvl.INFO, e, null);
   }

   // ── HTTP logging ─────────────────────────────────────────────────────────
   public void httpHeaders(String method, String uri, Map<String, String> headers) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "http_headers");
      if (method != null) e.put("method", method);
      if (uri != null) e.put("uri", uri);
      if (headers != null) e.put("headers", maskHdrs(headers));
      dispatch(Lvl.INFO, e, null);
   }

   public void httpHeaders(Map<String, String> headers) {
      httpHeaders(null, null, headers);
   }

   public void httpHeaders(String uri, Map<String, String> headers) {
      httpHeaders(null, uri, headers);
   }

   public void httpRequest(String method, String uri, Map<String, String> headers, Object body) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "http_request");
      e.put("method", method);
      e.put("uri", uri);
      if (headers != null) e.put("headers", maskHdrs(headers));
      if (body != null) e.put("body", masked(body));
      dispatch(Lvl.INFO, e, null);
   }

   public void httpRequest(String uri, Map<String, String> headers, Object request) {
      httpRequest(null, uri, headers, request);
   }

   public void httpRequest(String method, String uri, Object request) {
      httpRequest(method, uri, null, request);
   }

   public void http(String uri, Map<String, String> headers, Object request, Object response, long duration) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "http");
      e.put("uri", uri);
      e.put("duration_ms", duration);
      if (headers != null) e.put("headers", maskHdrs(headers));
      if (request != null) e.put("request", masked(request));
      if (response != null) e.put("response", masked(response));
      dispatch(Lvl.INFO, e, null);
   }

   public void httpResponse(String method, String uri, int status, long ms, Object body) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "http_response");
      e.put("method", method);
      e.put("uri", uri);
      e.put("status", status);
      e.put("duration_ms", ms);
      if (body != null) e.put("response", masked(body));
      dispatch(Lvl.INFO, e, null);
   }

   public void httpError(String method, String uri, long ms, Throwable err) {
      var e = base(Lvl.ERROR);
      e.put("type", "http_error");
      e.put("method", method);
      e.put("uri", uri);
      e.put("duration_ms", ms);
      e.put("error", err.getClass().getSimpleName());
      e.put("error_message", err.getMessage());
      dispatch(Lvl.ERROR, e, err);
   }

   // ── DB logging ───────────────────────────────────────────────────────────
   public void dbRequest(Object request) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "db_request");
      e.put("task_type", "db");
      if (request != null) e.put("request", masked(request));
      dispatch(Lvl.INFO, e, null);
   }

   public void dbResponse(Object response) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "db_response");
      e.put("task_type", "db");
      if (response != null) e.put("response", masked(response));
      dispatch(Lvl.INFO, e, null);
   }

   public void db(Object request, Object response) {
      if (!delegate.isInfoEnabled()) return;
      var e = base(Lvl.INFO);
      e.put("type", "db");
      e.put("task_type", "db");
      if (request != null) e.put("request", masked(request));
      if (response != null) e.put("response", masked(response));
      dispatch(Lvl.INFO, e, null);
   }

   // ── Audit (always sync, never sampled, includes caller) ──────────────────
   public void audit(String msg, Object payload) {
      var e = base(Lvl.INFO);
      e.put("type", "audit");
      e.put("message", msg);
      if (payload != null) e.put("data", masked(payload));
      // Force caller info for audit
      addCallerInfo(e);
      // Always sync, always log
      write(Lvl.INFO, e, null, state.formatter());
      LogMetrics.incrementInfo();
      LogEventBus.fire(e);
   }

   // ── Internal ─────────────────────────────────────────────────────────────
   private enum Lvl {
      TRACE(LocationAwareLogger.TRACE_INT),
      DEBUG(LocationAwareLogger.DEBUG_INT),
      INFO(LocationAwareLogger.INFO_INT),
      WARN(LocationAwareLogger.WARN_INT),
      ERROR(LocationAwareLogger.ERROR_INT);

      private final int slf4jLevel;

      Lvl(int slf4jLevel) {
         this.slf4jLevel = slf4jLevel;
      }

      int toSlf4jLevel() {
         return slf4jLevel;
      }
   }

   private boolean enabled(Lvl l) {
      return switch (l) {
         case TRACE -> delegate.isTraceEnabled();
         case DEBUG -> delegate.isDebugEnabled();
         case INFO -> delegate.isInfoEnabled();
         case WARN -> delegate.isWarnEnabled();
         case ERROR -> delegate.isErrorEnabled();
      };
   }

   private boolean shouldSample() {
      CbqLogConfig cfg = state.config();
      double rate = sampleRate < 1.0 ? sampleRate : cfg.defaultSampleRate();
      return LogSampler.shouldLog(rate);
   }

   private void log(Lvl l, Object obj) {
      if (!enabled(l) || !shouldSample()) return;
      var e = base(l);
      if (obj instanceof String s) {
         e.put("message", masked(s));
      } else if (obj instanceof Map) {
         e.put("data", masked(obj));
      } else {
         e.put("data", masked(obj));
      }
      dispatch(l, e, null);
   }

   private void log(Lvl l, String msg, Object... args) {
      if (!enabled(l) || !shouldSample()) return;

      Throwable err = null;
      Object payload = null;
      String formattedMsg = msg;

      if (args != null && args.length > 0) {
         int lastIdx = args.length - 1;
         Object last = args[lastIdx];
         
         int placeholderCount = countPlaceholders(msg);
         
         boolean lastIsThrowable = last instanceof Throwable;
         
         if (placeholderCount < args.length) {
            // We have more args than placeholders
            if (lastIsThrowable) {
               err = (Throwable) last;
               if (placeholderCount == args.length - 2) {
                  payload = args[args.length - 2];
               }
            } else {
               payload = last;
            }
         }

         formattedMsg = formatMessage(msg, args, placeholderCount);
      }

      var e = base(l);
      e.put("message", formattedMsg);
      if (payload != null) e.put("data", masked(payload));
      if (err != null) {
         e.put("error", err.getClass().getSimpleName());
         e.put("error_message", err.getMessage());
      }
      dispatch(l, e, err);
   }

   private int countPlaceholders(String s) {
      if (s == null) return 0;
      int count = 0;
      int i = 0;
      while ((i = s.indexOf("{}", i)) != -1) {
         count++;
         i += 2;
      }
      return count;
   }

   private String formatMessage(String msg, Object[] args, int placeholderCount) {
      if (msg == null || args == null || placeholderCount == 0) return msg;
      StringBuilder sb = new StringBuilder(msg.length() + 50);
      int argIdx = 0;
      int lastIdx = 0;
      int pos;
      while (argIdx < placeholderCount && argIdx < args.length && (pos = msg.indexOf("{}", lastIdx)) != -1) {
         sb.append(msg, lastIdx, pos);
         Object arg = args[argIdx++];
         if (arg != null && !isPrimitiveOrWrapper(arg.getClass())) {
            sb.append(masked(arg));
         } else {
            sb.append(arg);
         }
         lastIdx = pos + 2;
      }
      sb.append(msg.substring(lastIdx));
      return sb.toString();
   }

   private boolean isPrimitiveOrWrapper(Class<?> type) {
      return type.isPrimitive() ||
              type == Double.class || type == Float.class || type == Long.class ||
              type == Integer.class || type == Short.class || type == Character.class ||
              type == Byte.class || type == Boolean.class || type == String.class;
   }

   private void logKv(Lvl l, String msg, Object... kv) {
      if (!enabled(l) || !shouldSample()) return;
      if (kv.length == 1 && !(kv[0] instanceof String)) {
         log(l, msg, kv[0]);
         return;
      }
      var e = base(l);
      e.put("message", msg);
      for (int i = 0; i + 1 < kv.length; i += 2) e.put(String.valueOf(kv[i]), kv[i + 1]);
      dispatch(l, e, null);
   }

   private void dispatch(Lvl l, Map<String, Object> entry, Throwable err) {
      State s = state;
      incrementMetric(l);
      LogEventBus.fire(entry);

      // Capture location for the prefix
      String location = captureLocation();

      if (s.config().async()) {
         var mdc = MDC.getCopyOfContextMap();
         if (mdc == null) mdc = new java.util.HashMap<>();
         mdc.put("l", location);

         var finalMdc = mdc;
         AsyncLogWriter.submit(() -> {
            MDC.setContextMap(finalMdc);
            try {
               write(l, entry, err, s.formatter());
            } finally {
               MDC.clear();
            }
         });
      } else {
         String oldL = MDC.get("l");
         MDC.put("l", location);
         try {
            write(l, entry, err, s.formatter());
         } finally {
            if (oldL != null) MDC.put("l", oldL);
            else MDC.remove("l");
         }
      }
   }

   private String captureLocation() {
      var st = Thread.currentThread().getStackTrace();
      for (int i = 1; i < st.length; i++) {
         String cls = st[i].getClassName();
         if (shouldSkip(cls)) continue;
         String methodName = st[i].getMethodName();
         char firstChar = methodName.isEmpty() ? '?' : methodName.charAt(0);
         return firstChar + "(" + st[i].getFileName() + ":" + st[i].getLineNumber() + ")";
      }
      return "?(?:?)";
   }

   private boolean shouldSkip(String cls) {
      return cls.equals(FQCN) ||
              cls.equals("java.lang.Thread") ||
              cls.startsWith("com.cbq.log.") ||
              cls.startsWith("java.lang.reflect.") ||
              cls.startsWith("jdk.internal.reflect.") ||
              cls.startsWith("org.junit.") ||
              cls.startsWith("com.intellij.") ||
              cls.startsWith("org.springframework.util.ReflectionUtils");
   }

   private void write(Lvl l, Map<String, Object> entry, Throwable err, LogFormatter formatter) {
      String line = formatter.format(entry);
      // We don't use LocationAwareLogger for caller info anymore since we pass it via MDC 'l'
      switch (l) {
         case TRACE -> delegate.trace(line);
         case DEBUG -> delegate.debug(line);
         case INFO -> delegate.info(line);
         case WARN -> {
            if (err != null) delegate.warn(line, err);
            else delegate.warn(line);
         }
         case ERROR -> {
            if (err != null) delegate.error(line, err);
            else delegate.error(line);
         }
      }
   }

   private LinkedHashMap<String, Object> base(Lvl level) {
      var cfg = state.config();
      var e = new LinkedHashMap<String, Object>();
      e.put("time", OffsetDateTime.now(ZoneId.of("Asia/Qatar")));
//      e.put("level", level.name());
      e.put("svc", cfg.serviceName());
      String c = LogContext.getCorrelationId(), r = LogContext.getRequestId();
      if (c != null) e.put("cid", c);
      if (r != null) e.put("rid", r);
      // Gateway context from MDC or ContextProvider
      String ua = LogContext.get("user_agent"), ip = LogContext.get("client_ip"), gw = LogContext.get("gateway_consumer");
      if (ua == null) ua = LogContext.get("gateway.consumer");

      if (ua != null) e.put("user_agent", ua);
      if (ip != null) e.put("client_ip", ip);
      if (gw != null) e.put("gt_consumer", gw);

      // Custom MDC fields
      if (!cfg.mdcFields().isEmpty()) {
         for (String f : cfg.mdcFields()) {
            String val = LogContext.get(f);
            if (val != null) e.put(f, val);
         }
      }

      if (cfg.includeCallerInfo()) addCallerInfo(e);
      return e;
   }

   private void addCallerInfo(Map<String, Object> e) {
      var st = Thread.currentThread().getStackTrace();
      for (int i = 3; i < st.length; i++) {
         if (!st[i].getClassName().startsWith("com.cbq.log.")) {
            e.put("caller", st[i].getClassName() + "." + st[i].getMethodName() + ":" + st[i].getLineNumber());
            break;
         }
      }
   }

   private Object masked(Object payload) {
      CbqLogConfig cfg = state.config();
      if (payload instanceof String s) {
         String t = s.length() > cfg.maxBodySize() ? s.substring(0, cfg.maxBodySize()) + "...[TRUNCATED]" : s;
         if (cfg.maskFields().isEmpty() && cfg.maskJsonPaths().isEmpty()) return t;
         return MaskEngine.maskJson(t, cfg.maskFields(), cfg.maskJsonPaths(), cfg.maskSymbol());
      }
      if (payload instanceof Map<?, ?> m)
         return MaskEngine.maskMap(m, cfg.maskFields(), cfg.maskSymbol());
      return MaskEngine.maskToMap(payload, cfg.maskFields(), cfg.maskSymbol());
   }

   private Map<String, String> maskHdrs(Map<String, String> h) {
      CbqLogConfig cfg = state.config();
      var m = new LinkedHashMap<String, String>();
      h.forEach((k, v) -> m.put(k, MaskEngine.maskHeader(k, v, cfg.maskFields(), cfg.maskSymbol())));
      return m;
   }

   private void incrementMetric(Lvl l) {
      switch (l) {
         case TRACE -> LogMetrics.incrementTrace();
         case DEBUG -> LogMetrics.incrementDebug();
         case INFO -> LogMetrics.incrementInfo();
         case WARN -> LogMetrics.incrementWarn();
         case ERROR -> LogMetrics.incrementError();
      }
   }
}
