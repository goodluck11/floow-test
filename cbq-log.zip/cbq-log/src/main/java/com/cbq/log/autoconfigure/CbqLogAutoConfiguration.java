package com.cbq.log.autoconfigure;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import com.cbq.log.mask.MaskProfile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.util.Map;

@AutoConfiguration
@EnableConfigurationProperties(CbqLogProperties.class)
public class CbqLogAutoConfiguration {
   private static final Logger log = LoggerFactory.getLogger(CbqLogAutoConfiguration.class);

   private static final Map<String, MaskProfile> PROFILES = Map.ofEntries(
           Map.entry("PCI", MaskProfile.PCI),
           Map.entry("GDPR", MaskProfile.GDPR),
           Map.entry("HIPAA", MaskProfile.HIPAA),
           Map.entry("KONG", MaskProfile.KONG_GATEWAY),
           Map.entry("KONG_GATEWAY", MaskProfile.KONG_GATEWAY),
           Map.entry("AUTH", MaskProfile.AUTH),
           Map.entry("NIGERIA_FINTECH", MaskProfile.NIGERIA_FINTECH));

   @Bean
   @ConditionalOnMissingBean
   public CbqLogConfig cbqLogConfig(CbqLogProperties p) {
      var b = CbqLogConfig.builder()
              .serviceName(p.getServiceName())
              .async(p.isAsync())
              .maskFields(p.getMaskFields().toArray(String[]::new))
              .maskJsonPaths(p.getMaskJsonPaths().toArray(String[]::new))
              .maskSymbol(p.getMaskSymbol())
              .leftVisible(p.getLeftVisible())
              .rightVisible(p.getRightVisible())
              .maxBodySize(p.getMaxBodySize())
              .correlationKey(p.getCorrelationKey())
              .requestIdKey(p.getRequestIdKey())
              .includeCallerInfo(p.isIncludeCallerInfo())
              .environment(p.getEnvironment())
              .slowQueryThresholdMs(p.getSlowQueryThresholdMs())
              .defaultSampleRate(p.getDefaultSampleRate())
              .prodMaskOverride(p.isProdMaskOverride())
              .asyncCorePoolSize(p.getAsyncCorePoolSize())
              .asyncMaxPoolSize(p.getAsyncMaxPoolSize())
              .asyncQueueCapacity(p.getAsyncQueueCapacity())
              .mdcFields(p.getMdcFields().toArray(String[]::new));

      if ("TEXT".equalsIgnoreCase(p.getFormat())) b.textFormat();
      else if ("PRETTY".equalsIgnoreCase(p.getFormat())) b.prettyFormat();
      else if ("PRETTY_TEXT".equalsIgnoreCase(p.getFormat())) b.prettyTextFormat();
      else b.jsonFormat();

      // Resolve named mask profiles
      for (String name : p.getMaskProfiles()) {
         MaskProfile profile = PROFILES.get(name.toUpperCase());
         if (profile != null) b.maskProfile(profile);
         else log.warn("Unknown mask profile '{}'. Available: {}", name, PROFILES.keySet());
      }

      CbqLogConfig config = b.build();
      CbqLog.configure(config);

      log.info("CBQ Log configured: service={}, format={}, async={}, env={}, profiles={}, slowQueryMs={}",
              p.getServiceName(), p.getFormat(), p.isAsync(), p.getEnvironment(),
              p.getMaskProfiles(), p.getSlowQueryThresholdMs());
      return config;
   }

}
