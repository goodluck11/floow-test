package com.cbq.log.event;

import com.cbq.log.async.AsyncLogWriter;

import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

/**
 * Non-blocking log event bus. Register listeners for specific patterns.
 *
 * <pre>{@code
 * LogEventBus.on(e -> "error".equals(e.get("type")), e -> slackAlert(e));
 * LogEventBus.on("task_type", "db", e -> e.containsKey("success") && !(boolean) e.get("success"),
 *                e -> pagerDuty(e));
 * LogEventBus.onError(e -> metrics.increment("errors"));
 * }</pre>
 * <p>
 * All listeners execute asynchronously on the shared virtual thread pool.
 */
public final class LogEventBus {

   private static final CopyOnWriteArrayList<Subscription> SUBS = new CopyOnWriteArrayList<>();

   private LogEventBus() {
   }

   /**
    * Register a listener with a predicate filter
    */
   public static Subscription on(Predicate<Map<String, Object>> filter, LogEventListener listener) {
      var s = new Subscription(filter, listener);
      SUBS.add(s);
      return s;
   }

   /**
    * Register for events where field equals value AND predicate passes
    */
   public static Subscription on(String field, Object value, Predicate<Map<String, Object>> extra, LogEventListener listener) {
      return on(e -> value.equals(e.get(field)) && extra.test(e), listener);
   }

   /**
    * Register for all ERROR-level events
    */
   public static Subscription onError(LogEventListener listener) {
      return on(e -> "ERROR".equals(e.get("level")), listener);
   }

   /**
    * Register for slow operations (duration_ms > threshold)
    */
   public static Subscription onSlowOp(long thresholdMs, LogEventListener listener) {
      return on(e -> {
         Object d = e.get("duration_ms");
         return d instanceof Number n && n.longValue() > thresholdMs;
      }, listener);
   }

   /**
    * Fire event to all matching listeners (non-blocking)
    */
   public static void fire(Map<String, Object> event) {
      if (SUBS.isEmpty()) return;
      for (var sub : SUBS) {
         if (!sub.active) continue;
         try {
            if (sub.filter.test(event)) {
               AsyncLogWriter.submit(() -> {
                  try {
                     sub.listener.onEvent(event);
                  } catch (Exception e) { /* swallow — listener must not break logging */ }
               });
            }
         } catch (Exception e) { /* predicate failure — skip */ }
      }
   }

   /**
    * Unsubscribe all
    */
   public static void clear() {
      SUBS.clear();
   }

   public static final class Subscription {
      final Predicate<Map<String, Object>> filter;
      final LogEventListener listener;
      volatile boolean active = true;

      Subscription(Predicate<Map<String, Object>> filter, LogEventListener listener) {
         this.filter = filter;
         this.listener = listener;
      }

      public void cancel() {
         active = false;
         SUBS.remove(this);
      }
   }
}
