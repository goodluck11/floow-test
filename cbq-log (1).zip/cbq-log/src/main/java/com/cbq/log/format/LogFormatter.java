package com.cbq.log.format;

import java.util.Map;

/** Produces the final string written to SLF4J from a structured entry map. */
@FunctionalInterface
public interface LogFormatter {
    String format(Map<String, Object> entry);
}
