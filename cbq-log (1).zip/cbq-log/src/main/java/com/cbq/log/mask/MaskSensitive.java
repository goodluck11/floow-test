package com.cbq.log.mask;

import java.lang.annotation.*;

/**
 * Marks a field for masking when logged via CbqLog or MaskEngine.
 *
 * <p>Usage on POJOs:
 * <pre>{@code
 * public class Payment {
 *     private String orderId;                                        // not masked
 *
 *     @MaskSensitive(visibleChars = 4)
 *     private String cardNumber;                                     // ************4242
 *
 *     @MaskSensitive(fullyMask = true)
 *     private String cvv;                                            // ***
 *
 *     @MaskSensitive(maskSymbol = 'X', visibleChars = 4)
 *     private String accountNumber;                                  // XXXXXXXX1234
 *
 *     @MaskSensitive(exclude = true)
 *     private String internalTraceId;                                // excluded entirely from output
 * }
 * }</pre>
 *
 * <p>Works with:
 * <ul>
 *   <li>{@code MaskEngine.mask(obj)} — returns masked JSON string</li>
 *   <li>{@code MaskEngine.maskToMap(obj)} — returns masked Map&lt;String,Object&gt;</li>
 *   <li>{@code CbqLog.info("payment", payment)} — auto-masks annotated fields</li>
 * </ul>
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface MaskSensitive {

    /** Mask character (default: '*') */
    char maskSymbol() default '*';

    /** Number of trailing visible characters (default: 0 = fully masked) */
    int visibleChars() default 0;

    /** If true, replace entire value regardless of visibleChars (default: false) */
    boolean fullyMask() default false;

    /** If true, exclude this field entirely from masked output (default: false) */
    boolean exclude() default false;
}
