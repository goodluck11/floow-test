package com.cbq.log.mask;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * High-performance masking engine. Caches reflection metadata per class.
 *
 * <p>Three masking approaches:
 * <ol>
 *   <li><b>Annotation-based</b> — reads {@link MaskSensitive} from POJO fields</li>
 *   <li><b>Field-name based</b> — mask by field name set (for JSON strings / Maps)</li>
 *   <li><b>Combined</b> — annotations take precedence, field names as fallback</li>
 * </ol>
 *
 * <pre>{@code
 * // Annotation-based
 * String masked = MaskEngine.mask(payment);              // reads @MaskSensitive on Payment fields
 * Map<String,Object> map = MaskEngine.maskToMap(payment); // same, as Map
 *
 * // Field-name based (for raw JSON)
 * String masked = MaskEngine.maskJson(jsonStr, Set.of("cardNumber", "cvv"), '*');
 *
 * // Combined
 * String masked = MaskEngine.mask(payment, Set.of("extraSecret"), '*');
 * }</pre>
 *
 * Thread-safe. All caches are concurrent.
 */
public final class MaskEngine {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

    // Cache: Class → List<FieldMaskSpec> (computed once per class)
    private static final ConcurrentHashMap<Class<?>, List<FieldMaskSpec>> CACHE = new ConcurrentHashMap<>();

    private MaskEngine() {}

    // ── Annotation-based masking ─────────────────────────────────────────────

    /** Mask annotated fields, return JSON string */
    public static String mask(Object obj) {
        return mask(obj, Set.of(), '*');
    }

    /** Mask annotated fields + extra field names, return JSON string */
    public static String mask(Object obj, Set<String> extraFields, char defaultSymbol) {
        if (obj == null) return "null";
        if (obj instanceof String s) return maskJson(s, extraFields, defaultSymbol);
        Map<String, Object> map = maskToMap(obj, extraFields, defaultSymbol);
        return toJson(map);
    }

    /** Mask annotated fields, return Map */
    public static Map<String, Object> maskToMap(Object obj) {
        return maskToMap(obj, Set.of(), '*');
    }

    /** Mask annotated fields + extra field names, return Map */
    public static Map<String, Object> maskToMap(Object obj, Set<String> extraFields, char defaultSymbol) {
        if (obj == null) return Map.of();
        if (obj instanceof Map<?, ?> raw) return maskMap(raw, extraFields, defaultSymbol);

        List<FieldMaskSpec> specs = getSpecs(obj.getClass());
        var result = new LinkedHashMap<String, Object>();

        for (FieldMaskSpec spec : specs) {
            if (spec.exclude) continue;
            Object val;
            try { val = spec.field.get(obj); } catch (IllegalAccessException e) { continue; }
            if (spec.masked) {
                result.put(spec.name, maskValue(val, spec.symbol, spec.visibleChars, spec.fullyMask));
            } else if (extraFields.contains(spec.name)) {
                result.put(spec.name, maskValue(val, defaultSymbol, 0, true));
            } else {
                result.put(spec.name, val);
            }
        }

        // Fields not in the class (from extraFields) won't appear — that's correct for POJO masking
        return result;
    }

    // ── JSON string masking (field-name based) ───────────────────────────────

    /** Mask fields in a JSON string by field name */
    public static String maskJson(String json, Set<String> fields, char maskSymbol) {
        if (json == null || json.isBlank() || fields.isEmpty()) return json;
        try {
            JsonNode node = MAPPER.readTree(json);
            maskJsonNode(node, fields, maskSymbol);
            return MAPPER.writeValueAsString(node);
        } catch (JsonProcessingException e) {
            return json;
        }
    }

    // ── Header masking ───────────────────────────────────────────────────────

    /** Mask sensitive header values (Authorization always partially masked) */
    public static String maskHeader(String headerName, String headerValue, Set<String> sensitiveHeaders, char symbol) {
        if (headerName == null || headerValue == null) return headerValue;
        if (headerName.equalsIgnoreCase("Authorization")) {
            return headerValue.length() > 10
                    ? headerValue.substring(0, Math.min(7, headerValue.length())) + "..." + rep(symbol, 4)
                    : rep(symbol, headerValue.length());
        }
        for (String s : sensitiveHeaders) {
            if (headerName.equalsIgnoreCase(s)) return rep(symbol, Math.max(headerValue.length(), 4));
        }
        return headerValue;
    }

    // ── Internals ────────────────────────────────────────────────────────────

    private static List<FieldMaskSpec> getSpecs(Class<?> clazz) {
        return CACHE.computeIfAbsent(clazz, MaskEngine::buildSpecs);
    }

    private static List<FieldMaskSpec> buildSpecs(Class<?> clazz) {
        var specs = new ArrayList<FieldMaskSpec>();
        for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                MaskSensitive ann = f.getAnnotation(MaskSensitive.class);
                if (ann != null) {
                    specs.add(new FieldMaskSpec(f, f.getName(), true, ann.maskSymbol(), ann.visibleChars(), ann.fullyMask(), ann.exclude()));
                } else {
                    specs.add(new FieldMaskSpec(f, f.getName(), false, '*', 0, false, false));
                }
            }
        }
        return List.copyOf(specs);
    }

    private record FieldMaskSpec(Field field, String name, boolean masked, char symbol, int visibleChars, boolean fullyMask, boolean exclude) {}

    static Object maskValue(Object val, char symbol, int visibleChars, boolean fullyMask) {
        if (val == null) return null;
        String s = val.toString();
        if (s.isEmpty()) return "";
        if (fullyMask || visibleChars <= 0) return rep(symbol, Math.max(s.length(), 3));
        if (visibleChars >= s.length()) return rep(symbol, 3) + s;
        return rep(symbol, s.length() - visibleChars) + s.substring(s.length() - visibleChars);
    }

    private static Map<String, Object> maskMap(Map<?, ?> raw, Set<String> fields, char symbol) {
        var result = new LinkedHashMap<String, Object>();
        raw.forEach((k, v) -> {
            String key = String.valueOf(k);
            if (fields.contains(key)) result.put(key, maskValue(v, symbol, 0, true));
            else result.put(key, v);
        });
        return result;
    }

    private static void maskJsonNode(JsonNode node, Set<String> fields, char symbol) {
        if (node.isObject()) {
            ObjectNode obj = (ObjectNode) node;
            var it = obj.fields();
            while (it.hasNext()) {
                var e = it.next();
                if (shouldMask(e.getKey(), fields)) {
                    obj.set(e.getKey(), new TextNode(rep(symbol, Math.max(e.getValue().asText("").length(), 3))));
                } else {
                    maskJsonNode(e.getValue(), fields, symbol);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode el : node) maskJsonNode(el, fields, symbol);
        }
    }

    private static boolean shouldMask(String name, Set<String> fields) {
        for (String f : fields) if (name.equalsIgnoreCase(f)) return true;
        return false;
    }

    static String rep(char c, int n) { return String.valueOf(c).repeat(Math.max(n, 1)); }

    static String toJson(Object obj) {
        try { return MAPPER.writeValueAsString(obj); } catch (JsonProcessingException e) { return String.valueOf(obj); }
    }
}
