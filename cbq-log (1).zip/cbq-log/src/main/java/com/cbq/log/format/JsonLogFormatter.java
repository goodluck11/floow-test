package com.cbq.log.format;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.util.Map;

/** Single-line JSON output. Thread-safe, reuses one ObjectMapper. */
public final class JsonLogFormatter implements LogFormatter {
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

    @Override
    public String format(Map<String, Object> entry) {
        try { return MAPPER.writeValueAsString(entry); }
        catch (JsonProcessingException e) { return entry.toString(); }
    }
}
