package com.cbq.log.autoconfigure;

import com.cbq.log.config.CbqLogConfig;
import com.cbq.log.core.CbqLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import jakarta.annotation.PreDestroy;

@AutoConfiguration
@EnableConfigurationProperties(CbqLogProperties.class)
public class CbqLogAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(CbqLogAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public CbqLogConfig cbqLogConfig(CbqLogProperties p) {
        var cfg = CbqLogConfig.builder()
                .serviceName(p.getServiceName())
                .async(p.isAsync())
                .maskFields(p.getMaskFields().toArray(String[]::new))
                .maskSymbol(p.getMaskSymbol())
                .maxBodySize(p.getMaxBodySize())
                .correlationKey(p.getCorrelationKey())
                .requestIdKey(p.getRequestIdKey())
                .includeCallerInfo(p.isIncludeCallerInfo());

        if ("TEXT".equalsIgnoreCase(p.getFormat())) cfg.textFormat(); else cfg.jsonFormat();

        CbqLogConfig config = cfg.build();
        CbqLog.configure(config);
        log.info("CBQ Log configured: service={}, format={}, async={}", p.getServiceName(), p.getFormat(), p.isAsync());
        return config;
    }

    @PreDestroy
    public void shutdown() {
        com.cbq.log.async.AsyncLogWriter.shutdown();
    }
}
