package com.cbq.log.config;

import java.util.*;

/**
 * Configuration for CbqLog. Immutable after build.
 *
 * <pre>{@code
 * CbqLogConfig config = CbqLogConfig.builder()
 *     .serviceName("payment-service")
 *     .jsonFormat()                        // or .textFormat()
 *     .async(true)                         // non-blocking (virtual threads if Java 21+, else cached pool)
 *     .maskFields("cardNumber", "cvv")     // field-name masking for JSON/Map
 *     .maskSymbol('*')
 *     .maxBodySize(4096)
 *     .correlationKey("correlationId")     // MDC key
 *     .requestIdKey("requestId")
 *     .includeCallerInfo(false)            // class/method/line in output
 *     .build();
 * }</pre>
 */
public record CbqLogConfig(
        String serviceName,
        LogFormat format,
        boolean async,
        Set<String> maskFields,
        char maskSymbol,
        int maxBodySize,
        String correlationKey,
        String requestIdKey,
        boolean includeCallerInfo
) {
    public enum LogFormat { TEXT, JSON }

    public static CbqLogConfig defaults() {
        return new CbqLogConfig("app", LogFormat.JSON, true, Set.of(), '*', 4096, "correlationId", "requestId", false);
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private String serviceName = "app";
        private LogFormat format = LogFormat.JSON;
        private boolean async = true;
        private final Set<String> maskFields = new LinkedHashSet<>();
        private char maskSymbol = '*';
        private int maxBodySize = 4096;
        private String correlationKey = "correlationId";
        private String requestIdKey = "requestId";
        private boolean includeCallerInfo = false;

        public Builder serviceName(String v)        { this.serviceName = v; return this; }
        public Builder jsonFormat()                 { this.format = LogFormat.JSON; return this; }
        public Builder textFormat()                 { this.format = LogFormat.TEXT; return this; }
        public Builder async(boolean v)             { this.async = v; return this; }
        public Builder sync()                       { this.async = false; return this; }
        public Builder maskFields(String... f)      { Collections.addAll(maskFields, f); return this; }
        public Builder maskSymbol(char c)           { this.maskSymbol = c; return this; }
        public Builder maxBodySize(int v)           { this.maxBodySize = v; return this; }
        public Builder correlationKey(String v)     { this.correlationKey = v; return this; }
        public Builder requestIdKey(String v)       { this.requestIdKey = v; return this; }
        public Builder includeCallerInfo(boolean v) { this.includeCallerInfo = v; return this; }

        public CbqLogConfig build() {
            return new CbqLogConfig(serviceName, format, async, Set.copyOf(maskFields),
                    maskSymbol, maxBodySize, correlationKey, requestIdKey, includeCallerInfo);
        }
    }
}
