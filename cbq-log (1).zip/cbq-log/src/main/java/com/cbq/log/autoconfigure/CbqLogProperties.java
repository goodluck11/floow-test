package com.cbq.log.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.Set;

@ConfigurationProperties(prefix = "cbq.log")
public class CbqLogProperties {
    private String serviceName = "app";
    private String format = "JSON";
    private boolean async = true;
    private Set<String> maskFields = Set.of();
    private char maskSymbol = '*';
    private int maxBodySize = 4096;
    private String correlationKey = "correlationId";
    private String requestIdKey = "requestId";
    private boolean includeCallerInfo = false;

    public String getServiceName() { return serviceName; } public void setServiceName(String v) { this.serviceName = v; }
    public String getFormat() { return format; } public void setFormat(String v) { this.format = v; }
    public boolean isAsync() { return async; } public void setAsync(boolean v) { this.async = v; }
    public Set<String> getMaskFields() { return maskFields; } public void setMaskFields(Set<String> v) { this.maskFields = v; }
    public char getMaskSymbol() { return maskSymbol; } public void setMaskSymbol(char v) { this.maskSymbol = v; }
    public int getMaxBodySize() { return maxBodySize; } public void setMaxBodySize(int v) { this.maxBodySize = v; }
    public String getCorrelationKey() { return correlationKey; } public void setCorrelationKey(String v) { this.correlationKey = v; }
    public String getRequestIdKey() { return requestIdKey; } public void setRequestIdKey(String v) { this.requestIdKey = v; }
    public boolean isIncludeCallerInfo() { return includeCallerInfo; } public void setIncludeCallerInfo(boolean v) { this.includeCallerInfo = v; }
}
