# CBQ Log

Lightweight structured logging library with annotation-driven field masking, async/sync modes, and Lombok `@CustomLog` integration.

**Java 17+** | **Zero Spring dependency for core** | **Optional Spring Boot auto-config**

---

## Features

- **Structured JSON/text logging** — Splunk/ELK-friendly single-line output
- **`@MaskSensitive` annotation** — field-level masking on POJOs with caching
- **`MaskEngine`** — mask any object, JSON string, or Map programmatically
- **Async (non-blocking)** — virtual threads (Java 21+) or daemon thread pool (Java 17+)
- **Sync mode** — for low-latency scenarios or testing
- **MDC correlation** — `LogContext` for correlation/request ID propagation
- **Lombok `@CustomLog`** — drop-in replacement for `@Slf4j`
- **Task logging** — DB, cache, email, queue operations
- **HTTP logging** — request/response with header masking
- **Default `logback-spring.xml`** — shipped, overridable
- **Spring Boot auto-configuration** — configure via `application.yml`
- **Java config** — fluent builder, no Spring needed

---

## Install

```xml
<dependency>
    <groupId>com.cbq</groupId>
    <artifactId>cbq-log</artifactId>
    <version>1.0.0</version>
</dependency>
```

---

## Quick Start

### 1. Manual Declaration

```java
private static final CbqLog log = CbqLog.getLogger(PaymentService.class);

log.info("order created", order);              // masks @MaskSensitive fields
log.error("payment failed", payment, ex);
log.debug("cache hit", Map.of("key", k));
```

### 2. Lombok `@CustomLog`

Add to your project root `lombok.config`:

```properties
lombok.log.custom.declaration = com.cbq.log.core.CbqLog com.cbq.log.core.CbqLog.getLogger(TYPE)
```

Then:

```java
@CustomLog
public class PaymentService {
    public void charge(Payment payment) {
        log.info("charging customer", payment);  // generates: CbqLog log = CbqLog.getLogger(PaymentService.class)
    }
}
```

---

## `@MaskSensitive` — Annotation-Based Masking

```java
public class Payment {
    private String orderId;                                         // not masked

    @MaskSensitive(visibleChars = 4)
    private String cardNumber;                                      // ************4242

    @MaskSensitive(fullyMask = true)
    private String cvv;                                             // ***

    @MaskSensitive(maskSymbol = 'X', visibleChars = 4)
    private String accountNumber;                                   // XXXXXXXX1234

    @MaskSensitive(exclude = true)
    private String internalTraceId;                                 // excluded from output entirely
}
```

### Usage

```java
// Auto-masked when logged
log.info("payment processed", payment);
// Output: {"message":"payment processed","data":{"orderId":"ORD-123","cardNumber":"************4242","cvv":"***","accountNumber":"XXXXXXXX1234"}}

// Programmatic masking
String json = MaskEngine.mask(payment);                            // JSON string
Map<String, Object> map = MaskEngine.maskToMap(payment);           // Map
String masked = MaskEngine.mask(payment, Set.of("extra"), '*');    // annotations + extra fields
```

### On JSON Strings

```java
String rawJson = """{"cardNumber":"4242424242424242","amount":100}""";
String masked = MaskEngine.maskJson(rawJson, Set.of("cardNumber"), '*');
// {"cardNumber":"****************","amount":100}
```

---

## Configuration

### Java Config (no Spring)

```java
CbqLog.configure(CbqLogConfig.builder()
    .serviceName("payment-service")
    .jsonFormat()                        // or .textFormat()
    .async(true)                         // non-blocking
    .maskFields("cardNumber", "cvv")     // field-name masking for JSON/Map
    .maskSymbol('*')
    .maxBodySize(4096)
    .correlationKey("correlationId")
    .includeCallerInfo(false)
    .build());
```

### Spring Boot (`application.yml`)

```yaml
cbq:
  log:
    service-name: payment-service
    format: JSON                        # JSON or TEXT
    async: true
    mask-fields: cardNumber,cvv,password,token
    mask-symbol: '*'
    max-body-size: 4096
    correlation-key: correlationId
    request-id-key: requestId
    include-caller-info: false
```

---

## Logging Modes

### Async (Default)

All log writes dispatch to a background executor. On Java 21+ this uses virtual threads; on Java 17+ a cached daemon thread pool.

MDC context is snapshotted before dispatch, so correlation IDs propagate correctly.

```java
CbqLogConfig.builder().async(true).build();  // default
```

### Sync

Writes directly on the calling thread. Useful for testing or latency-critical paths where you need guaranteed ordering.

```java
CbqLogConfig.builder().sync().build();
```

---

## Task Logging

```java
log.task("db", "insert", "orders", 45, true);
log.task("cache", "get", "user:123", 2, true);
log.task("email", "send", "user@ex.com", 150, false, "SMTP timeout");
log.task("queue", "publish", "order-events", 8, true);
```

Output (JSON):
```json
{"timestamp":"...","service":"payment-service","type":"task","task_type":"db","operation":"insert","target":"orders","duration_ms":45,"success":true}
```

---

## HTTP Logging

```java
log.httpRequest("POST", "/v1/charges", headers, requestBody);
log.httpResponse("POST", "/v1/charges", 201, 245, responseBody);
log.httpError("POST", "/v1/charges", 500, exception);
```

Output:
```json
{"timestamp":"...","service":"payment-service","type":"http_request","method":"POST","uri":"/v1/charges","headers":{"Authorization":"Bearer ...****"},"body":{"amount":2000,"cardNumber":"************4242"}}
{"timestamp":"...","service":"payment-service","type":"http_response","method":"POST","uri":"/v1/charges","status":201,"duration_ms":245}
```

---

## Structured Key-Value Logging

```java
log.info("metrics", "cpu", 0.85, "memory", 0.72, "requests", 1500);
// {"timestamp":"...","service":"app","message":"metrics","cpu":0.85,"memory":0.72,"requests":1500}
```

---

## Correlation Context

```java
LogContext.setCorrelationId("corr_abc123");
LogContext.newRequestId();                    // auto-generates "req_..."
String corrId = LogContext.getOrCreateCorrelationId();

// Scoped
LogContext.withCorrelation("corr_new", () -> {
    log.info("inside scoped correlation");   // correlation_id: corr_new
});
// previous correlation ID restored
```

---

## Logback Configuration

CBQ Log ships a default `logback-spring.xml` with:

| Profile | Appenders |
|---------|-----------|
| `default`, `dev` | Console (human-readable) |
| `staging`, `prod` | Async Console (JSON) + Async Rolling File |

**To override:** Create your own `logback-spring.xml` in your application's `src/main/resources/`. You can include CBQ defaults:

```xml
<configuration>
    <include resource="com/cbq/log/cbq-logback-defaults.xml"/>

    <!-- Your custom appenders here -->
    <root level="INFO">
        <appender-ref ref="CBQ_JSON_CONSOLE"/>
        <appender-ref ref="CBQ_ASYNC_FILE"/>
    </root>
</configuration>
```

Available appenders from `cbq-logback-defaults.xml`:

| Appender | Description |
|----------|-------------|
| `CBQ_CONSOLE` | Standard console with timestamp pattern |
| `CBQ_JSON_CONSOLE` | Raw message only (for structured JSON) |
| `CBQ_FILE` | Rolling file (50MB, 30 days, 1GB cap) |
| `CBQ_ASYNC_CONSOLE` | Non-blocking wrapper around JSON console |
| `CBQ_ASYNC_FILE` | Non-blocking wrapper around file |

---

## Architecture

```
CbqLog (per-class, cached)
├── CbqLogConfig (immutable, fluent builder)
├── LogFormatter (JSON / TEXT)
├── MaskEngine
│   ├── @MaskSensitive (annotation, cached reflection)
│   ├── Field-name masking (JSON strings, Maps)
│   └── Header masking (Authorization auto-detected)
├── AsyncLogWriter (virtual threads / daemon pool)
├── LogContext (MDC-based correlation)
└── SLF4J Logger (delegate)
```

**Zero allocations on disabled levels** — all methods check `isXxxEnabled()` before building entries.

**Cached reflection** — `MaskEngine` scans `@MaskSensitive` annotations once per class, stores in `ConcurrentHashMap`.

**MDC snapshot** — async mode copies MDC before dispatch to ensure correct correlation IDs.
