package com.ready.interview.loadtest;

import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.sql.DataSource;
import java.lang.management.ManagementFactory;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class LoadSimulationTest {

   @LocalServerPort
   private int port;

   @Autowired
   private DataSource dataSource;

   @Autowired
   private JdbcTemplate jdbcTemplate;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private MockMvc mockMvc;

   private static final int TOTAL_REQUESTS = 10000;
   private static final int CONCURRENT_USERS = 1000; // Simulating high concurrency

   @Test
   void simulate500RpsLoad() {
      // Setup for 100 RPS per instance (1 instance for this local test)
      // Change these parameters to test different scenarios
      int targetRps = 50;
      int durationSeconds = 10;
      int apiCalls = 1; // Simulated 20ms sequential API calls
      int dbCalls = 1;  // Simulated database operations
      
      simulateFlexibleLoad(targetRps, durationSeconds, apiCalls, dbCalls);
   }

   private void simulateFlexibleLoad(int targetRps, int durationSeconds, int apiCalls, int dbCalls) {
      String url = String.format("http://localhost:%d/api/flexible?apiCalls=%d&dbCalls=%d", port, apiCalls, dbCalls);
      int totalRequests = targetRps * durationSeconds;

      try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
         HttpClient client = HttpClient.newBuilder()
                 .executor(executor)
                 .connectTimeout(Duration.ofSeconds(10))
                 .build();

         AtomicInteger successCount = new AtomicInteger(0);
         AtomicInteger failureCount = new AtomicInteger(0);
         List<Long> responseTimes = new ArrayList<>();

         System.out.println(String.format("[DEBUG_LOG] Starting Load Test: %d RPS for %ds (%d API, %d DB calls)", 
                 targetRps, durationSeconds, apiCalls, dbCalls));
         Instant start = Instant.now();

         for (int i = 0; i < totalRequests; i++) {
            long delayMicros = (i * 1_000_000L) / targetRps;
            long currentMicros = Duration.between(start, Instant.now()).toNanos() / 1000;
            if (delayMicros > currentMicros) {
               TimeUnit.MICROSECONDS.sleep(delayMicros - currentMicros);
            }

            executor.submit(() -> {
               long reqStart = System.currentTimeMillis();
               try {
                  HttpRequest request = HttpRequest.newBuilder()
                          .uri(URI.create(url))
                          .GET()
                          .build();

                  HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                  long reqEnd = System.currentTimeMillis();

                  if (response.statusCode() == 200) {
                     successCount.incrementAndGet();
                     long duration = reqEnd - reqStart;
                     synchronized (responseTimes) {
                        responseTimes.add(duration);
                     }
                  } else {
                     failureCount.incrementAndGet();
                  }
               } catch (Exception e) {
                  failureCount.incrementAndGet();
               }
            });
         }

         executor.shutdown();
         executor.awaitTermination(30 + durationSeconds, TimeUnit.SECONDS);

         Instant end = Instant.now();
         long totalDurationMs = Duration.between(start, end).toMillis();

         System.out.println("LOAD_TEST_RESULT_START");
         System.out.println("Config: " + targetRps + " RPS, " + apiCalls + " API calls, " + dbCalls + " DB calls");
         System.out.println("Total Target Requests: " + totalRequests);
         System.out.println("Success: " + successCount.get());
         System.out.println("Failures: " + failureCount.get());
         System.out.println("Actual Time: " + totalDurationMs + " ms");
         System.out.println("Actual RPS: " + (successCount.get() + failureCount.get()) * 1000.0 / totalDurationMs);
         System.out.println("Throughput (Success): " + (successCount.get() * 1000.0 / totalDurationMs) + " req/s");

         if (successCount.get() > 0) {
            synchronized (responseTimes) {
               responseTimes.sort(Long::compare);
               double avg = responseTimes.stream().mapToLong(Long::longValue).average().orElse(0);
               long p50 = responseTimes.get((int) (responseTimes.size() * 0.50));
               long p95 = responseTimes.get((int) (responseTimes.size() * 0.95));
               long p99 = responseTimes.get((int) (responseTimes.size() * 0.99));
               System.out.println("Average Latency: " + String.format("%.2f", avg) + " ms");
               System.out.println("P50 Latency: " + p50 + " ms");
               System.out.println("P95 Latency: " + p95 + " ms");
               System.out.println("P99 Latency: " + p99 + " ms");
            }
         }
         
         // Print Pool Metrics if Hikari
         if (dataSource instanceof HikariDataSource hds) {
            var pool = hds.getHikariPoolMXBean();
            System.out.println("Hikari Pool: Active=" + pool.getActiveConnections() + 
                    ", Idle=" + pool.getIdleConnections() + 
                    ", Total=" + pool.getTotalConnections() + 
                    ", ThreadsAwaiting=" + pool.getThreadsAwaitingConnection());
         }

         System.out.println("LOAD_TEST_RESULT_END");
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
      }
   }

   @Test
   void simulateLoad() {
      String url = "http://localhost:" + port + "/posts";

      // Use Virtual Threads to simulate 10,000 requests efficiently
      try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
         HttpClient client = HttpClient.newBuilder()
                 .executor(executor)
                 .connectTimeout(Duration.ofSeconds(10))
                 .build();

         AtomicInteger successCount = new AtomicInteger(0);
         AtomicInteger failureCount = new AtomicInteger(0);
         AtomicLong totalResponseTime = new AtomicLong(0);
         List<Long> responseTimes = new ArrayList<>();

         System.out.println("[DEBUG_LOG] Starting load test: " + TOTAL_REQUESTS + " requests to " + url);
         Instant start = Instant.now();

         List<CompletableFuture<Void>> futures = new ArrayList<>();

         for (int i = 0; i < TOTAL_REQUESTS; i++) {
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
               long reqStart = System.currentTimeMillis();
               try {
                  HttpRequest request = HttpRequest.newBuilder()
                          .uri(URI.create(url))
                          .GET()
                          .build();

                  HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                  long reqEnd = System.currentTimeMillis();

                  if (response.statusCode() == 200) {
                     successCount.incrementAndGet();
                     long duration = reqEnd - reqStart;
                     totalResponseTime.addAndGet(duration);
                     synchronized (responseTimes) {
                        responseTimes.add(duration);
                     }
                  } else {
                     failureCount.incrementAndGet();
                  }
               } catch (Exception e) {
                  failureCount.incrementAndGet();
               }
            }, executor);
            futures.add(future);
         }

         CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

         Instant end = Instant.now();
         long totalDurationMs = Duration.between(start, end).toMillis();

         System.out.println("RESULT_START");
         System.out.println("Total Requests: " + TOTAL_REQUESTS);
         System.out.println("Success: " + successCount.get());
         System.out.println("Failures: " + failureCount.get());
         System.out.println("Total Time: " + totalDurationMs + " ms");
         System.out.println("Throughput: " + (successCount.get() * 1000.0 / totalDurationMs) + " req/s");

         if (successCount.get() > 0) {
            System.out.println("Average Latency: " + (totalResponseTime.get() / (double) successCount.get()) + " ms");

            responseTimes.sort(Long::compare);
            long p95 = responseTimes.get((int) (responseTimes.size() * 0.95));
            long p99 = responseTimes.get((int) (responseTimes.size() * 0.99));
            System.out.println("P95 Latency: " + p95 + " ms");
            System.out.println("P99 Latency: " + p99 + " ms");
         }
         System.out.println("RESULT_END");
      }
   }

   private void simulateRealisticBankingLoad() {
      // Deprecated or keep as legacy
      simulateFlexibleLoad(1000, 10, 5, 3);
   }

   @Test
   void testConnectionPoolSize() {
      HikariDataSource hikariDataSource = (HikariDataSource) dataSource;

      // Get pool metrics
      HikariPoolMXBean poolMXBean = hikariDataSource.getHikariPoolMXBean();

      // Execute multiple queries to force connections to be used
      for (int i = 0; i < 20; i++) {
         jdbcTemplate.queryForObject("SELECT 1", Integer.class);
      }

      // Verify pool stats
      int activeConnections = poolMXBean.getActiveConnections();
      int idleConnections = poolMXBean.getIdleConnections();
      int totalConnections = poolMXBean.getTotalConnections();

      System.out.println(String.format("Active: %d, Idle: %d, Total: %d",
              activeConnections, idleConnections, totalConnections));

      // Assert pool behavior
      assertThat(totalConnections).isLessThanOrEqualTo(50);
      assertThat(idleConnections).isGreaterThanOrEqualTo(0);
   }

   @Test
   public void testConnectionTimeout() {
      List<Connection> connections = new ArrayList<>();
      try {
         // Exceed the pool size (50) to trigger timeout
         for (int i = 0; i < 50; i++) {
            connections.add(dataSource.getConnection());
         }

         long startTime = System.currentTimeMillis();
         assertThatThrownBy(() -> {
            dataSource.getConnection();
         }).isInstanceOf(SQLException.class);

         long duration = System.currentTimeMillis() - startTime;
         // connection-timeout is 5000ms
         assertThat(duration).isGreaterThanOrEqualTo(4500);
         assertThat(duration).isLessThan(7000);
      } catch (SQLException e) {
         fail("Should not have failed while filling the pool: " + e.getMessage());
      } finally {
         connections.forEach(c -> {
            try {
               c.close();
            } catch (SQLException ignored) {
            }
         });
      }
   }

   @Test
   public void testLeakDetection() throws Exception {
      // leak-detection-threshold is 2000ms in application.properties
      // We'll use MBean to check if leak detection is working if possible,
      // but the most realistic is to check logs.
      // For this test, we just ensure it doesn't crash the app.
      Connection conn = dataSource.getConnection();
      try {
         assertThat(conn).isNotNull();
         // We don't close it immediately
         Thread.sleep(2500);
      } finally {
         conn.close();
      }
   }

   @Test
   public void testProperConnectionHandling() {
      // This should NOT trigger leak detection
      try (Connection conn = dataSource.getConnection()) {
         // Use connection
         PreparedStatement stmt = conn.prepareStatement("SELECT 1");
         stmt.execute();
      } catch (SQLException e) {
         fail("Should not throw exception");
      }
   }

    @Test
    public void testTomcatThreadPoolConfig() {
        try {
            MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
            // Try different domains/patterns for Tomcat
            var objectNames = mBeanServer.queryNames(new ObjectName("*:type=ThreadPool,*"), null);
            if (objectNames.isEmpty()) {
                objectNames = mBeanServer.queryNames(null, null);
                System.out.println("[DEBUG_LOG] All MBeans: " + objectNames.stream()
                        .map(ObjectName::getCanonicalName)
                        .filter(name -> name.contains("ThreadPool"))
                        .collect(Collectors.toList()));
            }
            
            System.out.println("[DEBUG_LOG] Found ThreadPool MBeans: " + objectNames);
            
            // If we still can't find it, it might be because Tomcat hasn't started its connector yet
            // even with RANDOM_PORT. But usually it should be there.
            
            if (objectNames.isEmpty()) {
                System.out.println("[DEBUG_LOG] No ThreadPool MBean found. Skipping MBean validation.");
                return;
            }

            ObjectName threadPoolName = objectNames.stream()
                    .filter(n -> n.getCanonicalName().contains("ThreadPool"))
                    .findFirst()
                    .orElse(null);
            
            if (threadPoolName == null) {
                System.out.println("[DEBUG_LOG] No ThreadPool MBean found in results. Skipping.");
                return;
            }

            System.out.println("[DEBUG_LOG] Using MBean: " + threadPoolName);

            Integer maxThreads = (Integer) mBeanServer.getAttribute(threadPoolName, "maxThreads");
            Integer minSpareThreads = (Integer) mBeanServer.getAttribute(threadPoolName, "minSpareThreads");

            System.out.println("[DEBUG_LOG] maxThreads: " + maxThreads + ", minSpareThreads: " + minSpareThreads);

            assertThat(maxThreads).isEqualTo(500);
            assertThat(minSpareThreads).isEqualTo(50);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Could not access Tomcat MBean: " + e.getMessage());
        }
    }

    @Test
    public void testTomcatConnectionTimeout() throws Exception {
        // Test our new slow endpoint
        mockMvc.perform(get("/api/slow").param("delay", "100"))
                .andExpect(status().isOk());
    }

    @Test
    public void testConcurrentRequests() throws InterruptedException {
        int threadCount = 100;
        ExecutorService executorService = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger failureCount = new AtomicInteger(0);

        for (int i = 0; i < threadCount; i++) {
            executorService.submit(() -> {
                try {
                    ResponseEntity<String> response = restTemplate.getForEntity("/api/test", String.class);
                    if (response.getStatusCode() == HttpStatus.OK) {
                        successCount.incrementAndGet();
                    } else {
                        failureCount.incrementAndGet();
                    }
                } catch (Exception e) {
                    failureCount.incrementAndGet();
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(30, TimeUnit.SECONDS);

        System.out.println(String.format("Success: %d, Failed: %d",
                successCount.get(), failureCount.get()));

        assertThat(successCount.get()).isGreaterThan(0);
    }

    @Test
    public void testMultipleDatabaseCalls() {
        List<CompletableFuture<Integer>> futures = new ArrayList<>();

        // Simulate 100 concurrent database calls
        for (int i = 0; i < 100; i++) {
            CompletableFuture<Integer> future = CompletableFuture.supplyAsync(() -> {
                return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM posts", Integer.class);
            });
            futures.add(future);
        }

        // Wait for all to complete
        List<Integer> results = futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());

        assertThat(results).hasSize(100);
        assertThat(results.get(0)).isGreaterThan(0);
    }

   private void exhaustConnectionPool() throws SQLException {
      List<Connection> connections = new ArrayList<>();
      try {
         for (int i = 0; i < 60; i++) { // Try to get more than pool size
            connections.add(dataSource.getConnection());
         }
      } finally {
         // Clean up
         for (Connection conn : connections) {
            try {
               conn.close();
            } catch (SQLException e) {
            }
         }
      }
   }
}
