package com.ready.interview.controller;

/*
 * @created by 30/08/2024  - 15:52
 * @project interview
 * @author Goodluck
 */

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoWebController {

   @GetMapping()
   public String hello() {
      return "Hello World";
   }
}
