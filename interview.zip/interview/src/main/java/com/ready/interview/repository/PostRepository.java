package com.ready.interview.repository;

import com.ready.interview.model.Page;
import com.ready.interview.model.Post;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/*
 * @created by 13/02/2026 - 18:46
 * @project interview
 * @author Goodluck
 */
@Repository
@RequiredArgsConstructor
@CustomLog
public class PostRepository {
   private final JdbcClient jdbcClient;

   public List<Post> findAll() {
      return jdbcClient
              .sql("SELECT * FROM posts LIMIT 10")
              .query(this::mapRowToPost)
              .list();
   }

   public Page<Post> getPosts(int size, Long cursor) {
      var limit = size > 0 ? size : 10;
      var fetchLimit = limit + 1;
      var hasCursor = cursor != null && cursor > 0;
      var query = hasCursor
              ? "SELECT * FROM posts WHERE id > :cursor ORDER BY id ASC LIMIT :limit"
              : "SELECT * FROM posts ORDER BY id LIMIT :limit";

      var spec = jdbcClient.sql(query).param("limit", fetchLimit);
      if (hasCursor) spec = spec.param("cursor", cursor);

      var posts = spec.query(this::mapRowToPost).list();

      var hasMore = posts.size() > limit;
      var pageItems = hasMore ? posts.subList(0, limit) : posts;
      var nextCursor = pageItems.isEmpty() ? null : pageItems.get(pageItems.size() - 1).id();
      return new Page<>(nextCursor, hasMore, pageItems);
   }

   public long count() {
      return Optional.of(
              jdbcClient.sql("SELECT COUNT(*) FROM posts")
                      .query(Long.class)
                      .single()
      ).orElse(0L);
   }

   public long deleteAll() {
      return jdbcClient.sql("DELETE FROM posts")
              .update();
   }

   private Post mapRowToPost(ResultSet rs, int rowNum) throws SQLException {
      return new Post(
              rs.getLong("id"),
              rs.getLong("user_id"),
              rs.getString("title"),
              rs.getString("body")
      );
   }
}
