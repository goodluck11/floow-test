package com.ready.interview.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * @created by 09/10/2025  - 07:23
 * @project interview
 * @author Goodluck
 */

@NoArgsConstructor
@Data
public class Employee {
   @NotBlank(groups = {BasicInfo.class, FullInfo.class})
   private String firstName;

   @NotBlank(groups = {BasicInfo.class, FullInfo.class})
   private String lastName;

   @NotBlank(groups = {ContactInfo.class, FullInfo.class})
   @Email(groups = {ContactInfo.class, FullInfo.class})
   private String email;

   @NotBlank(groups = {ContactInfo.class, FullInfo.class})
   private String mobile;

   @NotBlank(groups = {FullInfo.class})
   private String employer;

   @NotBlank(groups = {FullInfo.class})
   private String address;

   public interface BasicInfo {
   }

   public interface ContactInfo {
   }

   public interface FullInfo {
   }

   public enum ValidationScenario {
      REGISTRATION, PROFILE_UPDATE, EMPLOYMENT_INFO
   }
}

