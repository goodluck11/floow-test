package com.ready.interview.controller;

import com.cbq.log.core.CbqLog;
import com.cbq.log.timed.TimedOp;
import com.ready.interview.model.Page;
import com.ready.interview.model.Post;
import com.ready.interview.model.UserPayload;
import com.ready.interview.service.PostService;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/*
 * @created by 13/02/2026 - 18:55
 * @project interview
 * @author Goodluck
 */
@RestController
@RequestMapping("/")
@RequiredArgsConstructor
//@CustomLog
public class PostController {
   private static final CbqLog log = CbqLog.getLogger(PostController.class);
   private final PostService postService;

   @PostConstruct
   public void init() {
      log.info("PostController initialized {}", System.getProperty("java.version"));
   }

   @GetMapping("/user")
   public UserPayload user() {
      var user = new UserPayload();
      user.setUserId("usr_99210");
      user.setFullName("Marcus Aurelius");
      user.setUsername("marcus_gladiator");
      user.setPassword("hashed_password_8821x");
      user.setAccountNumber("8822991023");
      user.setIban("GB29NWBK60161331926819");
      user.setCardNumber("4532-1190-8842-1002");
      user.setCvv("442");
      user.setExpiryDate("12/27");
      user.setStatus("active");
      user.setIsLocked(false);
      user.setAge(30);

      var data = TimedOp.call(log, "db", "getUser", "users", () -> {
         Thread.sleep(100);
         return user;
      });
      log.info("User data fetched successfully", user);
      return data;
   }

   @GetMapping("/posts")
   public Page<Post> getPosts(@RequestParam(required = false) Long cursor,
                              @RequestParam(defaultValue = "10") int limit) {
      log.infoKv("Fetched Posts", "cursor", cursor, "limit", limit);
      return postService.findAll(limit, cursor);
   }

   @GetMapping("/message")
   public String message() {
      return TimedOp.call(log, "db", "findById", "users", () -> "Hello World");
   }

   @GetMapping("/posts/all")
   public List<Post> findAll() {
      return postService.findAll();
   }

   @GetMapping("/api/test")
   public String test() {
      return "OK";
   }

   @GetMapping("/api/slow")
   public String slow(@RequestParam(defaultValue = "1000") long delay) throws InterruptedException {
      Thread.sleep(delay);
      return "Slow response after " + delay + "ms";
   }

   @GetMapping("/api/flexible")
   public String flexible(@RequestParam(defaultValue = "0") int apiCalls,
                          @RequestParam(defaultValue = "0") int dbCalls) throws InterruptedException {
      // API calls simulation
      for (int i = 0; i < apiCalls; i++) {
         Thread.sleep(20);
      }
      
      // DB calls simulation
      for (int i = 0; i < dbCalls; i++) {
         postService.executeSimpleQuery();
      }
      
      return "Executed " + apiCalls + " API and " + dbCalls + " DB calls";
   }

   @DeleteMapping("/posts/delete-all")
   public Long deleteAll() {
      return postService.deleteAll();
   }
}
