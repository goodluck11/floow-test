package com.ready.interview.service;

import com.ready.interview.model.Page;
import com.ready.interview.model.Post;
import com.ready.interview.repository.PostRepository;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/*
 * @created by 13/02/2026 - 18:44
 * @project interview
 * @author Goodluck
 */
@Service
@RequiredArgsConstructor
@CustomLog
public class PostService {
   private final PostRepository postRepository;

   public List<Post> findAll() {
      return postRepository.findAll();
   }

   public Page<Post> findAll(int limit, Long cursor) {
      return postRepository.getPosts(limit, cursor);
   }

   public Long deleteAll() {
      return postRepository.deleteAll();
   }

   public void executeSimpleQuery() {
      postRepository.count();
   }

   public String processBankingTransaction() {
      // Simulate 3 DB calls in one transaction context (implicitly handled by SimpleJdbcClient here)
      // 1. Check account
      postRepository.findAll(); 
      // 2. Fetch recent transactions
      postRepository.getPosts(5, null);
      // 3. Update the audit log (simulated by another select for this test)
      postRepository.count();
      
      return "Transaction Processed";
   }
}
