package com.ready.interview;

import lombok.CustomLog;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;
import java.util.Stack;

@SpringBootApplication
@CustomLog
public class InterviewApplication implements CommandLineRunner {

   public static void main(String[] args) {
      SpringApplication.run(InterviewApplication.class, args);
   }

   public static String reverseString(String str) {
      StringBuilder reverse = new StringBuilder();
      for (int i = str.length() - 1; i >= 0; i--) {
         reverse.append(str.charAt(i));
      }
      return reverse.toString();
   }

   public static boolean isPalindrome(String str) {
      String reverse = reverseString(str);
      return str.contentEquals(reverse);
   }

   public static int factorial(int n) {
      if (n == 0 || n == 1) {
         return 1;
      }
      return n * factorial(n - 1);
   }

   public static void shiftArrayRight(int[] arr) {
      if (arr == null || arr.length == 0) {
         return;
      }

      int lastElement = arr[arr.length - 1];

      for (int i = arr.length - 1; i > 0; i--) {
         arr[i] = arr[i - 1];
      }

      arr[0] = lastElement;
   }

   public static boolean isBalanced(String expression) {
      Stack<Character> stack = new Stack<>();

      for (char c : expression.toCharArray()) {
         // Push opening brackets onto the stack
         if (c == '(' || c == '{' || c == '[') {
            stack.push(c);
         }
         // Check if closing bracket matches the top of the stack
         else if (c == ')' || c == '}' || c == ']') {
            if (stack.isEmpty()) {
               return false; // No corresponding opening bracket
            }

            char top = stack.pop();
            if (!isMatchingPair(top, c)) {
               return false; // Mismatched pair
            }
         }
      }

      // If stack is empty, all opening brackets had a matching closing bracket
      return stack.isEmpty();
   }

   private static boolean isMatchingPair(char opening, char closing) {
      return (opening == '(' && closing == ')') ||
              (opening == '{' && closing == '}') ||
              (opening == '[' && closing == ']');
   }

   public static boolean isBalancedBracket(String expression) {
      HashMap<Character, Integer> bracketCount = new HashMap<>();
      bracketCount.put('(', 0);
      bracketCount.put(')', 0);
      bracketCount.put('{', 0);
      bracketCount.put('}', 0);
      bracketCount.put('[', 0);
      bracketCount.put(']', 0);

      for (char c : expression.toCharArray()) {
         if (bracketCount.containsKey(c)) {
            bracketCount.put(c, bracketCount.get(c) + 1);
         }
      }

      // Check if all opening and closing brackets have the same count
      return bracketCount.get('(').equals(bracketCount.get(')')) &&
              bracketCount.get('{').equals(bracketCount.get('}')) &&
              bracketCount.get('[').equals(bracketCount.get(']'));
   }

   @Override
   public void run(String... args) {
      /*String word = "madam";
      System.out.println("Is " + word + " a palindrome? " + isPalindrome(word));

      int number = 5;
      System.out.println("Factorial of " + number + " is " + factorial(number));

      int[] array = {1, 2, 3, 4, 5};
      shiftArrayRight(array);

      System.out.println("Shifted array: ");
      for (int num : array) {
         System.out.print(num + " ");
      }
      System.out.println("\n==============");
      String expression1 = "{[()()]}";
      String expression2 = "[(])";
      String expression3 = "{[()]}}";

      System.out.println(expression1 + " is balanced: " + isBalanced(expression1));
      System.out.println(expression2 + " is balanced: " + isBalanced(expression2));
      System.out.println(expression3 + " is balanced: " + isBalanced(expression3));
      System.out.println(expression1 + " is balanced: " + isBalancedBracket(expression1));*/
   }
}
