package com.ready.interview.controller;

/*
 * @created by 09/10/2025  - 07:26
 * @project interview
 * @author Goodluck
 */

import com.ready.interview.model.Employee;
import com.ready.interview.service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/employees")
public class EmployeeController {

   private final EmployeeService employeeService;

   EmployeeController(EmployeeService employeeService) {
      this.employeeService = employeeService;
   }

   @PostMapping
   public ResponseEntity<Void> createEmployee(@RequestBody Employee employee) {
      employeeService.create(employee);
      return ResponseEntity.ok().build();
   }
}
