package com.ready.interview.exception;

/*
 * @created by 09/10/2025  - 07:55
 * @project interview
 * @author Goodluck
 */

import jakarta.validation.ConstraintViolation;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

   @ExceptionHandler(DataValidationException.class)
   public ResponseEntity<Map<String, Object>> handleDataValidationException(DataValidationException ex) {
      Set<? extends ConstraintViolation<?>> violations = ex.getViolations();

      Map<String, String> errors = violations.stream()
              .collect(Collectors.toMap(
                      v -> v.getPropertyPath().toString(),
                      ConstraintViolation::getMessage,
                      (a, b) -> a
              ));

      Map<String, Object> body = Map.of(
              "error", "Validation Failed",
              "message", ex.getMessage(),
              "details", errors
      );

      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
   }

   @ExceptionHandler(Exception.class)
   public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
      Map<String, Object> body = Map.of(
              "error", "Internal Server Error",
              "message", ex.getMessage()
      );
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
   }
}

