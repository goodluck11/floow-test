package com.ready.interview.model;

import com.cbq.log.mask.MaskSensitive;
import lombok.Data;

@Data
public class UserPayload {
   private String userId;
   private String fullName;
   private String username;

   @MaskSensitive(rightVisible = 5)
   private String password;

   @MaskSensitive(leftVisible = 2, rightVisible = 2)
   private String accountNumber;

   @MaskSensitive(leftVisible = 4, rightVisible = 4)
   private String iban;

   @MaskSensitive(leftVisible = 4, rightVisible = 4)
   private String cardNumber;

   @MaskSensitive
   private String cvv;

   private String expiryDate;
   private String status;
   private Boolean isLocked;
   private Integer age;
}
