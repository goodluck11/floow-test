package com.ready.interview.model;

import java.util.List;

/*
 * @created by 13/02/2026 - 18:51
 * @project interview
 * @author Goodluck
 */
public record Page<T>(
        Long nextCursor,
        Boolean hasNext,
        List<T> items
) {
}
