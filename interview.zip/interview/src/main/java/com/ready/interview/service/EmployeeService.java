package com.ready.interview.service;

/*
 * @created by 09/10/2025  - 07:27
 * @project interview
 * @author Goodluck
 *
 */

import com.ready.interview.exception.DataValidationException;
import com.ready.interview.model.Employee;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class EmployeeService {
   private final Validator validator;

   public EmployeeService(Validator validator) {
      this.validator = validator;
   }

   public void create(Employee employee) {
      customValidation(employee, Employee.ValidationScenario.REGISTRATION);
   }

   public void customValidation(Employee employee, Employee.ValidationScenario scenario) {
      Set<ConstraintViolation<Employee>> violations = switch (scenario) {
         case REGISTRATION -> validateProperties(employee,
                 new Class[]{Employee.BasicInfo.class, Employee.ContactInfo.class},
                 "firstName", "lastName", "email"
         );
         case PROFILE_UPDATE -> validator.validate(employee, Employee.ContactInfo.class);
         case EMPLOYMENT_INFO ->
                 validateProperties(employee, new Class[]{Employee.FullInfo.class}, "employer", "address");
      };

      if (!violations.isEmpty()) {
         throw new DataValidationException("Custom validation failed", violations);
      }
   }

   private <T> Set<ConstraintViolation<T>> validateProperties(T entity, Class<?>[] groups, String... props) {
      Set<ConstraintViolation<T>> violations = new HashSet<>();
      for (String prop : props) {
         violations.addAll(validator.validateProperty(entity, prop, groups));
      }
      return violations;
   }
}
