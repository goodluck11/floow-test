package com.ready.interview.exception;

/*
 * @created by 09/10/2025  - 07:36
 * @project interview
 * @author Goodluck
 */

import jakarta.validation.ConstraintViolation;

import java.util.Set;
import java.util.stream.Collectors;

public class DataValidationException extends RuntimeException {
   private final Set<? extends ConstraintViolation<?>> violations;

   public DataValidationException(String message, Set<? extends ConstraintViolation<?>> violations) {
      super(message + ": " + formatViolations(violations));
      this.violations = violations;
   }

   private static String formatViolations(Set<? extends ConstraintViolation<?>> violations) {
      return violations.stream()
              .map(v -> v.getPropertyPath() + " " + v.getMessage())
              .collect(Collectors.joining(", "));
   }

   public Set<? extends ConstraintViolation<?>> getViolations() {
      return violations;
   }
}