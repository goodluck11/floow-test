package com.ready.interview.config;

import com.cbq.log.db.DbLogProxyDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.simple.JdbcClient;

import javax.sql.DataSource;

/*
 * @created by 13/02/2026 - 18:45
 * @project interview
 * @author Goodluck
 */
@Configuration
public class DbConfig {
   @Bean
   public JdbcClient jdbcClient(DataSource dataSource) {
      return JdbcClient.create(DbLogProxyDataSource.wrap(dataSource, true));
   }
}
