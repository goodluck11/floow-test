package com.ready.interview.model;

/*
 * @created by 13/02/2026 - 18:43
 * @project interview
 * @author Goodluck
 */
public record Post(Long id, Long userId, String title, String body) {
}

