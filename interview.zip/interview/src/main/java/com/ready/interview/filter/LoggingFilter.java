package com.ready.interview.filter;

import com.cbq.log.context.LogContext;
import com.cbq.log.gateway.GatewayContext;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.CustomLog;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.UUID;

/*
 * @created by 13/02/2026 - 19:01
 * @project interview
 * @author Goodluck
 */
@Component
@CustomLog
public class LoggingFilter implements Filter {

   @Override
   public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
           throws IOException, ServletException {
      long start = System.nanoTime();

      var http = (HttpServletRequest) req;
      var response = (HttpServletResponse) res;

      var path = http.getRequestURI();
      var method = http.getMethod();

      var corrId = http.getHeader("X-Correlation-ID");
      if (corrId == null) corrId = UUID.randomUUID().toString();

      LogContext.setCorrelationId(corrId);
      LogContext.newRequestId();
      GatewayContext.extract(http::getHeader);

      try {
         chain.doFilter(req, res);
         long ms = (System.nanoTime() - start) / 1_000_000;
         log.info("Request {} finished in {}ms", path, ms);
      } catch (Exception ex) {
         long ms = (System.nanoTime() - start) / 1_000_000;
         log.error("Request {} failed after {}ms", path, ms, ex);
         throw ex;
      } finally {
         GatewayContext.clear();
         LogContext.clearAll();
      }
   }
}
