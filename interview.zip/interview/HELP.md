To handle 50,000 users across 5 instances (10,000 users per instance), the default Spring Boot settings are insufficient. You are moving into a high-concurrency territory where **blocking I/O** (the default Tomcat model) requires careful thread management, and the **database pool** requires a "fail-fast" strategy.

Assuming a typical mix of active vs. idle users, here is a production-hardened configuration for `application.yml`:

### 1. Tomcat Thread Pool & Connection Settings

The goal here is to allow the OS to handle many connections but keep the JVM from crashing due to "thread thrashing" (CPU spending more time switching threads than doing work).

```yaml
server:
  tomcat:
    # Max threads processing requests simultaneously
    # 200 is default; 400-600 is usually the sweet spot for high load
    threads:
      max: 500
      min-spare: 50
    # Max connections the server accepts and keeps in the OS queue
    # Should be high to prevent "Connection Refused"
    max-connections: 20000
    # Queue size for tasks when all threads are busy
    accept-count: 1000
    # Keep-alive helps 10k users reuse connections
    keep-alive-timeout: 15s
    max-keep-alive-requests: 100
  connection-timeout: 10s

```

* **Max Connections (20,000):** This allows 10,000 users per instance to stay connected (Keep-Alive) without being rejected, even if they aren't all making a request at the exact same millisecond.
* **Max Threads (500):** Do **not** set this to 10,000. If 10,000 threads were active, your CPU would die from context switching. 500 threads can handle thousands of requests per second if your code is efficient (e.g., 20ms response time).

---

### 2. Database Pool (HikariCP) Settings

A common mistake is making the DB pool huge. In reality, a large pool often **slows down** the database due to disk contention and locking.

```yaml
spring:
  datasource:
    hikari:
      # Start with 30-50 per instance. Total connections = 5 * 50 = 250
      # Check your DB's max_connections (e.g., PostgreSQL default is 100)
      maximum-pool-size: 50
      minimum-idle: 10
      # How long to wait for a connection from the pool before failing
      connection-timeout: 5000 # 5 seconds (Fail fast!)
      # Max time a connection can stay in the pool
      max-lifetime: 1800000 # 30 mins
      # Detect "leaked" connections (queries that never closed)
      leak-detection-threshold: 2000 # 2 seconds

```

* **Maximum Pool Size:** Total connections to your DB will be `Instances * maximum-pool-size`. If you have 5 instances with a pool of 50, your DB must support at least **250+** connections.
* **Fail Fast:** Setting `connection-timeout` to 5s ensures that if the DB is slammed, the API returns an error quickly rather than letting Tomcat threads hang until they time out, which would cause a "death spiral" where the whole instance stops responding.

---

### 3. Critical JVM & OS Tuning

Configuring the app is only half the battle. For 10,000 connections per instance, you must tune the environment:

* **OS File Descriptors:** On Linux, the default is often 1,024. A server with 10k users will fail immediately. Increase the `ulimit` for the user running the app to at least **65,535**.
* **Memory (Heap):** Each Tomcat thread consumes roughly 1MB of stack memory. 500 threads = 500MB just for thread overhead.
* **Recommendation:** Minimum **4GB RAM** per instance.
* **JVM Flag:** `-Xms4g -Xmx4g -XX:+UseG1GC`



### Summary Table for 50,000 Users

| Component | Setting | Recommendation (per instance) |
| --- | --- | --- |
| **Tomcat** | `max-threads` | 500 - 800 |
| **Tomcat** | `max-connections` | 20,000 |
| **HikariCP** | `maximum-pool-size` | 30 - 60 (ensure DB can handle  this) |
| **HikariCP** | `connection-timeout` | 5,000 ms |
| **OS** | `ulimit -n` | 65,535 |


When using **MSSQL** (Microsoft SQL Server) with 50,000 users across 5 instances, you are dealing with a database that handles connections very efficiently but has a strict **Worker Thread** limit.

Unlike PostgreSQL, where each connection is a heavy process, MSSQL handles thousands of connections easily, but it can "choke" if too many of those connections try to execute complex queries at the exact same time.

### 1. Spring Boot `application.yml` for MSSQL

For 10,000 users per instance, use these settings to ensure the Java side doesn't become the bottleneck while protecting the SQL Server from connection exhaustion.

```yaml
spring:
  datasource:
    hikari:
      # Total connections across 5 instances = 300. 
      # MSSQL handles this easily (max is 32,767).
      maximum-pool-size: 60
      minimum-idle: 20
      # MSSQL specific: max-lifetime should be 30s-60s less than 
      # the DB's connection timeout (usually 30 mins)
      max-lifetime: 1740000 
      connection-timeout: 5000
      # Essential for MSSQL to find "long running" blocking locks
      leak-detection-threshold: 3000
      pool-name: MSSQL-Hikari-Pool

server:
  tomcat:
    threads:
      max: 600
      min-spare: 100
    max-connections: 15000
    accept-count: 2000

```

---

### 2. The MSSQL "Secret Sauce": Connection String Tuning

MSSQL performance often depends on how the driver handles metadata and encryption. Add these parameters to your `spring.datasource.url`:

* **`sendStringParametersAsUnicode=false`**: By default, the driver sends strings as Unicode (NVARCHAR). If your DB columns are VARCHAR, MSSQL will perform a **Full Table Scan** because it has to convert every row to match the parameter. Setting this to `false` can improve performance by 10x for non-unicode columns.
* **`selectMethod=cursor`**: Useful if you are pulling large datasets, as it prevents the entire result set from being loaded into JVM memory at once.

**Example URL:**
`jdbc:sqlserver://your-server:1433;databaseName=your_db;sendStringParametersAsUnicode=false;encrypt=true;trustServerCertificate=true;`

---

### 3. Database-Side Config (MSSQL)

SQL Server has a "Max Worker Threads" setting. If you have 5 instances with 60 connections each (300 total), you are well within limits, but you should verify your server's capacity.

| CPU Cores | Default Max Worker Threads |
| --- | --- |
| 4 Cores | 512 |
| 16 Cores | 704 |
| 64 Cores | 1216 |

> [!IMPORTANT]
> **Check for "Thread Starvation":** If your 50,000 users trigger many small queries, MSSQL might run out of worker threads before it runs out of connections. Monitor `sys.dm_os_waiting_tasks` to see if `THREADPOOL` wait types appear.

---

### 4. Summary Checklist for MSSQL Success

1. **Isolation Level:** MSSQL's default isolation can cause heavy locking. Consider enabling **Read Committed Snapshot Isolation (RCSI)** at the DB level to allow reads to not block writes:
   `ALTER DATABASE YourDB SET READ_COMMITTED_SNAPSHOT ON;`
2. **Indexing:** With 50,000 users, "Missing Index" warnings in SQL Server Management Studio (SSMS) are your best friend.
3. **App Level:** Use `@Transactional(readOnly = true)` for your GET requests. This allows Hikari and MSSQL to optimize the connection usage.

**Would you like me to provide a SQL script to check your current MSSQL worker thread usage and identify if your 50k users are causing locking issues?**


To truly calibrate your financial system, you shouldn't rely on guesswork. You need to know exactly when your disk or network will "choke."

In a financial system, your **maximum sustained throughput** is limited by your slowest link (usually the disk or a network log aggregator). If your app produces 2,000 logs/sec but your disk can only write 1,000, your 10,000-slot queue will fill up in exactly **20 seconds**.

### The "Struggle Test" (Java Performance Benchmark)

You can run this simple test within your service to find your "breaking point." This test bypasses your business logic to measure pure logging speed.

```java
@Test
void benchmarkLoggingThroughput() throws InterruptedException {
    int totalLogs = 100_000;
    long start = System.currentTimeMillis();

    for (int i = 0; i < totalLogs; i++) {
        // Use your actual logging call here
        log.info("BENCHMARK: Payment processed for account {} amount {}", 
                 "ACC123456", 150.75);
    }

    long duration = System.currentTimeMillis() - start;
    double logsPerSecond = (totalLogs / (double) duration) * 1000;

    System.out.println("--- LOGGING BENCHMARK RESULTS ---");
    System.out.println("Total Time: " + duration + "ms");
    System.out.println("Throughput: " + (int)logsPerSecond + " logs/sec");
}

```

### How to read the results:

1. **If Throughput > your peak TPS:** You are safe. Your `asyncQueueCapacity` only needs to handle small jitter.
2. **If Throughput < your peak TPS:** You have a "Log Debt" problem. No matter how big your queue is, it will eventually fill up, and `CallerRunsPolicy` will slow down your payments.

---

### Calibration Guide for Finance

Based on common fintech benchmarks (on standard cloud SSDs):

| Metric | Low Traffic (<50 TPS) | Medium Traffic (50-200 TPS) | High Traffic (500+ TPS) |
| --- | --- | --- | --- |
| **asyncQueueCapacity** | 1,024 | 4,096 | 10,000 - 20,000 |
| **asyncMaxPoolSize** | 2 | 4 | 8 - 16 |
| **Policy** | `CallerRuns` | `CallerRuns` | `CallerRuns` |
| **Memory Impact** | ~2MB | ~8MB | ~40MB |

### Final Tuning Tip: "The Quiet Killer"

In finance, **Console Logging** is a performance killer. Writing to `System.out` is often 50x slower than writing to a file because it involves synchronized blocks in the JVM.

> **Rule of Thumb:** Always ensure your production profile has console logging **disabled** or set to `ERROR` only. Use `RollingFileAppender` or a direct socket appender for your JSON logs.
