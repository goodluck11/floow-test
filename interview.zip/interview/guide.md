### Performance Test & Optimization Guide

This guide provides a robust template for simulating production-grade loads and optimizing Spring Boot (Tomcat + HikariCP) applications for high RPS (Requests Per Second).

---

### 1. The Realistic Configuration (500 RPS for 3 Instances)

To handle **500 RPS per instance** (1,500 RPS total) with a mix of API and DB calls, use these settings.

#### `application.properties`
```properties
# --- HikariCP Optimization ---
# Formula: (RPS * Average_DB_Latency) + buffer
# If Avg Latency is 100ms: 500 * 0.1 = 50 connections.
spring.datasource.hikari.maximum-pool-size=100
spring.datasource.hikari.minimum-idle=50
spring.datasource.hikari.connection-timeout=5000
spring.datasource.hikari.idle-timeout=600000
spring.datasource.hikari.max-lifetime=1800000

# --- Tomcat Optimization ---
# Enable Virtual Threads (Java 21+) to handle high concurrency without thread pool exhaustion
spring.threads.virtual.enabled=true
server.tomcat.threads.max=1000
server.tomcat.threads.min-spare=100
server.tomcat.max-connections=20000
server.tomcat.accept-count=1000

# --- Timeouts ---
server.tomcat.connection-timeout=20s
server.tomcat.keep-alive-timeout=15s
```

---

### 2. Robust Test Template

The template is located in `src/test/java/com/ready/interview/loadtest/LoadSimulationTest.java`. 

#### How to use the `simulateFlexibleLoad` method:
It allows you to simulate different production scenarios by adjusting:
- `targetRps`: Target requests per second per instance.
- `durationSeconds`: How long the test should run.
- `apiCalls`: Number of sequential external API calls (simulated by 20ms sleep).
- `dbCalls`: Number of sequential database operations.

#### Example Scenarios:
| Scenario | Config in Test | Goal |
| :--- | :--- | :--- |
| **Heavy API Only** | `simulateFlexibleLoad(500, 30, 5, 0)` | Tests thread pool / virtual thread handling. |
| **Heavy DB Only** | `simulateFlexibleLoad(500, 30, 0, 5)` | Tests Connection Pool exhaustion. |
| **Mixed Workload** | `simulateFlexibleLoad(500, 30, 2, 2)` | Realistic banking transaction. |

---

### 3. Metric Analysis Guide

When you run the test, it prints a block like this:
```text
LOAD_TEST_RESULT_START
Config: 500 RPS, 2 API calls, 2 DB calls
Total Target Requests: 5000
Success: 5000
Failures: 0
Actual RPS: 498.5
Throughput (Success): 498.5 req/s
Average Latency: 125.40 ms
P95 Latency: 180 ms
Hikari Pool: Active=45, Idle=55, Total=100, ThreadsAwaiting=0
LOAD_TEST_RESULT_END
```

**Key Indicators:**
1.  **Success vs Failures**: If failures appear with "Connection Timeout", your `maximum-pool-size` is too small for the latency.
2.  **Average Latency**: If this exceeds your SLA (e.g., > 500ms), look for slow queries or blocking API calls.
3.  **ThreadsAwaiting**: If > 0, your pool is a bottleneck. Increase `maximum-pool-size`.

---

### 4. When to Tweak the Connection Pool

| Observation | Action |
| :--- | :--- |
| **High Latency + 0% Failures** | Check DB CPU/IO or application code efficiency. |
| **High Failures + ThreadsAwaiting > 0** | **Increase** `maximum-pool-size`. |
| **Connection Timeout Errors** | **Increase** `maximum-pool-size` OR **Increase** `connection-timeout`. |
| **DB CPU @ 100%** | **Decrease** `maximum-pool-size` to prevent DB thrashing. |
| **API Calls Only (No DB)** | Connection pool size doesn't matter; focus on `server.tomcat.threads.max` or Virtual Threads. |

### 5. Production Guide (MS SQL Server / Postgres)
- Ensure DB `max_connections` >= `Instances * maximum-pool-size`.
- For MS SQL, enable `READ_COMMITTED_SNAPSHOT` to prevent reads from being blocked by writes.
